namespace Dialogly.Api.Helpers;

public static class SessionMetadataHelper
{
    public static (string DeviceName, string OS, string Browser) ParseUserAgent(string? userAgent)
    {
        var ua = userAgent?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(ua))
        {
            return ("Unknown device", "Unknown OS", "Unknown browser");
        }

        var os = GetOperatingSystem(ua);
        var browser = GetBrowser(ua);
        var isMobile = ua.Contains("iPhone", StringComparison.OrdinalIgnoreCase)
            || ua.Contains("Android", StringComparison.OrdinalIgnoreCase)
            || ua.Contains("Mobile", StringComparison.OrdinalIgnoreCase);

        var deviceName = isMobile ? $"{browser} on mobile" : $"{browser} on desktop";
        return (deviceName, os, browser);
    }

    public static string NormalizeIpAddress(string? ipAddress)
    {
        if (string.IsNullOrWhiteSpace(ipAddress))
        {
            return "Unknown IP";
        }

        if (ipAddress.StartsWith("::ffff:", StringComparison.OrdinalIgnoreCase))
        {
            return ipAddress["::ffff:".Length..];
        }

        return ipAddress;
    }

    public static bool IsLocalIp(string? ipAddress)
    {
        if (string.IsNullOrWhiteSpace(ipAddress))
        {
            return false;
        }

        return string.Equals(ipAddress, "::1", StringComparison.OrdinalIgnoreCase)
            || string.Equals(ipAddress, "127.0.0.1", StringComparison.OrdinalIgnoreCase)
            || string.Equals(ipAddress, "localhost", StringComparison.OrdinalIgnoreCase);
    }

    private static string GetOperatingSystem(string userAgent)
    {
        if (userAgent.Contains("Windows", StringComparison.OrdinalIgnoreCase)) return "Windows";
        if (userAgent.Contains("Mac OS X", StringComparison.OrdinalIgnoreCase) || userAgent.Contains("Macintosh", StringComparison.OrdinalIgnoreCase)) return "macOS";
        if (userAgent.Contains("Android", StringComparison.OrdinalIgnoreCase)) return "Android";
        if (userAgent.Contains("iPhone", StringComparison.OrdinalIgnoreCase) || userAgent.Contains("iPad", StringComparison.OrdinalIgnoreCase)) return "iOS";
        if (userAgent.Contains("Linux", StringComparison.OrdinalIgnoreCase)) return "Linux";
        return "Unknown OS";
    }

    private static string GetBrowser(string userAgent)
    {
        if (userAgent.Contains("Edg/", StringComparison.OrdinalIgnoreCase)) return "Edge";
        if (userAgent.Contains("OPR/", StringComparison.OrdinalIgnoreCase) || userAgent.Contains("Opera", StringComparison.OrdinalIgnoreCase)) return "Opera";
        if (userAgent.Contains("Firefox/", StringComparison.OrdinalIgnoreCase)) return "Firefox";
        if (userAgent.Contains("Chrome/", StringComparison.OrdinalIgnoreCase)) return "Chrome";
        if (userAgent.Contains("Safari/", StringComparison.OrdinalIgnoreCase)) return "Safari";
        return "Browser";
    }
}
