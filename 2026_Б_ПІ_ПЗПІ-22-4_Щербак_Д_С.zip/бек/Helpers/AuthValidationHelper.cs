using System.Net.Mail;
using System.Text.RegularExpressions;
using Dialogly.Api.DTOs.Auth;

namespace Dialogly.Api.Helpers;

public static class AuthValidationHelper
{
    private static readonly Regex NameRegex = new(@"^[\p{L}'-]+$", RegexOptions.Compiled);
    private static readonly Regex PasswordRegex = new(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}$", RegexOptions.Compiled);
    private static readonly Regex VerificationCodeRegex = new(@"^\d{6}$", RegexOptions.Compiled);

    public static string? ValidateRegister(RegisterRequestDto request)
    {
        var firstName = request.FirstName?.Trim() ?? string.Empty;
        var lastName = request.LastName?.Trim() ?? string.Empty;
        var email = request.Email?.Trim() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(firstName))
        {
            return "First name is required.";
        }

        if (firstName.Length > 40)
        {
            return "First name must be at most 40 characters.";
        }

        if (!NameRegex.IsMatch(firstName))
        {
            return "First name can contain only letters, apostrophe, or hyphen.";
        }

        if (string.IsNullOrWhiteSpace(lastName))
        {
            return "Last name is required.";
        }

        if (lastName.Length > 40)
        {
            return "Last name must be at most 40 characters.";
        }

        if (!NameRegex.IsMatch(lastName))
        {
            return "Last name can contain only letters, apostrophe, or hyphen.";
        }

        if (request.DateOfBirth is null)
        {
            return "Date of birth is required.";
        }

        var dob = request.DateOfBirth.Value;
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        if (dob > today)
        {
            return "Date of birth cannot be in the future.";
        }

        var age = CalculateAge(dob, today);
        if (age > 120)
        {
            return "Date of birth is not valid.";
        }

        if (string.IsNullOrWhiteSpace(email))
        {
            return "Email is required.";
        }

        if (email.Length > 254)
        {
            return "Email must be at most 254 characters.";
        }

        if (!email.Contains('@'))
        {
            return "Email format is invalid.";
        }

        if (!IsValidEmail(email))
        {
            return "Email format is invalid.";
        }

        if (string.IsNullOrWhiteSpace(request.Password))
        {
            return "Password is required.";
        }

        if (!PasswordRegex.IsMatch(request.Password))
        {
            return "Password must be at least 8 characters and include uppercase, lowercase, digit, and special character.";
        }

        if (string.IsNullOrWhiteSpace(request.ConfirmPassword))
        {
            return "Confirm password is required.";
        }

        if (!string.Equals(request.Password, request.ConfirmPassword, StringComparison.Ordinal))
        {
            return "Confirm password must match password.";
        }

        if (!request.AgreedToTerms)
        {
            return "You must agree to the terms.";
        }

        return null;
    }

    public static string? ValidateLogin(LoginRequestDto request)
    {
        var emailError = ValidateEmail(request.Email);
        if (emailError is not null)
        {
            return emailError;
        }

        if (string.IsNullOrWhiteSpace(request.Password))
        {
            return "Password is required.";
        }

        return null;
    }

    public static string? ValidateVerifyEmail(VerifyEmailRequestDto request)
    {
        var emailError = ValidateEmail(request.Email);
        if (emailError is not null)
        {
            return emailError;
        }

        var code = request.Code?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(code))
        {
            return "Verification code is required.";
        }

        if (!VerificationCodeRegex.IsMatch(code))
        {
            return "Verification code must contain exactly 6 digits.";
        }

        return null;
    }

    public static string? ValidateResendVerificationCode(ResendVerificationCodeRequestDto request)
    {
        return ValidateEmail(request.Email);
    }

    public static string? ValidateForgotPassword(ForgotPasswordRequestDto request)
    {
        return ValidateEmail(request.Email);
    }

    public static string? ValidateResetPassword(ResetPasswordRequestDto request)
    {
        var emailError = ValidateEmail(request.Email);
        if (emailError is not null)
        {
            return emailError;
        }

        var code = request.Code?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(code))
        {
            return "Reset code is required.";
        }

        if (!VerificationCodeRegex.IsMatch(code))
        {
            return "Reset code must contain exactly 6 digits.";
        }

        var passwordError = ValidatePassword(request.NewPassword, "New password");
        if (passwordError is not null)
        {
            return passwordError;
        }

        if (string.IsNullOrWhiteSpace(request.ConfirmPassword))
        {
            return "Confirm password is required.";
        }

        if (!string.Equals(request.NewPassword, request.ConfirmPassword, StringComparison.Ordinal))
        {
            return "Confirm password must match new password.";
        }

        return null;
    }

    public static string? ValidateResendPasswordResetCode(ResendPasswordResetCodeRequestDto request)
    {
        return ValidateEmail(request.Email);
    }

    private static string? ValidateEmail(string? value)
    {
        var email = value?.Trim() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(email))
        {
            return "Email is required.";
        }

        if (email.Length > 254)
        {
            return "Email must be at most 254 characters.";
        }

        if (!email.Contains('@'))
        {
            return "Email format is invalid.";
        }

        if (!IsValidEmail(email))
        {
            return "Email format is invalid.";
        }

        return null;
    }

    private static string? ValidatePassword(string? value, string fieldName)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return $"{fieldName} is required.";
        }

        if (!PasswordRegex.IsMatch(value))
        {
            return $"{fieldName} must be at least 8 characters and include uppercase, lowercase, digit, and special character.";
        }

        return null;
    }

    private static bool IsValidEmail(string email)
    {
        try
        {
            _ = new MailAddress(email);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static int CalculateAge(DateOnly birthDate, DateOnly today)
    {
        var age = today.Year - birthDate.Year;
        if (today.DayOfYear < birthDate.DayOfYear)
        {
            age--;
        }

        return age;
    }
}
