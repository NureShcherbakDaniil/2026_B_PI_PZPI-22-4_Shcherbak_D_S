using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace Dialogly.Api.Helpers;

public static class TotpHelper
{
    private const string Base32Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    public static string GenerateSecret(int byteLength = 20)
    {
        var bytes = RandomNumberGenerator.GetBytes(byteLength);
        return Base32Encode(bytes);
    }

    public static bool VerifyCode(string secret, string code, DateTimeOffset timestamp, int allowedDriftSteps = 1)
    {
        if (string.IsNullOrWhiteSpace(secret) || string.IsNullOrWhiteSpace(code))
        {
            return false;
        }

        var normalizedCode = code.Trim();
        for (var step = -allowedDriftSteps; step <= allowedDriftSteps; step++)
        {
            if (GenerateCode(secret, timestamp.AddSeconds(step * 30)) == normalizedCode)
            {
                return true;
            }
        }

        return false;
    }

    public static string BuildOtpAuthUri(string issuer, string email, string secret)
    {
        var label = Uri.EscapeDataString($"{issuer}:{email}");
        var encodedIssuer = Uri.EscapeDataString(issuer);
        return $"otpauth://totp/{label}?secret={secret}&issuer={encodedIssuer}&digits=6&period=30";
    }

    private static string GenerateCode(string secret, DateTimeOffset timestamp)
    {
        var key = Base32Decode(secret);
        var counter = timestamp.ToUnixTimeSeconds() / 30;
        Span<byte> counterBytes = stackalloc byte[8];
        for (var index = 7; index >= 0; index--)
        {
            counterBytes[index] = (byte)(counter & 0xFF);
            counter >>= 8;
        }

        using var hmac = new HMACSHA1(key);
        var hash = hmac.ComputeHash(counterBytes.ToArray());
        var offset = hash[^1] & 0x0F;
        var binaryCode =
            ((hash[offset] & 0x7F) << 24) |
            (hash[offset + 1] << 16) |
            (hash[offset + 2] << 8) |
            hash[offset + 3];

        var otp = binaryCode % 1_000_000;
        return otp.ToString("D6", CultureInfo.InvariantCulture);
    }

    private static string Base32Encode(byte[] data)
    {
        if (data.Length == 0)
        {
            return string.Empty;
        }

        var builder = new StringBuilder((data.Length + 4) / 5 * 8);
        var buffer = (int)data[0];
        var next = 1;
        var bitsLeft = 8;

        while (bitsLeft > 0 || next < data.Length)
        {
            if (bitsLeft < 5)
            {
                if (next < data.Length)
                {
                    buffer <<= 8;
                    buffer |= data[next++] & 0xFF;
                    bitsLeft += 8;
                }
                else
                {
                    var pad = 5 - bitsLeft;
                    buffer <<= pad;
                    bitsLeft += pad;
                }
            }

            var index = 0x1F & (buffer >> (bitsLeft - 5));
            bitsLeft -= 5;
            builder.Append(Base32Alphabet[index]);
        }

        return builder.ToString();
    }

    private static byte[] Base32Decode(string input)
    {
        var sanitized = input.Trim().TrimEnd('=').ToUpperInvariant();
        if (sanitized.Length == 0)
        {
            return [];
        }

        var output = new List<byte>(sanitized.Length * 5 / 8);
        var buffer = 0;
        var bitsLeft = 0;

        foreach (var character in sanitized)
        {
            var value = Base32Alphabet.IndexOf(character);
            if (value < 0)
            {
                throw new FormatException("Invalid base32 secret.");
            }

            buffer = (buffer << 5) | value;
            bitsLeft += 5;

            if (bitsLeft >= 8)
            {
                output.Add((byte)(buffer >> (bitsLeft - 8)));
                bitsLeft -= 8;
            }
        }

        return [.. output];
    }
}
