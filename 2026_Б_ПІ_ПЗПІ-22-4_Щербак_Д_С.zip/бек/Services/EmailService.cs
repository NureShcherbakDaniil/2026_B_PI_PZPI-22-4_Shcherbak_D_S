using System.Net;
using System.Net.Mail;
using Dialogly.Api.Interfaces;

namespace Dialogly.Api.Services;

public class EmailService(
    IConfiguration configuration,
    IWebHostEnvironment environment,
    ILogger<EmailService> logger) : IEmailService
{
    private readonly IConfiguration _configuration = configuration;
    private readonly IWebHostEnvironment _environment = environment;
    private readonly ILogger<EmailService> _logger = logger;

    public async Task SendVerificationCodeAsync(string email, string code, CancellationToken cancellationToken = default)
    {
        await SendEmailAsync(
            email,
            subject: "Your Dialogly verification code",
            body: $"Your Dialogly verification code is {code}. It expires in 15 minutes.",
            developmentFallbackLogMessage: "[DEV ONLY] Verification code for {Email}: {Code}",
            fallbackLogValue: code,
            cancellationToken: cancellationToken);
    }

    public async Task SendPasswordResetCodeAsync(string email, string code, CancellationToken cancellationToken = default)
    {
        await SendEmailAsync(
            email,
            subject: "Dialogly Password Reset Code",
            body: $"""
                  Your Dialogly password reset code is: {code}
                  This code expires in 15 minutes.
                  If you did not request a password reset, ignore this email.
                  """,
            developmentFallbackLogMessage: "[DEV ONLY] Password reset code for {Email}: {Code}",
            fallbackLogValue: code,
            cancellationToken: cancellationToken);
    }

    public async Task SendAccountDeletionCodeAsync(string email, string code, CancellationToken cancellationToken = default)
    {
        await SendEmailAsync(
            email,
            subject: "Dialogly account deletion confirmation",
            body: $"""
                  You requested to delete your Dialogly account.

                  Your confirmation code is: {code}
                  This code expires in 15 minutes.

                  If you did not request this, ignore this email and consider changing your password.
                  """,
            developmentFallbackLogMessage: "[DEV ONLY] Account deletion code for {Email}: {Code}",
            fallbackLogValue: code,
            cancellationToken: cancellationToken);
    }

    public async Task SendLoginAlertAsync(string email, string device, string location, DateTimeOffset occurredAt, CancellationToken cancellationToken = default)
    {
        var body =
            $"A new sign-in was detected from {device} at {location} on {occurredAt:yyyy-MM-dd HH:mm} UTC. " +
            "If this wasn't you, please change your password immediately.";

        await SendEmailAsync(
            email,
            subject: "New login to your Dialogly account",
            body: body,
            developmentFallbackLogMessage: "[DEV ONLY] Login alert for {Email}: {Context}",
            fallbackLogValue: $"device={device}, location={location}, time={occurredAt:O}",
            cancellationToken: cancellationToken);
    }

    private async Task SendEmailAsync(
        string email,
        string subject,
        string body,
        string developmentFallbackLogMessage,
        string fallbackLogValue,
        CancellationToken cancellationToken)
    {
        var host = _configuration["Smtp:Host"];
        var username = _configuration["Smtp:Username"];
        var password = _configuration["Smtp:Password"];
        var fromEmail = _configuration["Smtp:FromEmail"];
        var fromName = _configuration["Smtp:FromName"] ?? "Dialogly";
        var enableSsl = bool.TryParse(_configuration["Smtp:EnableSsl"], out var ssl) && ssl;
        var port = int.TryParse(_configuration["Smtp:Port"], out var configuredPort)
            ? configuredPort
            : 587;

        if (string.IsNullOrWhiteSpace(host) ||
            string.IsNullOrWhiteSpace(username) ||
            string.IsNullOrWhiteSpace(password) ||
            string.IsNullOrWhiteSpace(fromEmail))
        {
            if (_environment.IsDevelopment())
            {
                _logger.LogWarning(developmentFallbackLogMessage, email, fallbackLogValue);
                return;
            }

            throw new InvalidOperationException("SMTP is not configured.");
        }

        using var message = new MailMessage
        {
            From = new MailAddress(fromEmail, fromName),
            Subject = subject,
            Body = body,
            IsBodyHtml = false
        };

        message.To.Add(email);

        using var client = new SmtpClient(host, port)
        {
            EnableSsl = enableSsl,
            Credentials = new NetworkCredential(username, password)
        };

        await client.SendMailAsync(message, cancellationToken);
    }
}
