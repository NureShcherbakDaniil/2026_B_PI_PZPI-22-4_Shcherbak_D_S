using System.Text.Json;
using Dialogly.Api.Helpers;
using Dialogly.Api.Interfaces;

namespace Dialogly.Api.Services;

public class IpGeolocationService(
    IHttpClientFactory httpClientFactory,
    ILogger<IpGeolocationService> logger) : IIpGeolocationService
{
    private readonly IHttpClientFactory _httpClientFactory = httpClientFactory;
    private readonly ILogger<IpGeolocationService> _logger = logger;

    public async Task<string> ResolveLocationAsync(string? ipAddress, CancellationToken cancellationToken = default)
    {
        var normalizedIp = SessionMetadataHelper.NormalizeIpAddress(ipAddress);
        if (SessionMetadataHelper.IsLocalIp(normalizedIp))
        {
            return "Local";
        }

        try
        {
            var client = _httpClientFactory.CreateClient("ip-geolocation");
            using var response = await client.GetAsync(
                $"json/{Uri.EscapeDataString(normalizedIp)}",
                cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                return normalizedIp;
            }

            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            using var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
            var root = document.RootElement;

            if (root.TryGetProperty("status", out var statusElement) &&
                string.Equals(statusElement.GetString(), "fail", StringComparison.OrdinalIgnoreCase))
            {
                return normalizedIp;
            }

            var city = root.TryGetProperty("city", out var cityElement)
                ? cityElement.GetString()?.Trim()
                : null;
            var country = root.TryGetProperty("country", out var countryElement)
                ? countryElement.GetString()?.Trim()
                : null;

            if (!string.IsNullOrWhiteSpace(city) && !string.IsNullOrWhiteSpace(country))
            {
                return $"{city}, {country}";
            }

            if (!string.IsNullOrWhiteSpace(country))
            {
                return country;
            }
        }
        catch (Exception exception)
        {
            _logger.LogWarning(exception, "Unable to resolve location for IP {IpAddress}", normalizedIp);
        }

        return normalizedIp;
    }
}
