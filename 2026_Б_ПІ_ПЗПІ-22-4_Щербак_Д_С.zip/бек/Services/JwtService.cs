using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Dialogly.Api.Configuration;
using Dialogly.Api.Interfaces;
using Dialogly.Api.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Dialogly.Api.Services;

public class JwtService(IOptions<JwtOptions> jwtOptions) : IJwtService
{
    private readonly JwtOptions _jwtOptions = jwtOptions.Value;

    public string GenerateToken(User user, string? sessionJti = null)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.GivenName, user.FirstName),
            new(ClaimTypes.Surname, user.LastName)
        };

        if (!string.IsNullOrWhiteSpace(sessionJti))
        {
            claims.Add(new Claim(JwtRegisteredClaimNames.Jti, sessionJti));
        }

        var token = new JwtSecurityToken(
            issuer: _jwtOptions.Issuer,
            audience: _jwtOptions.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(_jwtOptions.ExpiresInMinutes),
            signingCredentials: CreateCredentials());

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public string GenerateTwoFactorTempToken(User user, string secret)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new("dialogly_purpose", "two_factor"),
            new("two_factor_secret", secret)
        };

        var token = new JwtSecurityToken(
            issuer: _jwtOptions.Issuer,
            audience: _jwtOptions.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(10),
            signingCredentials: CreateCredentials());

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public bool TryValidateTwoFactorTempToken(string token, out Guid userId, out string secret)
    {
        userId = Guid.Empty;
        secret = string.Empty;

        var handler = new JwtSecurityTokenHandler();
        try
        {
            var principal = handler.ValidateToken(token, CreateValidationParameters(), out _);
            if (!string.Equals(
                    principal.FindFirstValue("dialogly_purpose"),
                    "two_factor",
                    StringComparison.Ordinal))
            {
                return false;
            }

            var userIdClaim = principal.FindFirstValue(ClaimTypes.NameIdentifier);
            secret = principal.FindFirstValue("two_factor_secret") ?? string.Empty;
            if (!Guid.TryParse(userIdClaim, out userId) || string.IsNullOrWhiteSpace(secret))
            {
                userId = Guid.Empty;
                secret = string.Empty;
                return false;
            }

            return true;
        }
        catch
        {
            userId = Guid.Empty;
            secret = string.Empty;
            return false;
        }
    }

    private SigningCredentials CreateCredentials()
    {
        var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtOptions.Key));
        return new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);
    }

    private TokenValidationParameters CreateValidationParameters()
    {
        return new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ValidIssuer = _jwtOptions.Issuer,
            ValidAudience = _jwtOptions.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtOptions.Key)),
            ClockSkew = TimeSpan.Zero
        };
    }
}
