using Dialogly.Api.Configuration;
using Dialogly.Api.Data;
using Dialogly.Api.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Dialogly.Api.Services;

public class TelegramWebhookRefreshService(
    IServiceScopeFactory scopeFactory,
    IConfiguration configuration,
    IOptions<TelegramOptions> telegramOptions,
    ILogger<TelegramWebhookRefreshService> logger) : ITelegramWebhookRefreshService
{
    private const string TelegramPlatformCode = "telegram";
    private const string TelegramBotTokenCredentialType = "telegram_bot_token";
    private static readonly string[] TelegramWebhookAllowedUpdates = ["message", "message_reaction"];

    private readonly IServiceScopeFactory _scopeFactory = scopeFactory;
    private readonly IConfiguration _configuration = configuration;
    private readonly TelegramOptions _telegramOptions = telegramOptions.Value;
    private readonly ILogger<TelegramWebhookRefreshService> _logger = logger;

    public async Task RefreshAllAsync(CancellationToken cancellationToken = default)
    {
        var ngrokUrl = GetConfiguredWebhookBaseUrl();
        if (string.IsNullOrWhiteSpace(ngrokUrl))
        {
            _logger.LogInformation(
                "Skipping Telegram webhook refresh on startup because Ngrok:Url is not configured. Set it via user-secrets, e.g. dotnet user-secrets set \"Ngrok:Url\" \"https://your-ngrok-url.ngrok-free.dev\".");
            return;
        }

        using var scope = _scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var telegramService = scope.ServiceProvider.GetRequiredService<ITelegramService>();

        var integrations = await dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.Credentials)
            .Where(x => x.IsActive
                && x.Status == "Connected"
                && x.Platform.Code == TelegramPlatformCode)
            .ToListAsync(cancellationToken);

        foreach (var integration in integrations)
        {
            await RefreshIntegrationInternalAsync(
                telegramService,
                integration.Id,
                GetCredentialValue(integration.Credentials, TelegramBotTokenCredentialType),
                ngrokUrl,
                cancellationToken);
        }
    }

    public async Task<bool> TryRefreshIntegrationAsync(Guid integrationId, CancellationToken cancellationToken = default)
    {
        var ngrokUrl = GetConfiguredWebhookBaseUrl();
        if (string.IsNullOrWhiteSpace(ngrokUrl))
        {
            _logger.LogInformation(
                "Skipping Telegram webhook refresh for integration {IntegrationId} because Ngrok:Url is not configured.",
                integrationId);
            return false;
        }

        using var scope = _scopeFactory.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var telegramService = scope.ServiceProvider.GetRequiredService<ITelegramService>();

        var integration = await dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.Credentials)
            .FirstOrDefaultAsync(
                x => x.Id == integrationId
                    && x.IsActive
                    && x.Status == "Connected"
                    && x.Platform.Code == TelegramPlatformCode,
                cancellationToken);

        if (integration is null)
        {
            _logger.LogWarning(
                "Skipping Telegram webhook refresh because integration {IntegrationId} was not found or is not an active Telegram integration.",
                integrationId);
            return false;
        }

        return await RefreshIntegrationInternalAsync(
            telegramService,
            integration.Id,
            GetCredentialValue(integration.Credentials, TelegramBotTokenCredentialType),
            ngrokUrl,
            cancellationToken);
    }

    private async Task<bool> RefreshIntegrationInternalAsync(
        ITelegramService telegramService,
        Guid integrationId,
        string? botToken,
        string webhookBaseUrl,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(botToken))
        {
            _logger.LogWarning(
                "Skipping Telegram webhook refresh for integration {IntegrationId} because no bot token is stored.",
                integrationId);
            return false;
        }

        var webhookUrl = $"{webhookBaseUrl.TrimEnd('/')}/api/webhooks/telegram/{integrationId}";

        try
        {
            var result = await telegramService.SetWebhookAsync(
                botToken,
                webhookUrl,
                _telegramOptions.SecretToken,
                TelegramWebhookAllowedUpdates,
                cancellationToken);

            if (result is not { Ok: true })
            {
                _logger.LogWarning(
                    "Telegram webhook refresh failed for integration {IntegrationId}. WebhookUrl={WebhookUrl}. Description={Description}",
                    integrationId,
                    webhookUrl,
                    result?.Description ?? "No description");
                return false;
            }

            _logger.LogInformation(
                "Telegram webhook refreshed for integration {IntegrationId}. WebhookUrl={WebhookUrl}",
                integrationId,
                webhookUrl);
            return true;
        }
        catch (Exception exception)
        {
            _logger.LogWarning(
                exception,
                "Telegram webhook refresh threw for integration {IntegrationId}. WebhookUrl={WebhookUrl}",
                integrationId,
                webhookUrl);
            return false;
        }
    }

    private string? GetConfiguredWebhookBaseUrl()
    {
        return _configuration["Ngrok:Url"]?.Trim()
            ?? _telegramOptions.WebhookBaseUrl?.Trim();
    }

    private static string? GetCredentialValue(IEnumerable<Models.IntegrationCredential> credentials, string credentialType)
    {
        return credentials.FirstOrDefault(x => x.CredentialType == credentialType)?.ValueEncrypted;
    }
}
