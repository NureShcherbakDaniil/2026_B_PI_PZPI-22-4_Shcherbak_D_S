using System.Security.Cryptography;
using Dialogly.Api.Data;
using Dialogly.Api.DTOs.Workspaces;
using Dialogly.Api.Interfaces;
using Dialogly.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Dialogly.Api.Services;

public class WorkspaceService(ApplicationDbContext dbContext) : IWorkspaceService
{
    private static readonly HashSet<string> AllowedRoles = ["Owner", "Admin", "Member"];
    private readonly ApplicationDbContext _dbContext = dbContext;

    public async Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> CreateWorkspaceAsync(
        Guid userId,
        CreateWorkspaceRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var workspaceName = request.Name.Trim();
        var nowUtc = DateTime.UtcNow;
        var workspace = new Workspace
        {
            Id = Guid.NewGuid(),
            Name = workspaceName,
            Industry = NormalizeOptional(request.Industry),
            Website = NormalizeOptional(request.Website),
            Description = NormalizeOptional(request.Description),
            PublicSenderName = $"{workspaceName} Support",
            CreatedAt = nowUtc,
            UpdatedAt = nowUtc,
            IsActive = true
        };

        var member = new WorkspaceMember
        {
            Id = Guid.NewGuid(),
            WorkspaceId = workspace.Id,
            UserId = userId,
            Role = "Owner",
            JoinedAt = nowUtc,
            IsActive = true
        };

        user.ActiveWorkspaceId = workspace.Id;
        user.IsOnboardingCompleted = true;
        user.UpdatedAt = nowUtc;

        _dbContext.Workspaces.Add(workspace);
        _dbContext.WorkspaceMembers.Add(member);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapWorkspace(workspace, member.Role), null, StatusCodes.Status200OK);
    }

    public async Task<IReadOnlyList<WorkspaceDto>> GetMyWorkspacesAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        return await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .Where(x => x.UserId == userId && x.IsActive && x.Workspace.IsActive)
            .Select(x => new WorkspaceDto
            {
                Id = x.Workspace.Id,
                Name = x.Workspace.Name,
                Industry = x.Workspace.Industry,
                Website = x.Workspace.Website,
                Description = x.Workspace.Description,
                PublicSenderName = x.Workspace.PublicSenderName,
                Role = x.Role,
                CreatedAt = x.Workspace.CreatedAt
            })
            .OrderBy(x => x.Name)
            .ToListAsync(cancellationToken);
    }

    public async Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> GetWorkspaceAsync(
        Guid userId,
        Guid workspaceId,
        CancellationToken cancellationToken = default)
    {
        var membership = await GetActiveMembershipAsync(userId, workspaceId, cancellationToken);
        if (membership is null)
        {
            return (null, "Workspace not found.", StatusCodes.Status404NotFound);
        }

        return (MapWorkspace(membership.Workspace, membership.Role), null, StatusCodes.Status200OK);
    }

    public async Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> UpdateWorkspaceAsync(
        Guid userId,
        Guid workspaceId,
        UpdateWorkspaceRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var membership = await GetActiveMembershipAsync(userId, workspaceId, cancellationToken);
        if (membership is null)
        {
            return (null, "Workspace not found.", StatusCodes.Status404NotFound);
        }

        if (!CanManageInvites(membership.Role))
        {
            return (null, "Only Owners and Admins can update workspace settings.", StatusCodes.Status403Forbidden);
        }

        var workspace = membership.Workspace;
        var name = request.Name?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(name))
        {
            return (null, "Workspace name is required.", StatusCodes.Status400BadRequest);
        }

        if (name.Length < 2 || name.Length > 200)
        {
            return (null, "Workspace name must be between 2 and 200 characters.", StatusCodes.Status400BadRequest);
        }

        workspace.Name = name;
        workspace.Website = NormalizeOptional(request.Website);
        workspace.Industry = NormalizeOptional(request.Industry);
        workspace.Description = NormalizeOptional(request.Description);
        workspace.Timezone = NormalizeOptional(request.Timezone);
        workspace.DefaultLanguage = NormalizeOptional(request.DefaultLanguage);
        workspace.PublicSenderName = $"{name} Support";
        workspace.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);
        return (MapWorkspace(workspace, membership.Role), null, StatusCodes.Status200OK);
    }

    public async Task<IReadOnlyList<WorkspaceMemberDto>> GetWorkspaceMembersAsync(
        Guid userId,
        Guid workspaceId,
        CancellationToken cancellationToken = default)
    {
        var membership = await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .AnyAsync(x => x.UserId == userId && x.WorkspaceId == workspaceId && x.IsActive && x.Workspace.IsActive, cancellationToken);

        if (!membership)
        {
            return [];
        }

        return await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .Where(x => x.WorkspaceId == workspaceId && x.IsActive && x.Workspace.IsActive)
            .Include(x => x.User)
            .OrderBy(x => x.Role == "Owner" ? 0 : x.Role == "Admin" ? 1 : 2)
            .ThenBy(x => x.User.FirstName)
            .ThenBy(x => x.User.LastName)
            .Select(x => new WorkspaceMemberDto
            {
                UserId = x.UserId,
                FirstName = x.User.FirstName,
                LastName = x.User.LastName,
                Email = x.User.Email,
                Role = ToDisplayRole(x.Role),
                Status = "Active",
                JoinedAt = x.JoinedAt
            })
            .ToListAsync(cancellationToken);
    }

    public async Task<(string? ErrorMessage, int StatusCode)> RemoveWorkspaceMemberAsync(
        Guid userId,
        Guid workspaceId,
        Guid memberUserId,
        CancellationToken cancellationToken = default)
    {
        var membership = await GetActiveMembershipAsync(userId, workspaceId, cancellationToken);
        if (membership is null)
        {
            return ("Workspace not found.", StatusCodes.Status404NotFound);
        }

        if (!CanManageInvites(membership.Role))
        {
            return ("Only Owners and Admins can remove members.", StatusCodes.Status403Forbidden);
        }

        if (userId == memberUserId)
        {
            return ("You cannot remove yourself from the workspace.", StatusCodes.Status400BadRequest);
        }

        var member = await _dbContext.WorkspaceMembers
            .Include(x => x.User)
            .FirstOrDefaultAsync(x => x.WorkspaceId == workspaceId && x.UserId == memberUserId && x.IsActive, cancellationToken);

        if (member is null)
        {
            return ("Member not found.", StatusCodes.Status404NotFound);
        }

        if (member.Role == "Owner")
        {
            return ("Workspace owner cannot be removed.", StatusCodes.Status400BadRequest);
        }

        member.IsActive = false;
        if (member.User.ActiveWorkspaceId == workspaceId)
        {
            member.User.ActiveWorkspaceId = null;
            member.User.UpdatedAt = DateTime.UtcNow;
        }

        await _dbContext.SaveChangesAsync(cancellationToken);
        return (null, StatusCodes.Status204NoContent);
    }

    public async Task<(WorkspaceInviteDto? Response, string? ErrorMessage, int StatusCode)> CreateInviteAsync(
        Guid userId,
        Guid workspaceId,
        CreateWorkspaceInviteRequestDto request,
        string frontendBaseUrl,
        CancellationToken cancellationToken = default)
    {
        var membership = await GetActiveMembershipAsync(userId, workspaceId, cancellationToken);

        if (membership is null)
        {
            return (null, "Workspace not found.", StatusCodes.Status404NotFound);
        }

        if (!CanManageInvites(membership.Role))
        {
            return (null, "Only Owners and Admins can create invite codes.", StatusCodes.Status403Forbidden);
        }

        var nowUtc = DateTime.UtcNow;
        var invite = new WorkspaceInvite
        {
            Id = Guid.NewGuid(),
            WorkspaceId = workspaceId,
            Code = await GenerateUniqueInviteCodeAsync(cancellationToken),
            InviteLinkToken = Guid.NewGuid().ToString("N"),
            Role = NormalizeRole(request.Role) ?? "Member",
            CreatedByUserId = userId,
            ExpiresAt = nowUtc.AddDays(7),
            IsUsed = false,
            CreatedAt = nowUtc,
            IsActive = true
        };

        _dbContext.WorkspaceInvites.Add(invite);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapInvite(invite, frontendBaseUrl), null, StatusCodes.Status200OK);
    }

    public async Task<(IReadOnlyList<WorkspaceInviteDto>? Response, string? ErrorMessage, int StatusCode)> GetWorkspaceInvitesAsync(
        Guid userId,
        Guid workspaceId,
        string frontendBaseUrl,
        CancellationToken cancellationToken = default)
    {
        var membership = await GetActiveMembershipAsync(userId, workspaceId, cancellationToken);
        if (membership is null)
        {
            return (null, "Workspace not found.", StatusCodes.Status404NotFound);
        }

        if (!CanManageInvites(membership.Role))
        {
            return (null, "Only Owners and Admins can view invites.", StatusCodes.Status403Forbidden);
        }

        var invites = await _dbContext.WorkspaceInvites
            .AsNoTracking()
            .Where(x => x.WorkspaceId == workspaceId)
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync(cancellationToken);

        return (invites.Select(x => MapInvite(x, frontendBaseUrl)).ToList(), null, StatusCodes.Status200OK);
    }

    public async Task<(WorkspaceInviteDto? Response, string? ErrorMessage, int StatusCode)> RevokeWorkspaceInviteAsync(
        Guid userId,
        Guid workspaceId,
        string token,
        string frontendBaseUrl,
        CancellationToken cancellationToken = default)
    {
        var membership = await GetActiveMembershipAsync(userId, workspaceId, cancellationToken);
        if (membership is null)
        {
            return (null, "Workspace not found.", StatusCodes.Status404NotFound);
        }

        if (!CanManageInvites(membership.Role))
        {
            return (null, "Only Owners and Admins can revoke invites.", StatusCodes.Status403Forbidden);
        }

        var invite = await _dbContext.WorkspaceInvites
            .FirstOrDefaultAsync(
                x => x.WorkspaceId == workspaceId &&
                    (x.Code.ToUpper() == token.Trim().ToUpper() || x.InviteLinkToken.ToUpper() == token.Trim().ToUpper()),
                cancellationToken);

        if (invite is null)
        {
            return (null, "Invite not found.", StatusCodes.Status404NotFound);
        }

        invite.IsActive = false;
        if (!invite.ExpiresAt.HasValue || invite.ExpiresAt > DateTime.UtcNow)
        {
            invite.ExpiresAt = DateTime.UtcNow;
        }

        await _dbContext.SaveChangesAsync(cancellationToken);
        return (MapInvite(invite, frontendBaseUrl), null, StatusCodes.Status200OK);
    }

    public async Task<WorkspaceInviteValidationDto> ValidateInviteAsync(string token, CancellationToken cancellationToken = default)
    {
        var nowUtc = DateTime.UtcNow;
        var invite = await FindInviteByTokenAsync(token, cancellationToken, asNoTracking: true);

        if (invite is null)
        {
            return new WorkspaceInviteValidationDto { IsValid = false };
        }

        return new WorkspaceInviteValidationDto
        {
            WorkspaceName = invite.Workspace.Name,
            Role = ToDisplayRole(invite.Role),
            IsValid = invite.Workspace.IsActive && invite.IsActive && !invite.IsUsed && (!invite.ExpiresAt.HasValue || invite.ExpiresAt > nowUtc)
        };
    }

    public async Task<(AcceptWorkspaceInviteResponseDto? Response, string? ErrorMessage, int StatusCode)> AcceptInviteAsync(
        Guid userId,
        string token,
        CancellationToken cancellationToken = default)
    {
        var (workspace, errorMessage, statusCode) = await JoinWorkspaceAsync(userId, token, cancellationToken);
        if (workspace is null)
        {
            return (null, errorMessage, statusCode);
        }

        return (new AcceptWorkspaceInviteResponseDto
        {
            WorkspaceId = workspace.Id,
            Role = ToDisplayRole(workspace.Role)
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> JoinWorkspaceAsync(
        Guid userId,
        string inviteCode,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var nowUtc = DateTime.UtcNow;
        var invite = await FindInviteByTokenAsync(inviteCode, cancellationToken);

        if (invite is null || !invite.IsActive || invite.IsUsed || !invite.Workspace.IsActive || (invite.ExpiresAt.HasValue && invite.ExpiresAt <= nowUtc))
        {
            return (null, "Invite code is invalid or expired.", StatusCodes.Status404NotFound);
        }

        var alreadyMember = await _dbContext.WorkspaceMembers.AnyAsync(
            x => x.UserId == userId && x.WorkspaceId == invite.WorkspaceId && x.IsActive,
            cancellationToken);

        if (alreadyMember)
        {
            return (null, "You are already a member of this workspace.", StatusCodes.Status409Conflict);
        }

        var member = new WorkspaceMember
        {
            Id = Guid.NewGuid(),
            WorkspaceId = invite.WorkspaceId,
            UserId = userId,
            Role = NormalizeRole(invite.Role) ?? "Member",
            JoinedAt = nowUtc,
            InvitedByUserId = invite.CreatedByUserId,
            IsActive = true
        };

        invite.IsUsed = true;
        invite.UsedByUserId = userId;
        invite.UsedAt = nowUtc;

        user.ActiveWorkspaceId = invite.WorkspaceId;
        user.IsOnboardingCompleted = true;
        user.UpdatedAt = nowUtc;

        _dbContext.WorkspaceMembers.Add(member);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapWorkspace(invite.Workspace, member.Role), null, StatusCodes.Status200OK);
    }

    public async Task<IReadOnlyList<AccountContextDto>> GetAccountContextsAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);

        if (user is null)
        {
            return [];
        }

        var contexts = new List<AccountContextDto>
        {
            new()
            {
                Type = "personal",
                Id = user.Id,
                Name = "Personal",
                Role = null,
                IsActive = user.ActiveWorkspaceId is null
            }
        };

        var workspaceContexts = await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .Where(x => x.UserId == userId && x.IsActive && x.Workspace.IsActive)
            .OrderBy(x => x.Workspace.Name)
            .Select(x => new AccountContextDto
            {
                Type = "workspace",
                Id = x.WorkspaceId,
                Name = x.Workspace.Name,
                Role = x.Role,
                IsActive = user.ActiveWorkspaceId == x.WorkspaceId
            })
            .ToListAsync(cancellationToken);

        contexts.AddRange(workspaceContexts);
        return contexts;
    }

    private static WorkspaceDto MapWorkspace(Workspace workspace, string role)
    {
        return new WorkspaceDto
        {
            Id = workspace.Id,
            Name = workspace.Name,
            Industry = workspace.Industry,
            Website = workspace.Website,
            Description = workspace.Description,
            Timezone = workspace.Timezone,
            DefaultLanguage = workspace.DefaultLanguage,
            LogoUrl = workspace.LogoUrl,
            PublicSenderName = workspace.PublicSenderName,
            Role = role,
            CreatedAt = workspace.CreatedAt,
            UpdatedAt = workspace.UpdatedAt
        };
    }

    private async Task<WorkspaceMember?> GetActiveMembershipAsync(Guid userId, Guid workspaceId, CancellationToken cancellationToken)
    {
        return await _dbContext.WorkspaceMembers
            .Include(x => x.Workspace)
            .FirstOrDefaultAsync(
                x => x.UserId == userId && x.WorkspaceId == workspaceId && x.IsActive && x.Workspace.IsActive,
                cancellationToken);
    }

    private async Task<WorkspaceInvite?> FindInviteByTokenAsync(string token, CancellationToken cancellationToken, bool asNoTracking = false)
    {
        var normalizedToken = token.Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(normalizedToken))
        {
            return null;
        }

        IQueryable<WorkspaceInvite> query = _dbContext.WorkspaceInvites
            .Include(x => x.Workspace)
            .Where(x => x.Code.ToUpper() == normalizedToken || x.InviteLinkToken.ToUpper() == normalizedToken);

        if (asNoTracking)
        {
            query = query.AsNoTracking();
        }

        return await query.FirstOrDefaultAsync(cancellationToken);
    }

    private static WorkspaceInviteDto MapInvite(WorkspaceInvite invite, string frontendBaseUrl)
    {
        var normalizedBaseUrl = string.IsNullOrWhiteSpace(frontendBaseUrl)
            ? "http://localhost:5173"
            : frontendBaseUrl.TrimEnd('/');

        return new WorkspaceInviteDto
        {
            Token = invite.Code,
            InviteCode = invite.Code,
            InviteUrl = $"{normalizedBaseUrl}/join?code={Uri.EscapeDataString(invite.Code)}",
            Role = ToDisplayRole(invite.Role),
            Status = GetInviteStatus(invite),
            CreatedAt = invite.CreatedAt,
            ExpiresAt = invite.ExpiresAt
        };
    }

    private static string? NormalizeOptional(string? value)
    {
        return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    }

    private static bool CanManageInvites(string role)
    {
        return role == "Owner" || role == "Admin";
    }

    private static string? NormalizeRole(string? role)
    {
        if (string.IsNullOrWhiteSpace(role))
        {
            return null;
        }

        var normalized = role.Trim();
        if (normalized.Equals("Operator", StringComparison.OrdinalIgnoreCase))
        {
            return "Member";
        }

        return AllowedRoles.Contains(normalized) ? normalized : null;
    }

    private async Task<string> GenerateUniqueInviteCodeAsync(CancellationToken cancellationToken)
    {
        for (var attempt = 0; attempt < 10; attempt += 1)
        {
            var code = RandomAlphaNumeric(8);
            var exists = await _dbContext.WorkspaceInvites.AnyAsync(x => x.Code == code, cancellationToken);
            if (!exists)
            {
                return code;
            }
        }

        return $"{Guid.NewGuid():N}"[..8].ToUpperInvariant();
    }

    private static string RandomLetters(int length)
    {
        const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return new string(Enumerable.Range(0, length)
            .Select(_ => alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)])
            .ToArray());
    }

    private static string RandomDigits(int length)
    {
        return new string(Enumerable.Range(0, length)
            .Select(_ => (char)('0' + RandomNumberGenerator.GetInt32(10)))
            .ToArray());
    }

    private static string RandomAlphaNumeric(int length)
    {
        const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return new string(Enumerable.Range(0, length)
            .Select(_ => alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)])
            .ToArray());
    }

    private static string ToDisplayRole(string role)
    {
        return role == "Member" ? "Operator" : role;
    }

    private static string GetInviteStatus(WorkspaceInvite invite)
    {
        if (invite.IsUsed)
        {
            return "Used";
        }

        if (!invite.IsActive || (invite.ExpiresAt.HasValue && invite.ExpiresAt <= DateTime.UtcNow))
        {
            return "Expired";
        }

        return "Active";
    }
}
