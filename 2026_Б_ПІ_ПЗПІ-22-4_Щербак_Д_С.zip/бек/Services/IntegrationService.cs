using Dialogly.Api.Configuration;
using Dialogly.Api.Data;
using Dialogly.Api.DTOs.Integrations;
using Dialogly.Api.DTOs.Telegram;
using Dialogly.Api.Interfaces;
using Dialogly.Api.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Dialogly.Api.Services;

public class IntegrationService(
    ApplicationDbContext dbContext,
    ITelegramService telegramService,
    IIntegrationUniquenessService integrationUniquenessService,
    ITelegramWebhookRefreshService telegramWebhookRefreshService,
    IOptions<TelegramOptions> telegramOptions,
    IWebHostEnvironment environment,
    ILogger<IntegrationService> logger) : IIntegrationService
{
    private const string TelegramPlatformCode = "telegram";
    private const string MessengerPlatformCode = "messenger";
    private const string TelegramBotTokenCredentialType = "telegram_bot_token";
    private static readonly string[] TelegramWebhookAllowedUpdates = ["message", "message_reaction"];

    private static readonly Dictionary<string, string> PlatformDescriptions = new(StringComparer.OrdinalIgnoreCase)
    {
        [TelegramPlatformCode] = "Connect a real Telegram bot using a BotFather token.",
        [MessengerPlatformCode] = "Connect a Facebook Messenger page using a Page ID and Page Access Token."
    };

    private static readonly HashSet<string> AllowedPlatformCodes = [TelegramPlatformCode, MessengerPlatformCode];

    private readonly ApplicationDbContext _dbContext = dbContext;
    private readonly ITelegramService _telegramService = telegramService;
    private readonly IIntegrationUniquenessService _integrationUniquenessService = integrationUniquenessService;
    private readonly ITelegramWebhookRefreshService _telegramWebhookRefreshService = telegramWebhookRefreshService;
    private readonly TelegramOptions _telegramOptions = telegramOptions.Value;
    private readonly IWebHostEnvironment _environment = environment;
    private readonly ILogger<IntegrationService> _logger = logger;

    public async Task<IReadOnlyList<PlatformDto>> GetPlatformsAsync(CancellationToken cancellationToken = default)
    {
        var platforms = await _dbContext.Platforms
            .AsNoTracking()
            .Where(x => x.IsActive && AllowedPlatformCodes.Contains(x.Code))
            .OrderBy(x => x.Name)
            .ToListAsync(cancellationToken);

        return platforms
            .Select(x => new PlatformDto
            {
                Id = x.Id,
                Code = x.Code,
                Name = x.Name,
                ShortDescription = PlatformDescriptions.TryGetValue(x.Code, out var description)
                    ? description
                    : $"{x.Name} integration",
                IsEnabled = x.IsActive
            })
            .ToList();
    }

    public async Task<(IReadOnlyList<IntegrationAccountDto> Response, string? ErrorMessage, int StatusCode)> GetIntegrationsAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        var resolved = await ResolveContextAsync(userId, requireWorkspaceManageAccess: false, cancellationToken);
        if (!resolved.IsSuccess)
        {
            return ([], resolved.ErrorMessage, resolved.StatusCode);
        }

        var query = _dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.ConnectedByUser)
            .Where(x => x.Platform.IsActive && AllowedPlatformCodes.Contains(x.Platform.Code));

        query = resolved.Scope == "Workspace"
            ? query.Where(x => x.WorkspaceId == resolved.WorkspaceId)
            : query.Where(x => x.PersonalAccountId == resolved.PersonalAccountId);

        var integrations = await query
            .OrderByDescending(x => x.UpdatedAt ?? x.CreatedAt)
            .ToListAsync(cancellationToken);

        var latestByPlatform = integrations
            .GroupBy(x => x.Platform.Code)
            .Select(x => x.First())
            .OrderBy(x => x.Platform.Name)
            .Select(x => MapIntegration(x, resolved))
            .ToList();

        return (latestByPlatform, null, StatusCodes.Status200OK);
    }

    public async Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> ConnectIntegrationAsync(
        Guid userId,
        ConnectIntegrationRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var resolved = await ResolveContextAsync(userId, requireWorkspaceManageAccess: true, cancellationToken);
        if (!resolved.IsSuccess)
        {
            return (null, resolved.ErrorMessage, resolved.StatusCode);
        }

        var normalizedPlatformCode = request.PlatformCode.Trim().ToLowerInvariant();
        var platform = await _dbContext.Platforms.FirstOrDefaultAsync(
            x => x.IsActive && x.Code == normalizedPlatformCode && AllowedPlatformCodes.Contains(x.Code),
            cancellationToken);

        if (platform is null)
        {
            return (null, "Platform is not available.", StatusCodes.Status404NotFound);
        }

        if (platform.Code == TelegramPlatformCode)
        {
            return (null, "Use the Telegram token flow for real Telegram bot connections.", StatusCodes.Status400BadRequest);
        }

        if (platform.Code == MessengerPlatformCode)
        {
            return (null, "Use the Messenger page flow for real Messenger connections.", StatusCodes.Status400BadRequest);
        }

        var externalAccountId = request.ExternalAccountId.Trim();
        var displayName = request.DisplayName.Trim();
        var username = string.IsNullOrWhiteSpace(request.Username) ? null : request.Username.Trim();
        var nowUtc = DateTime.UtcNow;

        var availability = await _integrationUniquenessService.EnsureIntegrationIsAvailableAsync(
            platform.Code,
            externalAccountId,
            userId,
            resolved.WorkspaceId,
            cancellationToken);

        if (!availability.IsAvailable)
        {
            return (null, availability.ErrorMessage, availability.StatusCode);
        }

        var integration = availability.ExistingIntegration
            ?? await BuildScopedIntegrationsQuery(resolved)
                .Include(x => x.Platform)
                .Include(x => x.ConnectedByUser)
                .Where(x => x.PlatformId == platform.Id && x.IsActive)
                .OrderByDescending(x => x.UpdatedAt ?? x.CreatedAt)
                .FirstOrDefaultAsync(cancellationToken);

        if (integration is null)
        {
            integration = new Integration
            {
                Id = Guid.NewGuid(),
                PlatformId = platform.Id,
                PersonalAccountId = resolved.PersonalAccountId,
                WorkspaceId = resolved.WorkspaceId,
                CreatedAt = nowUtc,
                IsActive = true
            };

            _dbContext.Integrations.Add(integration);
        }

        integration.DisplayName = displayName;
        integration.ExternalAccountId = externalAccountId;
        integration.Username = username;
        integration.Status = "Connected";
        integration.ConnectedByUserId = userId;
        integration.ConnectedAt = nowUtc;
        integration.LastSyncAt = nowUtc;
        integration.DisconnectedAt = null;
        integration.UpdatedAt = nowUtc;
        integration.IsActive = true;
        integration.PersonalAccountId = resolved.PersonalAccountId;
        integration.WorkspaceId = resolved.WorkspaceId;

        await _dbContext.SaveChangesAsync(cancellationToken);

        var response = await _dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.ConnectedByUser)
            .FirstAsync(x => x.Id == integration.Id, cancellationToken);

        return (MapIntegration(response, resolved), null, StatusCodes.Status200OK);
    }

    public async Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> ConnectTelegramBotAsync(
        Guid userId,
        ConnectTelegramIntegrationRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var resolved = await ResolveContextAsync(userId, requireWorkspaceManageAccess: true, cancellationToken);
        if (!resolved.IsSuccess)
        {
            return (null, resolved.ErrorMessage, resolved.StatusCode);
        }

        var botToken = request.BotToken.Trim();
        if (string.IsNullOrWhiteSpace(botToken))
        {
            return (null, "Bot token is required.", StatusCodes.Status400BadRequest);
        }

        var platform = await _dbContext.Platforms.FirstOrDefaultAsync(
            x => x.IsActive && x.Code == TelegramPlatformCode,
            cancellationToken);

        if (platform is null)
        {
            return (null, "Telegram platform is not available.", StatusCodes.Status404NotFound);
        }

        var botInfo = await _telegramService.ValidateBotTokenAsync(botToken, cancellationToken);
        if (botInfo is null)
        {
            return (null, "Telegram bot token is invalid.", StatusCodes.Status400BadRequest);
        }

        var availability = await _integrationUniquenessService.EnsureIntegrationIsAvailableAsync(
            TelegramPlatformCode,
            botInfo.ExternalAccountId,
            userId,
            resolved.WorkspaceId,
            cancellationToken);

        if (!availability.IsAvailable)
        {
            return (null, availability.ErrorMessage, availability.StatusCode);
        }

        if (availability.ExistingIntegration is not null)
        {
            var existing = availability.ExistingIntegration;
            var reconnectUtc = DateTime.UtcNow;

            existing.DisplayName = botInfo.DisplayName;
            existing.ExternalAccountId = botInfo.ExternalAccountId;
            existing.Username = botInfo.Username;
            existing.Status = "Connected";
            existing.ConnectedByUserId = userId;
            existing.ConnectedAt ??= reconnectUtc;
            existing.LastSyncAt = reconnectUtc;
            existing.DisconnectedAt = null;
            existing.UpdatedAt = reconnectUtc;
            existing.IsActive = true;
            existing.PersonalAccountId = resolved.PersonalAccountId;
            existing.WorkspaceId = resolved.WorkspaceId;

            await UpsertCredentialAsync(existing.Id, TelegramBotTokenCredentialType, botToken, cancellationToken);
            await _dbContext.SaveChangesAsync(cancellationToken);
            await _telegramWebhookRefreshService.TryRefreshIntegrationAsync(existing.Id, cancellationToken);

            var existingResponse = await _dbContext.Integrations
                .AsNoTracking()
                .Include(x => x.Platform)
                .Include(x => x.ConnectedByUser)
                .FirstAsync(x => x.Id == existing.Id, cancellationToken);

            return (MapIntegration(existingResponse, resolved), null, StatusCodes.Status200OK);
        }

        var nowUtc = DateTime.UtcNow;
        var integration = await BuildScopedIntegrationsQuery(resolved)
            .Include(x => x.Credentials)
            .Include(x => x.Platform)
            .Include(x => x.ConnectedByUser)
            .Where(x => x.PlatformId == platform.Id && x.IsActive)
            .OrderByDescending(x => x.UpdatedAt ?? x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (integration is null)
        {
            integration = new Integration
            {
                Id = Guid.NewGuid(),
                PlatformId = platform.Id,
                PersonalAccountId = resolved.PersonalAccountId,
                WorkspaceId = resolved.WorkspaceId,
                CreatedAt = nowUtc,
                IsActive = true
            };

            _dbContext.Integrations.Add(integration);
        }

        integration.DisplayName = botInfo.DisplayName;
        integration.ExternalAccountId = botInfo.ExternalAccountId;
        integration.Username = botInfo.Username;
        integration.Status = "Connected";
        integration.ConnectedByUserId = userId;
        integration.ConnectedAt ??= nowUtc;
        integration.LastSyncAt = nowUtc;
        integration.DisconnectedAt = null;
        integration.UpdatedAt = nowUtc;
        integration.IsActive = true;
        integration.PersonalAccountId = resolved.PersonalAccountId;
        integration.WorkspaceId = resolved.WorkspaceId;

        await UpsertCredentialAsync(integration.Id, TelegramBotTokenCredentialType, botToken, cancellationToken, integration.Credentials);
        await _dbContext.SaveChangesAsync(cancellationToken);
        await _telegramWebhookRefreshService.TryRefreshIntegrationAsync(integration.Id, cancellationToken);

        var response = await _dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.ConnectedByUser)
            .FirstAsync(x => x.Id == integration.Id, cancellationToken);

        return (MapIntegration(response, resolved), null, StatusCodes.Status200OK);
    }

    public async Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> DisconnectIntegrationAsync(
        Guid userId,
        Guid integrationId,
        CancellationToken cancellationToken = default)
    {
        var resolved = await ResolveContextAsync(userId, requireWorkspaceManageAccess: true, cancellationToken);
        if (!resolved.IsSuccess)
        {
            return (null, resolved.ErrorMessage, resolved.StatusCode);
        }

        var integration = await _dbContext.Integrations
            .Include(x => x.Platform)
            .Include(x => x.ConnectedByUser)
            .FirstOrDefaultAsync(
                x => x.Id == integrationId
                    && x.IsActive
                    && AllowedPlatformCodes.Contains(x.Platform.Code),
                cancellationToken);

        if (integration is null)
        {
            return (null, "Integration not found.", StatusCodes.Status404NotFound);
        }

        var belongsToActiveContext = resolved.Scope == "Workspace"
            ? integration.WorkspaceId == resolved.WorkspaceId
            : integration.PersonalAccountId == resolved.PersonalAccountId;

        if (!belongsToActiveContext)
        {
            return (null, "Integration not found in the active context.", StatusCodes.Status404NotFound);
        }

        integration.Status = "Disconnected";
        integration.DisconnectedAt = DateTime.UtcNow;
        integration.UpdatedAt = integration.DisconnectedAt;
        integration.IsActive = false;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapIntegration(integration, resolved), null, StatusCodes.Status200OK);
    }

    public async Task<(object? Response, string? ErrorMessage, int StatusCode)> SetTelegramWebhookAsync(
        Guid userId,
        Guid integrationId,
        SetTelegramWebhookRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var resolved = await ResolveContextAsync(userId, requireWorkspaceManageAccess: true, cancellationToken);
        if (!resolved.IsSuccess)
        {
            return (null, resolved.ErrorMessage, resolved.StatusCode);
        }

        var integration = await LoadScopedTelegramIntegrationAsync(resolved, integrationId, cancellationToken);
        if (integration is null)
        {
            return (null, "Telegram integration not found in the active context.", StatusCodes.Status404NotFound);
        }

        var botToken = GetCredentialValue(integration, TelegramBotTokenCredentialType);
        if (string.IsNullOrWhiteSpace(botToken))
        {
            return (null, "Telegram bot token is not stored for this integration.", StatusCodes.Status400BadRequest);
        }

        var publicBaseUrl = request.PublicBaseUrl.Trim().TrimEnd('/');
        if (!Uri.TryCreate(publicBaseUrl, UriKind.Absolute, out _))
        {
            return (null, "A valid public webhook URL is required.", StatusCodes.Status400BadRequest);
        }

        var webhookUrl = $"{publicBaseUrl}/api/webhooks/telegram/{integration.Id}";
        var result = await _telegramService.SetWebhookAsync(
            botToken,
            webhookUrl,
            _telegramOptions.SecretToken,
            TelegramWebhookAllowedUpdates,
            cancellationToken);

        if (result is not { Ok: true })
        {
            return (null, result?.Description ?? "Telegram rejected the webhook configuration.", StatusCodes.Status400BadRequest);
        }

        return (new
        {
            webhookUrl,
            telegram = result,
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(bool Success, string? ErrorMessage, int StatusCode)> HandleTelegramWebhookAsync(
        Guid integrationId,
        TelegramUpdateDto update,
        CancellationToken cancellationToken = default)
    {
        if (update.MessageReaction is not null)
        {
            return await HandleTelegramMessageReactionAsync(integrationId, update, cancellationToken);
        }

        var message = update.Message;
        var hasPhoto = message?.Photo is { Count: > 0 };
        var hasAnimation = !string.IsNullOrWhiteSpace(message?.Animation?.FileId);
        var hasDocument = !hasAnimation && !string.IsNullOrWhiteSpace(message?.Document?.FileId);
        var hasText = !string.IsNullOrWhiteSpace(message?.Text) || !string.IsNullOrWhiteSpace(message?.Caption);

        if (message?.Chat is null || (!hasText && !hasPhoto && !hasDocument && !hasAnimation))
        {
            _logger.LogInformation(
                "Telegram update {UpdateId} ignored: no chat or no supported content.",
                update.UpdateId);
            return (true, null, StatusCodes.Status200OK);
        }

        if (!string.IsNullOrWhiteSpace(message.Text))
        {
            var normalizedText = message.Text.Trim();
            if (normalizedText.Equals("/start", StringComparison.OrdinalIgnoreCase)
                || normalizedText.StartsWith("/start ", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogInformation(
                    "Telegram update {UpdateId} ignored /start command for chat {ChatId}",
                    update.UpdateId,
                    message.Chat.Id);
                return (true, null, StatusCodes.Status200OK);
            }
        }

        var integration = await _dbContext.Integrations
            .Include(x => x.Platform)
            .Include(x => x.Credentials)
            .FirstOrDefaultAsync(
                x => x.Id == integrationId
                    && x.IsActive
                    && x.Status == "Connected"
                    && x.Platform.Code == TelegramPlatformCode,
                cancellationToken);

        if (integration is null)
        {
            _logger.LogWarning(
                "Telegram integration {IntegrationId} not found for update {UpdateId}",
                integrationId,
                update.UpdateId);
            return (false, "Telegram integration not found.", StatusCodes.Status404NotFound);
        }

        var externalChatId = message.Chat.Id.ToString();
        var chat = await _dbContext.Chats
            .Include(x => x.Messages)
            .FirstOrDefaultAsync(
                x => x.IntegrationId == integration.Id
                    && x.ExternalChatId == externalChatId,
                cancellationToken);

        var nowUtc = DateTime.UtcNow;
        var messageCreatedAt = message.Date.HasValue
            ? DateTimeOffset.FromUnixTimeSeconds(message.Date.Value).UtcDateTime
            : nowUtc;
        var messageText = !string.IsNullOrWhiteSpace(message.Caption)
            ? message.Caption.Trim()
            : message.Text?.Trim();

        if (chat is null)
        {
            var contact = new Contact
            {
                Id = Guid.NewGuid(),
                IntegrationId = integration.Id,
                ExternalContactId = message.From?.Id.ToString() ?? externalChatId,
                DisplayName = BuildContactDisplayName(message),
                Username = NormalizeUsername(message.From?.Username ?? message.Chat.Username),
                CreatedAt = nowUtc,
                UpdatedAt = nowUtc,
            };

            chat = new Chat
            {
                Id = Guid.NewGuid(),
                IntegrationId = integration.Id,
                ContactId = contact.Id,
                ExternalChatId = externalChatId,
                Title = BuildChatTitle(message),
                Status = "Open",
                CreatedAt = nowUtc,
                UpdatedAt = nowUtc,
                IsArchived = false,
            };

            _dbContext.Contacts.Add(contact);
            _dbContext.Chats.Add(chat);
        }

        var externalMessageId = message.MessageId.ToString();
        var exists = await _dbContext.Messages.AnyAsync(
            x => x.ChatId == chat.Id && x.ExternalMessageId == externalMessageId,
            cancellationToken);

        if (exists)
        {
            _logger.LogInformation(
                "Telegram update {UpdateId} skipped as duplicate message {ExternalMessageId} for chat {ChatId}",
                update.UpdateId,
                externalMessageId,
                chat.Id);
            return (true, null, StatusCodes.Status200OK);
        }

        var incomingMessage = new Message
        {
            Id = Guid.NewGuid(),
            ChatId = chat.Id,
            ExternalMessageId = externalMessageId,
            Text = messageText,
            Direction = "Inbound",
            MessageType = hasPhoto || hasDocument || hasAnimation ? "Attachment" : "Text",
            SenderDisplayName = BuildContactDisplayName(message),
            SentAt = messageCreatedAt,
            IsEdited = false,
            IsDeleted = false,
            CreatedAt = messageCreatedAt,
        };

        if (hasPhoto || hasDocument || hasAnimation)
        {
            var botToken = GetCredentialValue(integration, TelegramBotTokenCredentialType);
            if (!string.IsNullOrWhiteSpace(botToken))
            {
                if (hasPhoto)
                {
                    var largestPhoto = message.Photo!
                        .OrderByDescending(x => x.FileSize ?? 0)
                        .ThenByDescending(x => x.Width * x.Height)
                        .First();

                    var attachment = await SaveTelegramPhotoAttachmentAsync(
                        botToken,
                        largestPhoto,
                        incomingMessage.Id,
                        cancellationToken);

                    if (attachment is not null)
                    {
                        incomingMessage.Attachments.Add(attachment);
                    }
                }

                if (hasDocument && message.Document is not null)
                {
                    var attachment = await SaveTelegramDocumentAttachmentAsync(
                        botToken,
                        message.Document,
                        incomingMessage.Id,
                        cancellationToken);

                    if (attachment is not null)
                    {
                        incomingMessage.Attachments.Add(attachment);
                    }
                }

                if (hasAnimation && message.Animation is not null)
                {
                    var attachment = await SaveTelegramDocumentAttachmentAsync(
                        botToken,
                        message.Animation,
                        incomingMessage.Id,
                        cancellationToken);

                    if (attachment is not null)
                    {
                        incomingMessage.Attachments.Add(attachment);
                    }
                }
            }
        }

        chat.Title = BuildChatTitle(message);
        chat.LastMessageText = ResolveTelegramLastMessageText(message, incomingMessage);
        chat.LastMessageAt = incomingMessage.CreatedAt;
        chat.UnreadCount += 1;
        chat.UpdatedAt = nowUtc;

        integration.LastSyncAt = nowUtc;
        integration.UpdatedAt = nowUtc;

        _dbContext.Messages.Add(incomingMessage);
        await _dbContext.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Telegram message persisted. UpdateId: {UpdateId}, ChatId: {ChatId}, MessageId: {MessageId}, HasPhoto: {HasPhoto}, HasDocument: {HasDocument}, HasAnimation: {HasAnimation}",
            update.UpdateId,
            chat.Id,
            incomingMessage.Id,
            hasPhoto,
            hasDocument,
            hasAnimation);

        return (true, null, StatusCodes.Status200OK);
    }

    private async Task<(bool Success, string? ErrorMessage, int StatusCode)> HandleTelegramMessageReactionAsync(
        Guid integrationId,
        TelegramUpdateDto update,
        CancellationToken cancellationToken)
    {
        var reactionUpdate = update.MessageReaction;
        if (reactionUpdate?.Chat is null)
        {
            _logger.LogInformation(
                "Telegram reaction update {UpdateId} ignored: no chat payload.",
                update.UpdateId);
            return (true, null, StatusCodes.Status200OK);
        }

        var integration = await _dbContext.Integrations
            .Include(x => x.Platform)
            .FirstOrDefaultAsync(
                x => x.Id == integrationId
                    && x.IsActive
                    && x.Status == "Connected"
                    && x.Platform.Code == TelegramPlatformCode,
                cancellationToken);

        if (integration is null)
        {
            _logger.LogWarning(
                "Telegram integration {IntegrationId} not found for reaction update {UpdateId}",
                integrationId,
                update.UpdateId);
            return (false, "Telegram integration not found.", StatusCodes.Status404NotFound);
        }

        var externalChatId = reactionUpdate.Chat.Id.ToString();
        var externalMessageId = reactionUpdate.MessageId.ToString();
        var message = await _dbContext.Messages
            .Include(x => x.Chat)
            .FirstOrDefaultAsync(
                x => x.Chat.IntegrationId == integration.Id
                    && x.Chat.ExternalChatId == externalChatId
                    && x.ExternalMessageId == externalMessageId
                    && !x.IsDeleted,
                cancellationToken);

        if (message is null)
        {
            _logger.LogInformation(
                "Telegram reaction update {UpdateId} ignored: message {ExternalMessageId} was not found for chat {ExternalChatId}.",
                update.UpdateId,
                externalMessageId,
                externalChatId);
            return (true, null, StatusCodes.Status200OK);
        }

        var reaction = ResolveTelegramReactionEmoji(reactionUpdate.NewReaction);
        message.TelegramReaction = reaction;
        integration.LastSyncAt = DateTime.UtcNow;
        integration.UpdatedAt = integration.LastSyncAt;

        await _dbContext.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Telegram reaction update {UpdateId} persisted for message {MessageId}. Reaction={Reaction}",
            update.UpdateId,
            message.Id,
            reaction ?? "none");

        return (true, null, StatusCodes.Status200OK);
    }

    private async Task<ResolvedIntegrationContext> ResolveContextAsync(
        Guid userId,
        bool requireWorkspaceManageAccess,
        CancellationToken cancellationToken)
    {
        var user = await _dbContext.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);

        if (user is null)
        {
            return ResolvedIntegrationContext.Fail("User not found.", StatusCodes.Status404NotFound);
        }

        if (!user.ActiveWorkspaceId.HasValue)
        {
            var personalAccount = await EnsurePersonalAccountAsync(user, cancellationToken);
            return ResolvedIntegrationContext.Personal(user, personalAccount);
        }

        var membership = await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .Include(x => x.Workspace)
            .FirstOrDefaultAsync(
                x => x.UserId == userId
                    && x.WorkspaceId == user.ActiveWorkspaceId.Value
                    && x.IsActive
                    && x.Workspace.IsActive,
                cancellationToken);

        if (membership is null)
        {
            var personalAccount = await EnsurePersonalAccountAsync(user, cancellationToken);
            return ResolvedIntegrationContext.Personal(user, personalAccount);
        }

        if (requireWorkspaceManageAccess && !CanManageWorkspaceIntegrations(membership.Role))
        {
            return ResolvedIntegrationContext.Fail(
                "Only the workspace Owner can manage integrations.",
                StatusCodes.Status403Forbidden);
        }

        return ResolvedIntegrationContext.Workspace(user, membership.WorkspaceId, membership.Role);
    }

    private async Task<PersonalAccount> EnsurePersonalAccountAsync(User user, CancellationToken cancellationToken)
    {
        var personalAccount = await _dbContext.PersonalAccounts.FirstOrDefaultAsync(
            x => x.UserId == user.Id && x.IsActive,
            cancellationToken);

        if (personalAccount is not null)
        {
            return personalAccount;
        }

        personalAccount = new PersonalAccount
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            DisplayName = user.FullName,
            PublicSenderName = user.FullName,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
            IsActive = true
        };

        _dbContext.PersonalAccounts.Add(personalAccount);
        await _dbContext.SaveChangesAsync(cancellationToken);
        return personalAccount;
    }

    private IQueryable<Integration> BuildScopedIntegrationsQuery(ResolvedIntegrationContext resolved)
    {
        return resolved.Scope == "Workspace"
            ? _dbContext.Integrations.Where(x => x.WorkspaceId == resolved.WorkspaceId)
            : _dbContext.Integrations.Where(x => x.PersonalAccountId == resolved.PersonalAccountId);
    }

    private async Task<Integration?> LoadScopedTelegramIntegrationAsync(
        ResolvedIntegrationContext resolved,
        Guid integrationId,
        CancellationToken cancellationToken)
    {
        var query = _dbContext.Integrations
            .Include(x => x.Platform)
            .Include(x => x.Credentials)
            .Where(x => x.Id == integrationId && x.IsActive && x.Platform.Code == TelegramPlatformCode);

        query = resolved.Scope == "Workspace"
            ? query.Where(x => x.WorkspaceId == resolved.WorkspaceId)
            : query.Where(x => x.PersonalAccountId == resolved.PersonalAccountId);

        return await query.FirstOrDefaultAsync(cancellationToken);
    }

    private async Task UpsertCredentialAsync(
        Guid integrationId,
        string credentialType,
        string value,
        CancellationToken cancellationToken,
        IEnumerable<IntegrationCredential>? knownCredentials = null)
    {
        var credential = knownCredentials?.FirstOrDefault(x => x.CredentialType == credentialType)
            ?? await _dbContext.IntegrationCredentials.FirstOrDefaultAsync(
                x => x.IntegrationId == integrationId && x.CredentialType == credentialType,
                cancellationToken);

        if (credential is null)
        {
            credential = new IntegrationCredential
            {
                Id = Guid.NewGuid(),
                IntegrationId = integrationId,
                CredentialType = credentialType,
                ValueEncrypted = value,
                CreatedAt = DateTime.UtcNow,
            };

            _dbContext.IntegrationCredentials.Add(credential);
            return;
        }

        credential.ValueEncrypted = value;
        credential.UpdatedAt = DateTime.UtcNow;
    }

    private static string? GetCredentialValue(Integration integration, string credentialType)
    {
        return integration.Credentials
            .FirstOrDefault(x => x.CredentialType == credentialType)
            ?.ValueEncrypted;
    }

    private static bool CanManageWorkspaceIntegrations(string? role)
    {
        return role == "Owner";
    }

    private static IntegrationAccountDto MapIntegration(Integration integration, ResolvedIntegrationContext context)
    {
        return new IntegrationAccountDto
        {
            Id = integration.Id,
            PlatformCode = integration.Platform.Code,
            PlatformName = integration.Platform.Name,
            DisplayName = integration.DisplayName,
            ExternalAccountId = integration.ExternalAccountId,
            Username = integration.Username,
            Status = integration.Status,
            Scope = context.Scope,
            WorkspaceId = context.WorkspaceId,
            UserId = context.Scope == "Personal" ? context.UserId : null,
            CreatedAt = integration.CreatedAt,
            ConnectedAt = integration.ConnectedAt,
            LastSyncAt = integration.LastSyncAt,
            DisconnectedAt = integration.DisconnectedAt,
            ConnectedByName = integration.ConnectedByUser?.FullName
        };
    }

    private static string BuildContactDisplayName(TelegramMessageDto message)
    {
        if (!string.IsNullOrWhiteSpace(message.Chat?.Title))
        {
            return message.Chat.Title.Trim();
        }

        var firstName = message.From?.FirstName ?? message.Chat?.FirstName;
        var lastName = message.From?.LastName ?? message.Chat?.LastName;
        var fullName = $"{firstName} {lastName}".Trim();
        if (!string.IsNullOrWhiteSpace(fullName))
        {
            return fullName;
        }

        if (!string.IsNullOrWhiteSpace(message.From?.Username))
        {
            return $"@{message.From.Username.TrimStart('@')}";
        }

        if (!string.IsNullOrWhiteSpace(message.Chat?.Username))
        {
            return $"@{message.Chat.Username.TrimStart('@')}";
        }

        return $"Telegram chat {message.Chat?.Id}";
    }

    private static string BuildChatTitle(TelegramMessageDto message)
    {
        return !string.IsNullOrWhiteSpace(message.Chat?.Title)
            ? message.Chat.Title.Trim()
            : BuildContactDisplayName(message);
    }

    private static string? NormalizeUsername(string? username)
    {
        return string.IsNullOrWhiteSpace(username) ? null : $"@{username.Trim().TrimStart('@')}";
    }

    private static string? ResolveTelegramLastMessageText(TelegramMessageDto message, Message incomingMessage)
    {
        if (!string.IsNullOrWhiteSpace(incomingMessage.Text))
        {
            return incomingMessage.Text;
        }

        if (message.Document is not null)
        {
            var fileName = Path.GetFileName(message.Document.FileName?.Trim());
            if (!string.IsNullOrWhiteSpace(fileName))
            {
                return fileName;
            }

            return IsPdfDocument(message.Document.MimeType, fileName)
                ? "PDF received"
                : "File received";
        }

        if (message.Animation is not null)
        {
            return "GIF received";
        }

        if (message.Photo is { Count: > 0 } || incomingMessage.Attachments.Count > 0)
        {
            return "Photo received";
        }

        return null;
    }

    private static string? ResolveTelegramReactionEmoji(IEnumerable<TelegramReactionTypeDto>? reactions)
    {
        return reactions?
            .Where(x => string.Equals(x.Type, "emoji", StringComparison.OrdinalIgnoreCase))
            .Select(x => x.Emoji?.Trim())
            .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x) && x.Length <= 32);
    }

    private static bool IsPdfDocument(string? mimeType, string? fileName)
    {
        return string.Equals(mimeType, "application/pdf", StringComparison.OrdinalIgnoreCase)
            || string.Equals(Path.GetExtension(fileName), ".pdf", StringComparison.OrdinalIgnoreCase);
    }

    private async Task<MessageAttachment?> SaveTelegramPhotoAttachmentAsync(
        string botToken,
        TelegramPhotoSizeDto photo,
        Guid messageId,
        CancellationToken cancellationToken)
    {
        var file = await _telegramService.GetFileAsync(botToken, photo.FileId, cancellationToken);
        if (file is null || string.IsNullOrWhiteSpace(file.FilePath))
        {
            return null;
        }

        var download = await _telegramService.DownloadFileAsync(botToken, file.FilePath, cancellationToken);
        if (download is null)
        {
            return null;
        }

        var extension = Path.GetExtension(file.FilePath);
        if (string.IsNullOrWhiteSpace(extension))
        {
            extension = ".jpg";
        }

        var uploadsRoot = Path.Combine(
            string.IsNullOrWhiteSpace(_environment.WebRootPath)
                ? Path.Combine(_environment.ContentRootPath, "wwwroot")
                : _environment.WebRootPath,
            "uploads",
            "message-attachments");

        Directory.CreateDirectory(uploadsRoot);

        var storedFileName = $"{Guid.NewGuid():N}{extension}";
        var absolutePath = Path.Combine(uploadsRoot, storedFileName);
        await File.WriteAllBytesAsync(absolutePath, download.Value.Content, cancellationToken);

        return new MessageAttachment
        {
            Id = Guid.NewGuid(),
            MessageId = messageId,
            FileName = $"telegram-photo-{photo.FileUniqueId}{extension}",
            FileUrl = $"/uploads/message-attachments/{storedFileName}",
            MimeType = ResolveTelegramPhotoMimeType(download.Value.ContentType, extension),
            FileSize = photo.FileSize ?? download.Value.Content.LongLength,
            CreatedAt = DateTime.UtcNow
        };
    }

    private async Task<MessageAttachment?> SaveTelegramDocumentAttachmentAsync(
        string botToken,
        TelegramDocumentDto document,
        Guid messageId,
        CancellationToken cancellationToken)
    {
        var file = await _telegramService.GetFileAsync(botToken, document.FileId, cancellationToken);
        if (file is null || string.IsNullOrWhiteSpace(file.FilePath))
        {
            return null;
        }

        var download = await _telegramService.DownloadFileAsync(botToken, file.FilePath, cancellationToken);
        if (download is null)
        {
            return null;
        }

        var extension = ResolveTelegramDocumentExtension(
            document.FileName,
            file.FilePath,
            document.MimeType,
            download.Value.ContentType);
        var fileName = ResolveTelegramDocumentFileName(document, file.FilePath, extension);
        var contentType = ResolveTelegramDocumentMimeType(document.MimeType, download.Value.ContentType, fileName);

        var uploadsRoot = Path.Combine(
            string.IsNullOrWhiteSpace(_environment.WebRootPath)
                ? Path.Combine(_environment.ContentRootPath, "wwwroot")
                : _environment.WebRootPath,
            "uploads",
            "message-attachments");

        Directory.CreateDirectory(uploadsRoot);

        var storedFileName = $"{Guid.NewGuid():N}{extension}";
        var absolutePath = Path.Combine(uploadsRoot, storedFileName);
        await File.WriteAllBytesAsync(absolutePath, download.Value.Content, cancellationToken);

        return new MessageAttachment
        {
            Id = Guid.NewGuid(),
            MessageId = messageId,
            FileName = fileName,
            FileUrl = $"/uploads/message-attachments/{storedFileName}",
            MimeType = contentType,
            FileSize = document.FileSize ?? download.Value.Content.LongLength,
            CreatedAt = DateTime.UtcNow
        };
    }

    private static string ResolveTelegramPhotoMimeType(string? contentType, string? extension)
    {
        if (!string.IsNullOrWhiteSpace(contentType)
            && !string.Equals(contentType, "application/octet-stream", StringComparison.OrdinalIgnoreCase))
        {
            return contentType;
        }

        return extension?.ToLowerInvariant() switch
        {
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".webp" => "image/webp",
            ".gif" => "image/gif",
            _ => "image/jpeg"
        };
    }

    private static string ResolveTelegramDocumentFileName(
        TelegramDocumentDto document,
        string? filePath,
        string extension)
    {
        var fileName = Path.GetFileName(document.FileName?.Trim());
        if (string.IsNullOrWhiteSpace(fileName))
        {
            fileName = Path.GetFileName(filePath);
        }

        if (string.IsNullOrWhiteSpace(fileName))
        {
            var uniqueId = SanitizeFileToken(document.FileUniqueId ?? document.FileId);
            fileName = $"telegram-document-{uniqueId}{extension}";
        }
        else if (string.IsNullOrWhiteSpace(Path.GetExtension(fileName)) && extension != ".bin")
        {
            fileName = $"{fileName}{extension}";
        }

        return fileName;
    }

    private static string ResolveTelegramDocumentExtension(
        string? fileName,
        string? filePath,
        string? telegramMimeType,
        string? downloadContentType)
    {
        var extension = Path.GetExtension(fileName);
        if (string.IsNullOrWhiteSpace(extension))
        {
            extension = Path.GetExtension(filePath);
        }

        if (!string.IsNullOrWhiteSpace(extension))
        {
            return extension.ToLowerInvariant();
        }

        return ResolveExtensionFromContentType(telegramMimeType)
            ?? ResolveExtensionFromContentType(downloadContentType)
            ?? ".bin";
    }

    private static string ResolveTelegramDocumentMimeType(
        string? telegramMimeType,
        string? downloadContentType,
        string fileName)
    {
        if (!string.IsNullOrWhiteSpace(telegramMimeType)
            && !string.Equals(telegramMimeType, "application/octet-stream", StringComparison.OrdinalIgnoreCase))
        {
            return telegramMimeType;
        }

        if (!string.IsNullOrWhiteSpace(downloadContentType)
            && !string.Equals(downloadContentType, "application/octet-stream", StringComparison.OrdinalIgnoreCase))
        {
            return downloadContentType;
        }

        return Path.GetExtension(fileName).ToLowerInvariant() switch
        {
            ".pdf" => "application/pdf",
            ".doc" => "application/msword",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xls" => "application/vnd.ms-excel",
            ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".txt" => "text/plain",
            _ => "application/octet-stream"
        };
    }

    private static string? ResolveExtensionFromContentType(string? contentType)
    {
        return contentType?.ToLowerInvariant() switch
        {
            "application/pdf" => ".pdf",
            "application/msword" => ".doc",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document" => ".docx",
            "application/vnd.ms-excel" => ".xls",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" => ".xlsx",
            "text/plain" => ".txt",
            _ => null
        };
    }

    private static string SanitizeFileToken(string value)
    {
        var sanitized = new string(value
            .Where(character => char.IsLetterOrDigit(character) || character is '-' or '_')
            .Take(64)
            .ToArray());

        return string.IsNullOrWhiteSpace(sanitized) ? Guid.NewGuid().ToString("N") : sanitized;
    }

    private sealed record ResolvedIntegrationContext(
        bool IsSuccess,
        string Scope,
        Guid UserId,
        Guid? WorkspaceId,
        Guid? PersonalAccountId,
        string? WorkspaceRole,
        string? ErrorMessage,
        int StatusCode)
    {
        public static ResolvedIntegrationContext Personal(User user, PersonalAccount personalAccount) =>
            new(true, "Personal", user.Id, null, personalAccount.Id, null, null, StatusCodes.Status200OK);

        public static ResolvedIntegrationContext Workspace(User user, Guid workspaceId, string role) =>
            new(true, "Workspace", user.Id, workspaceId, null, role, null, StatusCodes.Status200OK);

        public static ResolvedIntegrationContext Fail(string message, int statusCode) =>
            new(false, string.Empty, Guid.Empty, null, null, null, message, statusCode);
    }
}
