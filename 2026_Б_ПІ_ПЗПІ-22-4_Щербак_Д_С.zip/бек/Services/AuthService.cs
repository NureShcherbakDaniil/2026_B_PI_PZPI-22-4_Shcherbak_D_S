using Dialogly.Api.Data;
using Dialogly.Api.DTOs.Auth;
using Dialogly.Api.DTOs.Users;
using Dialogly.Api.Helpers;
using Dialogly.Api.Interfaces;
using Dialogly.Api.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.IdentityModel.Tokens.Jwt;
using System.Globalization;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Dialogly.Api.Services;

public class AuthService(
    ApplicationDbContext dbContext,
    IJwtService jwtService,
    IEmailService emailService,
    IIpGeolocationService ipGeolocationService) : IAuthService
{
    private const int VerificationCodeLifetimeMinutes = 15;
    private const int ResendCooldownSeconds = 60;
    private const int MaxVerificationAttempts = 5;
    private const string ForgotPasswordNeutralMessage = "If this email exists, we sent a password reset code.";
    private const string ResendPasswordResetNeutralMessage = "If this email exists, we sent a new password reset code.";
    private static readonly Regex PasswordUppercaseRegex = new("[A-Z]", RegexOptions.Compiled);
    private static readonly Regex PasswordLowercaseRegex = new("[a-z]", RegexOptions.Compiled);
    private static readonly Regex PasswordDigitRegex = new("\\d", RegexOptions.Compiled);
    private static readonly Regex PasswordSpecialRegex = new("[^A-Za-z0-9]", RegexOptions.Compiled);

    private readonly ApplicationDbContext _dbContext = dbContext;
    private readonly IJwtService _jwtService = jwtService;
    private readonly IEmailService _emailService = emailService;
    private readonly IIpGeolocationService _ipGeolocationService = ipGeolocationService;
    private readonly PasswordHasher<User> _passwordHasher = new();

    public async Task<(AuthResponseDto? Response, string? ErrorMessage, int StatusCode)> RegisterAsync(RegisterRequestDto request, CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var nowUtc = DateTime.UtcNow;

        var deletedUsersWithEmail = await _dbContext.Users
            .Where(x => x.Email == normalizedEmail && x.IsDeleted)
            .ToListAsync(cancellationToken);

        foreach (var deletedUser in deletedUsersWithEmail)
        {
            AnonymizeDeletedUser(deletedUser, nowUtc);
        }

        if (deletedUsersWithEmail.Count > 0)
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        var exists = await _dbContext.Users.AnyAsync(x => x.Email == normalizedEmail, cancellationToken);
        if (exists)
        {
            return (null, "A user with this email already exists.", StatusCodes.Status409Conflict);
        }

        var user = new User
        {
            Id = Guid.NewGuid(),
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            Email = normalizedEmail,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            IsOnboardingCompleted = false,
            OnboardingWorkspaceChoice = null,
            ActiveWorkspaceId = null,
            CreatedAt = nowUtc,
            IsActive = true,
            EmailConfirmed = false
        };

        var verificationCode = GenerateVerificationCode();

        await using var transaction = await _dbContext.Database.BeginTransactionAsync(cancellationToken);

        try
        {
            TrySetUserOptionalProperties(user, request, nowUtc);

            _dbContext.Users.Add(user);
            await CreateDefaultSettingsIfEntitiesExistAsync(user.Id, nowUtc);
            _dbContext.EmailVerificationCodes.Add(CreateEmailVerificationCode(user, verificationCode, nowUtc));
            await _dbContext.SaveChangesAsync(cancellationToken);

            await _emailService.SendVerificationCodeAsync(normalizedEmail, verificationCode, cancellationToken);

            await transaction.CommitAsync(cancellationToken);
        }
        catch (SmtpException)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Unable to send verification email. Please check SMTP configuration.", StatusCodes.Status502BadGateway);
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("SMTP", StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Unable to send verification email. Please check SMTP configuration.", StatusCodes.Status502BadGateway);
        }

        var response = BuildAuthResponse(user, string.Empty);
        response.Message = "Verification code sent to your email";
        response.RequiresVerification = true;

        return (response, null, StatusCodes.Status200OK);
    }

    public async Task<(AuthResponseDto? Response, string? ErrorMessage, int StatusCode)> LoginAsync(
        LoginRequestDto request,
        string? userAgent,
        string? ipAddress,
        CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();

        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Email == normalizedEmail, cancellationToken);
        if (user is null)
        {
            return (null, "Invalid email or password.", StatusCodes.Status401Unauthorized);
        }

        if (user.IsDeleted || !user.IsActive)
        {
            return (null, "Invalid email or password.", StatusCodes.Status401Unauthorized);
        }

        var verified = VerifyPassword(user, request.Password);
        if (!verified)
        {
            return (null, "Invalid email or password.", StatusCodes.Status401Unauthorized);
        }

        if (!user.EmailConfirmed)
        {
            return (null, "Please verify your email before logging in.", StatusCodes.Status401Unauthorized);
        }

        if (user.TwoFactorEnabled && !string.IsNullOrWhiteSpace(user.TwoFactorSecret))
        {
            return (BuildTwoFactorRequiredResponse(user), null, StatusCodes.Status200OK);
        }

        var response = await BuildLoginSuccessResponseAsync(user, userAgent, ipAddress, cancellationToken);
        return (response, null, StatusCodes.Status200OK);
    }

    public async Task<(EmailVerificationResponseDto? Response, string? ErrorMessage, int StatusCode)> VerifyEmailAsync(
        VerifyEmailRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var code = request.Code.Trim();
        var nowUtc = DateTime.UtcNow;

        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Email == normalizedEmail && x.IsActive, cancellationToken);

        if (user is null)
        {
            return (null, "Code expired or invalid", StatusCodes.Status400BadRequest);
        }

        if (user.EmailConfirmed)
        {
            return (new EmailVerificationResponseDto
            {
                Message = "Email already verified",
                RequiresVerification = false
            }, null, StatusCodes.Status200OK);
        }

        var verificationCode = await _dbContext.EmailVerificationCodes
            .Where(x => x.Email == normalizedEmail && x.UsedAt == null && x.ExpiresAt > nowUtc)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (verificationCode is null)
        {
            return (null, "Code expired or invalid", StatusCodes.Status400BadRequest);
        }

        verificationCode.AttemptsCount += 1;

        if (verificationCode.AttemptsCount > MaxVerificationAttempts)
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
            return (null, "Too many attempts. Please request a new code.", StatusCodes.Status400BadRequest);
        }

        if (!BCrypt.Net.BCrypt.Verify(code, verificationCode.CodeHash))
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        user.EmailConfirmed = true;
        user.UpdatedAt = nowUtc;
        verificationCode.UsedAt = nowUtc;

        var activeCodes = await _dbContext.EmailVerificationCodes
            .Where(x => x.UserId == user.Id && x.Id != verificationCode.Id && x.UsedAt == null)
            .ToListAsync(cancellationToken);

        foreach (var activeCode in activeCodes)
        {
            activeCode.UsedAt = nowUtc;
        }

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new EmailVerificationResponseDto
        {
            Message = "Email verified successfully",
            RequiresVerification = false
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(EmailVerificationResponseDto? Response, string? ErrorMessage, int StatusCode)> ResendVerificationCodeAsync(
        ResendVerificationCodeRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var nowUtc = DateTime.UtcNow;

        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Email == normalizedEmail && x.IsActive, cancellationToken);

        if (user is null)
        {
            return (null, "Code expired or invalid", StatusCodes.Status400BadRequest);
        }

        if (user.EmailConfirmed)
        {
            return (null, "Email already verified", StatusCodes.Status400BadRequest);
        }

        var latestCode = await _dbContext.EmailVerificationCodes
            .Where(x => x.Email == normalizedEmail && x.UsedAt == null)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (latestCode is not null &&
            latestCode.CreatedAt > nowUtc.AddSeconds(-ResendCooldownSeconds))
        {
            return (null, "Please wait before requesting a new code", StatusCodes.Status429TooManyRequests);
        }

        var verificationCode = GenerateVerificationCode();

        _dbContext.EmailVerificationCodes.Add(CreateEmailVerificationCode(user, verificationCode, nowUtc));
        await _dbContext.SaveChangesAsync(cancellationToken);

        await _emailService.SendVerificationCodeAsync(normalizedEmail, verificationCode, cancellationToken);

        return (new EmailVerificationResponseDto
        {
            Message = "New verification code sent",
            RequiresVerification = true
        }, null, StatusCodes.Status200OK);
    }

    public async Task<ForgotPasswordResponseDto> ForgotPasswordAsync(
        ForgotPasswordRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var response = new ForgotPasswordResponseDto
        {
            Message = ForgotPasswordNeutralMessage
        };

        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Email == normalizedEmail && x.IsActive, cancellationToken);

        if (user is null || !user.EmailConfirmed)
        {
            return response;
        }

        var nowUtc = DateTime.UtcNow;
        var resetCode = GenerateVerificationCode();

        await using var transaction = await _dbContext.Database.BeginTransactionAsync(cancellationToken);

        try
        {
            await InvalidateActivePasswordResetCodesAsync(user.Id, nowUtc, cancellationToken);
            _dbContext.PasswordResetCodes.Add(CreatePasswordResetCode(user, resetCode, nowUtc));

            await _dbContext.SaveChangesAsync(cancellationToken);
            await _emailService.SendPasswordResetCodeAsync(normalizedEmail, resetCode, cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch (SmtpException)
        {
            await transaction.RollbackAsync(cancellationToken);
            return response;
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("SMTP", StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return response;
        }

        return response;
    }

    public async Task<(ResetPasswordResponseDto? Response, string? ErrorMessage, int StatusCode)> ResetPasswordAsync(
        ResetPasswordRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var code = request.Code.Trim();
        var nowUtc = DateTime.UtcNow;

        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Email == normalizedEmail && x.IsActive && x.EmailConfirmed, cancellationToken);

        if (user is null)
        {
            return (null, "Code expired or invalid", StatusCodes.Status400BadRequest);
        }

        var resetCode = await _dbContext.PasswordResetCodes
            .Where(x => x.UserId == user.Id && x.Email == normalizedEmail && x.UsedAt == null && x.ExpiresAt > nowUtc)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (resetCode is null)
        {
            return (null, "Code expired or invalid", StatusCodes.Status400BadRequest);
        }

        if (resetCode.AttemptsCount >= MaxVerificationAttempts)
        {
            return (null, "Too many attempts. Please request a new code.", StatusCodes.Status400BadRequest);
        }

        resetCode.AttemptsCount += 1;

        if (!BCrypt.Net.BCrypt.Verify(code, resetCode.CodeHash))
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);
        user.UpdatedAt = nowUtc;
        resetCode.UsedAt = nowUtc;

        await InvalidateActivePasswordResetCodesAsync(user.Id, nowUtc, cancellationToken, resetCode.Id);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new ResetPasswordResponseDto
        {
            Success = true,
            Message = "Password reset successfully. You can now log in."
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(ChangePasswordResponseDto? Response, string? ErrorMessage, int StatusCode)> ChangePasswordAsync(
        Guid userId,
        ChangePasswordRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (!VerifyPassword(user, request.CurrentPassword))
        {
            return (null, "Current password is incorrect", StatusCodes.Status400BadRequest);
        }

        var passwordValidationError = ValidateNewPassword(request.NewPassword, request.ConfirmPassword);
        if (passwordValidationError is not null)
        {
            return (null, passwordValidationError, StatusCodes.Status400BadRequest);
        }

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.NewPassword);
        user.UpdatedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new ChangePasswordResponseDto
        {
            Success = true,
            Message = "Password changed successfully"
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> RequestAccountDeletionCodeAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive && !x.IsDeleted, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (!user.EmailConfirmed)
        {
            return (null, "Please verify your email first", StatusCodes.Status400BadRequest);
        }

        return await CreateAndSendAccountDeletionCodeAsync(
            user,
            "We sent a confirmation code to your email.",
            cancellationToken);
    }

    public async Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> ConfirmAccountDeletionAsync(
        Guid userId,
        DeleteAccountRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var code = request.Code.Trim();
        if (code.Length != 6 || code.Any(static x => !char.IsDigit(x)))
        {
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        var nowUtc = DateTime.UtcNow;
        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive && !x.IsDeleted, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var deletionCode = await _dbContext.AccountDeletionCodes
            .Where(x => x.UserId == userId && x.UsedAt == null && x.ExpiresAt > nowUtc)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (deletionCode is null)
        {
            return (null, "Code expired or invalid", StatusCodes.Status400BadRequest);
        }

        if (deletionCode.AttemptsCount >= MaxVerificationAttempts)
        {
            return (null, "Too many attempts. Please request a new code.", StatusCodes.Status400BadRequest);
        }

        deletionCode.AttemptsCount += 1;

        if (!BCrypt.Net.BCrypt.Verify(code, deletionCode.CodeHash))
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        deletionCode.UsedAt = nowUtc;
        await InvalidateActiveAccountDeletionCodesAsync(user.Id, nowUtc, cancellationToken, deletionCode.Id);

        AnonymizeDeletedUser(user, nowUtc);
        await DeactivatePersonalIntegrationsAsync(user.Id, nowUtc, cancellationToken);

        var activeSessions = await _dbContext.UserSessions
            .Where(x => x.UserId == user.Id && !x.IsRevoked)
            .ToListAsync(cancellationToken);

        foreach (var session in activeSessions)
        {
            session.IsRevoked = true;
        }

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new SessionOperationResponseDto
        {
            Success = true,
            Message = "Your account has been deleted."
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> ResendAccountDeletionCodeAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive && !x.IsDeleted, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (!user.EmailConfirmed)
        {
            return (null, "Please verify your email first", StatusCodes.Status400BadRequest);
        }

        return await CreateAndSendAccountDeletionCodeAsync(
            user,
            "We sent a new confirmation code to your email.",
            cancellationToken);
    }

    public async Task<(ForgotPasswordResponseDto? Response, string? ErrorMessage, int StatusCode)> ResendPasswordResetCodeAsync(
        ResendPasswordResetCodeRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var response = new ForgotPasswordResponseDto
        {
            Message = ResendPasswordResetNeutralMessage
        };

        var user = await _dbContext.Users
            .FirstOrDefaultAsync(x => x.Email == normalizedEmail && x.IsActive, cancellationToken);

        if (user is null || !user.EmailConfirmed)
        {
            return (response, null, StatusCodes.Status200OK);
        }

        var nowUtc = DateTime.UtcNow;
        var latestCode = await _dbContext.PasswordResetCodes
            .Where(x => x.UserId == user.Id)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (latestCode is not null &&
            latestCode.CreatedAt > nowUtc.AddSeconds(-ResendCooldownSeconds))
        {
            return (null, "Please wait before requesting a new code", StatusCodes.Status429TooManyRequests);
        }

        var resetCode = GenerateVerificationCode();

        await using var transaction = await _dbContext.Database.BeginTransactionAsync(cancellationToken);

        try
        {
            await InvalidateActivePasswordResetCodesAsync(user.Id, nowUtc, cancellationToken);
            _dbContext.PasswordResetCodes.Add(CreatePasswordResetCode(user, resetCode, nowUtc));

            await _dbContext.SaveChangesAsync(cancellationToken);
            await _emailService.SendPasswordResetCodeAsync(normalizedEmail, resetCode, cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch (SmtpException)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (response, null, StatusCodes.Status200OK);
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("SMTP", StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (response, null, StatusCodes.Status200OK);
        }

        return (response, null, StatusCodes.Status200OK);
    }

    public async Task<IReadOnlyList<UserSessionDto>> GetActiveSessionsAsync(Guid userId, string? currentSessionJti, CancellationToken cancellationToken = default)
    {
        var sessions = await _dbContext.UserSessions
            .AsNoTracking()
            .Where(x => x.UserId == userId && !x.IsRevoked)
            .OrderByDescending(x => x.LastActiveAt)
            .ToListAsync(cancellationToken);

        return sessions
            .Select(x => new UserSessionDto
            {
                Id = x.Id,
                DeviceName = x.DeviceName,
                OS = x.OS,
                Browser = x.Browser,
                IpAddress = x.IpAddress,
                Location = x.Location,
                LastActiveAt = x.LastActiveAt,
                IsCurrentSession = !string.IsNullOrWhiteSpace(currentSessionJti) &&
                    string.Equals(x.TokenJti, currentSessionJti, StringComparison.Ordinal)
            })
            .ToList();
    }

    public async Task<TwoFactorStatusDto?> GetTwoFactorStatusAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);

        if (user is null)
        {
            return null;
        }

        return new TwoFactorStatusDto
        {
            TwoFactorEnabled = user.TwoFactorEnabled,
            HasSecret = !string.IsNullOrWhiteSpace(user.TwoFactorSecret)
        };
    }

    public async Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> RevokeSessionAsync(
        Guid userId,
        Guid sessionId,
        string? currentSessionJti,
        CancellationToken cancellationToken = default)
    {
        var session = await _dbContext.UserSessions
            .FirstOrDefaultAsync(x => x.Id == sessionId && x.UserId == userId && !x.IsRevoked, cancellationToken);

        if (session is null)
        {
            return (null, "Session not found.", StatusCodes.Status404NotFound);
        }

        if (!string.IsNullOrWhiteSpace(currentSessionJti) &&
            string.Equals(session.TokenJti, currentSessionJti, StringComparison.Ordinal))
        {
            return (null, "Current session cannot be revoked.", StatusCodes.Status400BadRequest);
        }

        session.IsRevoked = true;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new SessionOperationResponseDto
        {
            Success = true,
            Message = "Session revoked"
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(TwoFactorSetupResponseDto? Response, string? ErrorMessage, int StatusCode)> GetTwoFactorSetupAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var secret = TotpHelper.GenerateSecret();
        var otpAuthUri = TotpHelper.BuildOtpAuthUri("Dialogly", user.Email, secret);

        return (new TwoFactorSetupResponseDto
        {
            Secret = secret,
            QrCodeUrl = otpAuthUri
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(TwoFactorOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> ConfirmTwoFactorSetupAsync(
        Guid userId,
        TwoFactorConfirmSetupRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (string.IsNullOrWhiteSpace(request.Secret))
        {
            return (null, "Please set up 2FA first via /api/auth/2fa/setup", StatusCodes.Status400BadRequest);
        }

        if (!TotpHelper.VerifyCode(request.Secret, request.Code, DateTimeOffset.UtcNow))
        {
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        user.TwoFactorSecret = request.Secret.Trim();
        user.TwoFactorEnabled = true;
        user.UpdatedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new TwoFactorOperationResponseDto
        {
            Success = true,
            Message = "Two-factor authentication enabled"
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(TwoFactorOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> EnableTwoFactorAsync(
        Guid userId,
        TwoFactorEnableRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (string.IsNullOrWhiteSpace(user.TwoFactorSecret))
        {
            return (null, "Please set up 2FA first via /api/auth/2fa/setup", StatusCodes.Status400BadRequest);
        }

        if (!TotpHelper.VerifyCode(user.TwoFactorSecret, request.Code, DateTimeOffset.UtcNow))
        {
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        user.TwoFactorEnabled = true;
        user.UpdatedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new TwoFactorOperationResponseDto
        {
            Success = true,
            Message = "Two-factor authentication enabled"
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(TwoFactorOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> DisableTwoFactorAsync(
        Guid userId,
        TwoFactorCodeRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (!user.TwoFactorEnabled || string.IsNullOrWhiteSpace(user.TwoFactorSecret))
        {
            return (null, "Two-factor authentication is not enabled.", StatusCodes.Status400BadRequest);
        }

        if (!TotpHelper.VerifyCode(user.TwoFactorSecret, request.Code, DateTimeOffset.UtcNow))
        {
            return (null, "Invalid code", StatusCodes.Status400BadRequest);
        }

        user.TwoFactorEnabled = false;
        user.UpdatedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new TwoFactorOperationResponseDto
        {
            Success = true,
            Message = "Two-factor authentication disabled"
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(AuthResponseDto? Response, string? ErrorMessage, int StatusCode)> VerifyTwoFactorLoginAsync(
        TwoFactorVerifyRequestDto request,
        string? userAgent,
        string? ipAddress,
        CancellationToken cancellationToken = default)
    {
        if (!_jwtService.TryValidateTwoFactorTempToken(request.TempToken, out var userId, out _))
        {
            return (null, "Invalid or expired authentication challenge.", StatusCodes.Status400BadRequest);
        }

        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null || !user.EmailConfirmed || !user.TwoFactorEnabled || string.IsNullOrWhiteSpace(user.TwoFactorSecret))
        {
            return (null, "Invalid or expired authentication challenge.", StatusCodes.Status400BadRequest);
        }

        if (!TotpHelper.VerifyCode(user.TwoFactorSecret, request.Code, DateTimeOffset.UtcNow))
        {
            return (null, "Invalid verification code.", StatusCodes.Status400BadRequest);
        }

        var response = await BuildLoginSuccessResponseAsync(user, userAgent, ipAddress, cancellationToken);
        return (response, null, StatusCodes.Status200OK);
    }

    public async Task<bool> ValidateActiveSessionAsync(Guid userId, string sessionJti, CancellationToken cancellationToken = default)
    {
        return await _dbContext.UserSessions.AnyAsync(
            x => x.UserId == userId &&
                 x.TokenJti == sessionJti &&
                 !x.IsRevoked &&
                 x.User.IsActive &&
                 !x.User.IsDeleted,
            cancellationToken);
    }

    public async Task TouchActiveSessionAsync(Guid userId, string sessionJti, CancellationToken cancellationToken = default)
    {
        var session = await _dbContext.UserSessions
            .FirstOrDefaultAsync(
                x => x.UserId == userId &&
                     x.TokenJti == sessionJti &&
                     !x.IsRevoked &&
                     x.User.IsActive &&
                     !x.User.IsDeleted,
                cancellationToken);

        if (session is null)
        {
            return;
        }

        var nowUtc = DateTime.UtcNow;
        if ((nowUtc - session.LastActiveAt) < TimeSpan.FromMinutes(1))
        {
            return;
        }

        session.LastActiveAt = nowUtc;
        await _dbContext.SaveChangesAsync(cancellationToken);
    }
    public async Task<CurrentUserDto?> GetCurrentUserAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return null;
        }

        return new CurrentUserDto
        {
            Id = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email,
            EmailConfirmed = user.EmailConfirmed,
            IsOnboardingCompleted = user.IsOnboardingCompleted,
            OnboardingWorkspaceChoice = user.OnboardingWorkspaceChoice,
            IsFirstLogin = !user.IsOnboardingCompleted,
            ActiveWorkspaceId = user.ActiveWorkspaceId,
            PreferredLanguage = GetOptionalPropertyValue(user, "PreferredLanguage", "uk"),
            Theme = GetOptionalPropertyValue(user, "Theme", "system")
        };
    }

    public async Task<CurrentUserSettingsDto> GetCurrentUserSettingsAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        var settings = await EnsureUserSettingsAsync(userId, cancellationToken);

        return new CurrentUserSettingsDto
        {
            IsTourCompleted = settings.IsTourCompleted,
            NotificationsEnabled = settings.NotificationsEnabled,
            SoundEnabled = settings.SoundEnabled,
            LoginAlertsEnabled = settings.LoginAlertsEnabled,
            QuietHoursEnabled = settings.QuietHoursEnabled,
            QuietHoursStart = settings.QuietHoursStart,
            QuietHoursEnd = settings.QuietHoursEnd,
        };
    }

    public async Task<(CurrentUserDto? Response, string? ErrorMessage, int StatusCode)> UpdateCurrentUserProfileAsync(
        Guid userId,
        UpdateCurrentUserProfileRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var firstName = request.FirstName?.Trim() ?? string.Empty;
        var lastName = request.LastName?.Trim() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(firstName))
        {
            return (null, "First name is required.", StatusCodes.Status400BadRequest);
        }

        if (string.IsNullOrWhiteSpace(lastName))
        {
            return (null, "Last name is required.", StatusCodes.Status400BadRequest);
        }

        if (firstName.Length > 40)
        {
            return (null, "First name must be no longer than 40 characters.", StatusCodes.Status400BadRequest);
        }

        if (lastName.Length > 40)
        {
            return (null, "Last name must be no longer than 40 characters.", StatusCodes.Status400BadRequest);
        }

        user.FirstName = firstName;
        user.LastName = lastName;
        user.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);
        return (await GetCurrentUserAsync(userId, cancellationToken), null, StatusCodes.Status200OK);
    }

    public async Task<(CurrentUserSettingsDto? Response, string? ErrorMessage, int StatusCode)> UpdateCurrentUserSettingsAsync(
        Guid userId,
        UpdateCurrentUserSettingsRequestDto request,
        CancellationToken cancellationToken = default)
    {
        if (
            request.IsTourCompleted is null &&
            request.NotificationsEnabled is null &&
            request.SoundEnabled is null &&
            request.LoginAlertsEnabled is null &&
            request.QuietHoursEnabled is null &&
            request.QuietHoursStart is null &&
            request.QuietHoursEnd is null)
        {
            return (null, "At least one settings field must be provided.", StatusCodes.Status400BadRequest);
        }

        if (request.QuietHoursStart is not null && !IsValidTimeValue(request.QuietHoursStart))
        {
            return (null, "Quiet hours start time must use HH:mm format.", StatusCodes.Status400BadRequest);
        }

        if (request.QuietHoursEnd is not null && !IsValidTimeValue(request.QuietHoursEnd))
        {
            return (null, "Quiet hours end time must use HH:mm format.", StatusCodes.Status400BadRequest);
        }

        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var settings = await EnsureUserSettingsAsync(userId, cancellationToken);
        if (request.IsTourCompleted.HasValue)
        {
            settings.IsTourCompleted = request.IsTourCompleted.Value;
        }

        if (request.NotificationsEnabled.HasValue)
        {
            settings.NotificationsEnabled = request.NotificationsEnabled.Value;
        }

        if (request.SoundEnabled.HasValue)
        {
            settings.SoundEnabled = request.SoundEnabled.Value;
        }

        if (request.LoginAlertsEnabled.HasValue)
        {
            settings.LoginAlertsEnabled = request.LoginAlertsEnabled.Value;
        }

        if (request.QuietHoursEnabled.HasValue)
        {
            settings.QuietHoursEnabled = request.QuietHoursEnabled.Value;
        }

        if (request.QuietHoursStart is not null)
        {
            settings.QuietHoursStart = request.QuietHoursStart.Trim();
        }

        if (request.QuietHoursEnd is not null)
        {
            settings.QuietHoursEnd = request.QuietHoursEnd.Trim();
        }

        settings.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new CurrentUserSettingsDto
        {
            IsTourCompleted = settings.IsTourCompleted,
            NotificationsEnabled = settings.NotificationsEnabled,
            SoundEnabled = settings.SoundEnabled,
            LoginAlertsEnabled = settings.LoginAlertsEnabled,
            QuietHoursEnabled = settings.QuietHoursEnabled,
            QuietHoursStart = settings.QuietHoursStart,
            QuietHoursEnd = settings.QuietHoursEnd,
        }, null, StatusCodes.Status200OK);
    }

    public async Task<SecuritySettingsDto> GetSecuritySettingsAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        var settings = await EnsureUserSettingsAsync(userId, cancellationToken);
        var user = await _dbContext.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == userId, cancellationToken);
        var isTwoFactorActuallyEnabled = user is not null &&
            user.TwoFactorEnabled &&
            !string.IsNullOrWhiteSpace(user.TwoFactorSecret);

        return new SecuritySettingsDto
        {
            LoginAlertsEnabled = settings.LoginAlertsEnabled,
            TwoFactorEnabled = isTwoFactorActuallyEnabled
        };
    }

    public async Task<(SecuritySettingsDto? Response, string? ErrorMessage, int StatusCode)> UpdateSecuritySettingsAsync(
        Guid userId,
        UpdateSecuritySettingsRequestDto request,
        CancellationToken cancellationToken = default)
    {
        if (request.LoginAlertsEnabled is null)
        {
            return (null, "At least one settings field must be provided.", StatusCodes.Status400BadRequest);
        }

        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        var settings = await EnsureUserSettingsAsync(userId, cancellationToken);
        settings.LoginAlertsEnabled = request.LoginAlertsEnabled.Value;
        settings.UpdatedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (new SecuritySettingsDto
        {
            LoginAlertsEnabled = settings.LoginAlertsEnabled,
            TwoFactorEnabled = user.TwoFactorEnabled && !string.IsNullOrWhiteSpace(user.TwoFactorSecret)
        }, null, StatusCodes.Status200OK);
    }

    public async Task<CurrentUserDto?> UpdateOnboardingStatusAsync(
        Guid userId,
        bool? completed,
        string? workspaceChoice,
        CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(
            x => x.Id == userId && x.IsActive,
            cancellationToken);

        if (user is null)
        {
            return null;
        }

        if (completed.HasValue)
        {
            user.IsOnboardingCompleted = completed.Value;
        }

        if (workspaceChoice is not null)
        {
            user.OnboardingWorkspaceChoice = workspaceChoice;
        }

        user.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return await GetCurrentUserAsync(userId, cancellationToken);
    }

    public async Task<(CurrentUserDto? Response, string? ErrorMessage, int StatusCode)> UpdateActiveWorkspaceAsync(Guid userId, Guid? workspaceId, CancellationToken cancellationToken = default)
    {
        var user = await _dbContext.Users.FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);
        if (user is null)
        {
            return (null, "User not found.", StatusCodes.Status404NotFound);
        }

        if (workspaceId.HasValue)
        {
            var hasMembership = await _dbContext.WorkspaceMembers.AnyAsync(
                x => x.UserId == userId && x.WorkspaceId == workspaceId.Value && x.IsActive,
                cancellationToken);

            if (!hasMembership)
            {
                return (null, "You do not have access to this workspace.", StatusCodes.Status403Forbidden);
            }
        }

        user.ActiveWorkspaceId = workspaceId;
        user.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (await GetCurrentUserAsync(userId, cancellationToken), null, StatusCodes.Status200OK);
    }

    private AuthResponseDto BuildAuthResponse(User user, string token)
    {
        return new AuthResponseDto
        {
            Token = token,
            User = new AuthUserDto
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                EmailConfirmed = user.EmailConfirmed,
                IsOnboardingCompleted = user.IsOnboardingCompleted,
                OnboardingWorkspaceChoice = user.OnboardingWorkspaceChoice,
                IsFirstLogin = !user.IsOnboardingCompleted,
                ActiveWorkspaceId = user.ActiveWorkspaceId
            }
        };
    }

    private AuthResponseDto BuildTwoFactorRequiredResponse(User user)
    {
        return new AuthResponseDto
        {
            Success = true,
            RequiresTwoFactor = true,
            TempToken = _jwtService.GenerateTwoFactorTempToken(user, user.TwoFactorSecret ?? string.Empty),
            User = new AuthUserDto
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                EmailConfirmed = user.EmailConfirmed,
                IsOnboardingCompleted = user.IsOnboardingCompleted,
                OnboardingWorkspaceChoice = user.OnboardingWorkspaceChoice,
                IsFirstLogin = !user.IsOnboardingCompleted,
                ActiveWorkspaceId = user.ActiveWorkspaceId
            }
        };
    }

    private bool VerifyPassword(User user, string password)
    {
        if (string.IsNullOrWhiteSpace(user.PasswordHash))
        {
            return false;
        }

        if (user.PasswordHash.StartsWith("$2", StringComparison.Ordinal))
        {
            return BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
        }

        var verificationResult = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, password);
        return verificationResult is PasswordVerificationResult.Success or PasswordVerificationResult.SuccessRehashNeeded;
    }

    private static void TrySetUserOptionalProperties(User user, RegisterRequestDto request, DateTime nowUtc)
    {
        TrySetProperty(user, "DateOfBirth", request.DateOfBirth);
        TrySetProperty(user, "IsTermsAccepted", true);
        TrySetProperty(user, "TermsAcceptedAt", nowUtc);
        TrySetProperty(user, "PreferredLanguage", "uk");
        TrySetProperty(user, "Theme", "system");
    }

    private static EmailVerificationCode CreateEmailVerificationCode(User user, string code, DateTime nowUtc)
    {
        return new EmailVerificationCode
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Email = user.Email,
            CodeHash = BCrypt.Net.BCrypt.HashPassword(code),
            CreatedAt = nowUtc,
            ExpiresAt = nowUtc.AddMinutes(VerificationCodeLifetimeMinutes),
            AttemptsCount = 0
        };
    }

    private static PasswordResetCode CreatePasswordResetCode(User user, string code, DateTime nowUtc)
    {
        return new PasswordResetCode
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Email = user.Email,
            CodeHash = BCrypt.Net.BCrypt.HashPassword(code),
            CreatedAt = nowUtc,
            ExpiresAt = nowUtc.AddMinutes(VerificationCodeLifetimeMinutes),
            AttemptsCount = 0
        };
    }

    private static void AnonymizeDeletedUser(User user, DateTime nowUtc)
    {
        user.Email = CreateDeletedAccountEmail(user.Id);
        user.FirstName = "Deleted";
        user.LastName = "User";
        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(
            Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)));
        user.AvatarUrl = null;
        user.TwoFactorEnabled = false;
        user.TwoFactorSecret = null;
        user.ActiveWorkspaceId = null;
        user.OnboardingWorkspaceChoice = null;
        user.IsDeleted = true;
        user.DeletedAt ??= nowUtc;
        user.IsActive = false;
        user.UpdatedAt = nowUtc;
    }

    private async Task DeactivatePersonalIntegrationsAsync(
        Guid userId,
        DateTime nowUtc,
        CancellationToken cancellationToken)
    {
        var integrations = await _dbContext.Integrations
            .Include(x => x.PersonalAccount)
            .Where(x => x.IsActive
                && x.DisconnectedAt == null
                && x.WorkspaceId == null
                && x.PersonalAccount != null
                && x.PersonalAccount.UserId == userId)
            .ToListAsync(cancellationToken);

        foreach (var integration in integrations)
        {
            integration.Status = "Disconnected";
            integration.DisconnectedAt = nowUtc;
            integration.UpdatedAt = nowUtc;
            integration.IsActive = false;
        }
    }

    private static string CreateDeletedAccountEmail(Guid userId)
    {
        return $"deleted-{userId:N}@deleted.dialogly.local";
    }

    private static AccountDeletionCode CreateAccountDeletionCode(User user, string code, DateTime nowUtc)
    {
        return new AccountDeletionCode
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Email = user.Email,
            CodeHash = BCrypt.Net.BCrypt.HashPassword(code),
            CreatedAt = nowUtc,
            ExpiresAt = nowUtc.AddMinutes(VerificationCodeLifetimeMinutes),
            AttemptsCount = 0
        };
    }

    private async Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> CreateAndSendAccountDeletionCodeAsync(
        User user,
        string successMessage,
        CancellationToken cancellationToken)
    {
        var nowUtc = DateTime.UtcNow;
        var latestCode = await _dbContext.AccountDeletionCodes
            .Where(x => x.UserId == user.Id)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (latestCode is not null &&
            latestCode.CreatedAt > nowUtc.AddSeconds(-ResendCooldownSeconds))
        {
            return (null, "Please wait before requesting a new code", StatusCodes.Status429TooManyRequests);
        }

        var deletionCode = GenerateVerificationCode();

        await using var transaction = await _dbContext.Database.BeginTransactionAsync(cancellationToken);

        try
        {
            await InvalidateActiveAccountDeletionCodesAsync(user.Id, nowUtc, cancellationToken);
            _dbContext.AccountDeletionCodes.Add(CreateAccountDeletionCode(user, deletionCode, nowUtc));

            await _dbContext.SaveChangesAsync(cancellationToken);
            await _emailService.SendAccountDeletionCodeAsync(user.Email, deletionCode, cancellationToken);
            await transaction.CommitAsync(cancellationToken);
        }
        catch (SmtpException)
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Unable to send account deletion email. Please check SMTP configuration.", StatusCodes.Status502BadGateway);
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("SMTP", StringComparison.OrdinalIgnoreCase))
        {
            await transaction.RollbackAsync(cancellationToken);
            return (null, "Unable to send account deletion email. Please check SMTP configuration.", StatusCodes.Status502BadGateway);
        }

        return (new SessionOperationResponseDto
        {
            Success = true,
            Message = successMessage
        }, null, StatusCodes.Status200OK);
    }

    private async Task InvalidateActivePasswordResetCodesAsync(
        Guid userId,
        DateTime nowUtc,
        CancellationToken cancellationToken,
        Guid? exceptCodeId = null)
    {
        var activeCodes = await _dbContext.PasswordResetCodes
            .Where(x => x.UserId == userId && x.UsedAt == null && (!exceptCodeId.HasValue || x.Id != exceptCodeId.Value))
            .ToListAsync(cancellationToken);

        foreach (var activeCode in activeCodes)
        {
            activeCode.UsedAt = nowUtc;
        }
    }

    private async Task InvalidateActiveAccountDeletionCodesAsync(
        Guid userId,
        DateTime nowUtc,
        CancellationToken cancellationToken,
        Guid? exceptCodeId = null)
    {
        var activeCodes = await _dbContext.AccountDeletionCodes
            .Where(x => x.UserId == userId && x.UsedAt == null && (!exceptCodeId.HasValue || x.Id != exceptCodeId.Value))
            .ToListAsync(cancellationToken);

        foreach (var activeCode in activeCodes)
        {
            activeCode.UsedAt = nowUtc;
        }
    }

    private static string GenerateVerificationCode()
    {
        return RandomNumberGenerator
            .GetInt32(0, 1_000_000)
            .ToString("D6", CultureInfo.InvariantCulture);
    }

    private async Task CreateDefaultSettingsIfEntitiesExistAsync(Guid userId, DateTime nowUtc)
    {
        AddEntityIfExists("Dialogly.Api.Models.UserAppearanceSettings", new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["UserId"] = userId,
            ["Theme"] = "system",
            ["CreatedAt"] = nowUtc,
            ["SidebarCollapsed"] = false,
            ["AnimationsEnabled"] = true
        });

        AddEntityIfExists("Dialogly.Api.Models.UserLanguageSettings", new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["UserId"] = userId,
            ["LanguageCode"] = "uk",
            ["CreatedAt"] = nowUtc
        });

        AddEntityIfExists("Dialogly.Api.Models.UserNotificationSettings", new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["UserId"] = userId,
            ["EmailEnabled"] = true,
            ["PushEnabled"] = true,
            ["SoundEnabled"] = true,
            ["QuietHoursEnabled"] = false,
            ["CreatedAt"] = nowUtc
        });

        AddEntityIfExists("Dialogly.Api.Models.UserTwoFactorSettings", new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["UserId"] = userId,
            ["IsEnabled"] = false,
            ["CreatedAt"] = nowUtc
        });

        AddEntityIfExists("Dialogly.Api.Models.UserContextPreference", new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["UserId"] = userId,
            ["LastActiveContextType"] = "Personal",
            ["CreatedAt"] = nowUtc
        });

        AddEntityIfExists("Dialogly.Api.Models.UserSettings", new Dictionary<string, object?>
        {
            ["Id"] = Guid.NewGuid(),
            ["UserId"] = userId,
            ["IsTourCompleted"] = false,
            ["LoginAlertsEnabled"] = true,
            ["CreatedAt"] = nowUtc
        });

        await Task.CompletedTask;
    }

    private async Task<UserSettings> EnsureUserSettingsAsync(Guid userId, CancellationToken cancellationToken)
    {
        var settings = await _dbContext.UserSettings.FirstOrDefaultAsync(x => x.UserId == userId, cancellationToken);
        if (settings is not null)
        {
            return settings;
        }

        settings = new UserSettings
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            IsTourCompleted = false,
            NotificationsEnabled = true,
            SoundEnabled = false,
            LoginAlertsEnabled = true,
            QuietHoursEnabled = false,
            QuietHoursStart = "22:00",
            QuietHoursEnd = "08:00",
            CreatedAt = DateTime.UtcNow,
        };

        _dbContext.UserSettings.Add(settings);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return settings;
    }

    private static bool IsValidTimeValue(string value)
    {
        return TimeOnly.TryParseExact(value.Trim(), "HH:mm", out _);
    }

    private async Task<AuthResponseDto> BuildLoginSuccessResponseAsync(
        User user,
        string? userAgent,
        string? ipAddress,
        CancellationToken cancellationToken)
    {
        var sessionJti = Guid.NewGuid().ToString("N");
        await CreateUserSessionAsync(user, sessionJti, userAgent, ipAddress, cancellationToken);
        var token = _jwtService.GenerateToken(user, sessionJti);
        await SendLoginAlertIfEnabledAsync(user, userAgent, ipAddress, cancellationToken);
        return BuildAuthResponse(user, token);
    }

    private async Task CreateUserSessionAsync(
        User user,
        string sessionJti,
        string? userAgent,
        string? ipAddress,
        CancellationToken cancellationToken)
    {
        var nowUtc = DateTime.UtcNow;
        var (deviceName, os, browser) = SessionMetadataHelper.ParseUserAgent(userAgent);
        var normalizedIp = SessionMetadataHelper.NormalizeIpAddress(ipAddress);
        var location = await _ipGeolocationService.ResolveLocationAsync(normalizedIp, cancellationToken);

        _dbContext.UserSessions.Add(new UserSession
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            DeviceName = deviceName,
            OS = os,
            Browser = browser,
            IpAddress = normalizedIp,
            Location = location,
            CreatedAt = nowUtc,
            LastActiveAt = nowUtc,
            IsRevoked = false,
            TokenJti = sessionJti
        });

        await _dbContext.SaveChangesAsync(cancellationToken);
    }

    private async Task SendLoginAlertIfEnabledAsync(
        User user,
        string? userAgent,
        string? ipAddress,
        CancellationToken cancellationToken)
    {
        var settings = await EnsureUserSettingsAsync(user.Id, cancellationToken);
        if (!settings.LoginAlertsEnabled)
        {
            return;
        }

        var (deviceName, _, _) = SessionMetadataHelper.ParseUserAgent(userAgent);
        var location = await _ipGeolocationService.ResolveLocationAsync(ipAddress, cancellationToken);
        await _emailService.SendLoginAlertAsync(user.Email, deviceName, location, DateTimeOffset.UtcNow, cancellationToken);
    }

    private static string? ValidateNewPassword(string newPassword, string confirmPassword)
    {
        if (string.IsNullOrWhiteSpace(newPassword))
        {
            return "New password is required.";
        }

        if (newPassword.Length < 8)
        {
            return "New password must be at least 8 characters.";
        }

        if (!PasswordUppercaseRegex.IsMatch(newPassword))
        {
            return "New password must include an uppercase letter.";
        }

        if (!PasswordLowercaseRegex.IsMatch(newPassword))
        {
            return "New password must include a lowercase letter.";
        }

        if (!PasswordDigitRegex.IsMatch(newPassword))
        {
            return "New password must include a digit.";
        }

        if (!PasswordSpecialRegex.IsMatch(newPassword))
        {
            return "New password must include a special character.";
        }

        if (!string.Equals(newPassword, confirmPassword, StringComparison.Ordinal))
        {
            return "New password and confirmation do not match.";
        }

        return null;
    }

    private void AddEntityIfExists(string fullTypeName, Dictionary<string, object?> values)
    {
        var type = typeof(User).Assembly.GetType(fullTypeName);
        if (type is null)
        {
            return;
        }

        var instance = Activator.CreateInstance(type);
        if (instance is null)
        {
            return;
        }

        foreach (var (key, value) in values)
        {
            TrySetProperty(instance, key, value);
        }

        _dbContext.Add(instance);
    }

    private static void TrySetProperty(object target, string propertyName, object? value)
    {
        var property = target.GetType().GetProperty(propertyName);
        if (property is null || !property.CanWrite)
        {
            return;
        }

        var targetType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
        if (value is null)
        {
            property.SetValue(target, null);
            return;
        }

        if (targetType == typeof(DateTime) && value is DateOnly dateOnly)
        {
            property.SetValue(target, dateOnly.ToDateTime(TimeOnly.MinValue));
            return;
        }

        if (targetType == typeof(DateOnly) && value is DateOnly d)
        {
            property.SetValue(target, d);
            return;
        }

        if (targetType.IsInstanceOfType(value))
        {
            property.SetValue(target, value);
            return;
        }

        try
        {
            var converted = Convert.ChangeType(value, targetType);
            property.SetValue(target, converted);
        }
        catch
        {
            // Intentionally skip optional property if conversion is not possible.
        }
    }

    private static T GetOptionalPropertyValue<T>(User user, string propertyName, T fallback)
    {
        var property = user.GetType().GetProperty(propertyName);
        if (property is null || !property.CanRead)
        {
            return fallback;
        }

        var value = property.GetValue(user);
        if (value is null)
        {
            return fallback;
        }

        if (value is T typed)
        {
            return typed;
        }

        try
        {
            return (T)Convert.ChangeType(value, typeof(T));
        }
        catch
        {
            return fallback;
        }
    }
}
