using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Dialogly.Api.Configuration;
using Dialogly.Api.Data;
using Dialogly.Api.DTOs.Integrations;
using Dialogly.Api.Interfaces;
using Dialogly.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Dialogly.Api.Services;

public class MessengerService(
    ApplicationDbContext dbContext,
    HttpClient httpClient,
    IIntegrationUniquenessService integrationUniquenessService,
    IOptions<MessengerOptions> messengerOptions,
    ILogger<MessengerService> logger) : IMessengerService
{
    private const string MessengerPlatformCode = "messenger";
    private const string MessengerPageAccessTokenCredentialType = "messenger_page_access_token";

    private readonly ApplicationDbContext _dbContext = dbContext;
    private readonly HttpClient _httpClient = httpClient;
    private readonly IIntegrationUniquenessService _integrationUniquenessService = integrationUniquenessService;
    private readonly MessengerOptions _messengerOptions = messengerOptions.Value;
    private readonly ILogger<MessengerService> _logger = logger;
    private readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> ConnectAsync(
        Guid userId,
        ConnectMessengerIntegrationRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var resolved = await ResolveContextAsync(userId, requireWorkspaceManageAccess: true, cancellationToken);
        if (!resolved.IsSuccess)
        {
            return (null, resolved.ErrorMessage, resolved.StatusCode);
        }

        var pageId = request.PageId.Trim();
        var pageAccessToken = request.PageAccessToken.Trim();
        var pageName = request.PageName.Trim();

        if (string.IsNullOrWhiteSpace(pageId) || string.IsNullOrWhiteSpace(pageAccessToken) || string.IsNullOrWhiteSpace(pageName))
        {
            return (null, "Page ID, Page Access Token, and Page Name are required.", StatusCodes.Status400BadRequest);
        }

        var platform = await _dbContext.Platforms.FirstOrDefaultAsync(
            x => x.IsActive && x.Code == MessengerPlatformCode,
            cancellationToken);

        if (platform is null)
        {
            return (null, "Messenger platform is not available.", StatusCodes.Status404NotFound);
        }

        var availability = await _integrationUniquenessService.EnsureIntegrationIsAvailableAsync(
            MessengerPlatformCode,
            pageId,
            userId,
            resolved.WorkspaceId,
            cancellationToken);

        if (!availability.IsAvailable)
        {
            return (null, availability.ErrorMessage, availability.StatusCode);
        }

        var nowUtc = DateTime.UtcNow;
        var integration = availability.ExistingIntegration
            ?? await BuildScopedIntegrationsQuery(resolved)
                .Include(x => x.Platform)
                .Include(x => x.ConnectedByUser)
                .Where(x => x.PlatformId == platform.Id && x.IsActive)
                .OrderByDescending(x => x.UpdatedAt ?? x.CreatedAt)
                .FirstOrDefaultAsync(cancellationToken);

        if (integration is null)
        {
            integration = new Integration
            {
                Id = Guid.NewGuid(),
                PlatformId = platform.Id,
                PersonalAccountId = resolved.PersonalAccountId,
                WorkspaceId = resolved.WorkspaceId,
                CreatedAt = nowUtc,
                IsActive = true
            };

            _dbContext.Integrations.Add(integration);
        }

        integration.ExternalAccountId = pageId;
        integration.DisplayName = pageName;
        integration.Username = pageName;
        integration.Status = "Connected";
        integration.ConnectedByUserId = userId;
        integration.ConnectedAt = nowUtc;
        integration.LastSyncAt = nowUtc;
        integration.DisconnectedAt = null;
        integration.UpdatedAt = nowUtc;
        integration.IsActive = true;
        integration.PersonalAccountId = resolved.PersonalAccountId;
        integration.WorkspaceId = resolved.WorkspaceId;

        await UpsertCredentialAsync(integration.Id, MessengerPageAccessTokenCredentialType, pageAccessToken, cancellationToken);
        await _dbContext.SaveChangesAsync(cancellationToken);

        var response = await _dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.ConnectedByUser)
            .FirstAsync(x => x.Id == integration.Id, cancellationToken);

        return (MapIntegration(response, resolved), null, StatusCodes.Status200OK);
    }

    public async Task<(bool Success, string? ErrorMessage, int StatusCode)> HandleWebhookAsync(
        JsonElement body,
        CancellationToken cancellationToken = default)
    {
        if (!body.TryGetProperty("object", out var objectProperty)
            || !string.Equals(objectProperty.GetString(), "page", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation("Messenger webhook ignored: object is not page.");
            return (true, null, StatusCodes.Status200OK);
        }

        if (!body.TryGetProperty("entry", out var entries) || entries.ValueKind != JsonValueKind.Array)
        {
            _logger.LogInformation("Messenger webhook ignored: no entries.");
            return (true, null, StatusCodes.Status200OK);
        }

        foreach (var entry in entries.EnumerateArray())
        {
            if (!entry.TryGetProperty("messaging", out var messagingArray)
                || messagingArray.ValueKind != JsonValueKind.Array)
            {
                continue;
            }

            foreach (var messagingEvent in messagingArray.EnumerateArray())
            {
                var senderId = GetNestedString(messagingEvent, "sender", "id");
                var recipientId = GetNestedString(messagingEvent, "recipient", "id");
                var text = GetNestedString(messagingEvent, "message", "text");
                var externalMessageId = GetNestedString(messagingEvent, "message", "mid");
                var hasAttachments = TryGetNestedProperty(messagingEvent, out var attachmentsProperty, "message", "attachments")
                    && attachmentsProperty.ValueKind == JsonValueKind.Array
                    && attachmentsProperty.GetArrayLength() > 0;

                _logger.LogInformation(
                    "Messenger webhook received. SenderId={SenderId}, RecipientId={RecipientId}, MessageId={MessageId}, Text={Text}, HasAttachments={HasAttachments}",
                    senderId,
                    recipientId,
                    externalMessageId,
                    text,
                    hasAttachments);

                if (string.IsNullOrWhiteSpace(senderId) || string.IsNullOrWhiteSpace(recipientId) || (string.IsNullOrWhiteSpace(text) && !hasAttachments))
                {
                    continue;
                }

                var integration = await _dbContext.Integrations
                    .Include(x => x.Platform)
                    .Include(x => x.Credentials)
                    .FirstOrDefaultAsync(
                        x => x.IsActive
                            && x.Status == "Connected"
                            && x.Platform.Code == MessengerPlatformCode
                            && x.ExternalAccountId == recipientId,
                        cancellationToken);

                if (integration is null)
                {
                    _logger.LogWarning("Messenger integration not found for page {PageId}.", recipientId);
                    continue;
                }

                var nowUtc = DateTime.UtcNow;
                var messageCreatedAt = messagingEvent.TryGetProperty("timestamp", out var timestampProperty)
                    && timestampProperty.TryGetInt64(out var timestamp)
                        ? DateTimeOffset.FromUnixTimeMilliseconds(timestamp).UtcDateTime
                        : nowUtc;

                var contact = await _dbContext.Contacts.FirstOrDefaultAsync(
                    x => x.IntegrationId == integration.Id && x.ExternalContactId == senderId,
                    cancellationToken);

                if (contact is null)
                {
                    var pageAccessToken = integration.Credentials
                        .FirstOrDefault(x => x.CredentialType == MessengerPageAccessTokenCredentialType)
                        ?.ValueEncrypted;
                    var profileName = await GetProfileNameAsync(senderId, pageAccessToken ?? string.Empty, cancellationToken);

                    contact = new Contact
                    {
                        Id = Guid.NewGuid(),
                        IntegrationId = integration.Id,
                        ExternalContactId = senderId,
                        DisplayName = string.IsNullOrWhiteSpace(profileName)
                            ? BuildContactDisplayName(senderId)
                            : profileName,
                        CreatedAt = nowUtc,
                        UpdatedAt = nowUtc
                    };

                    _dbContext.Contacts.Add(contact);
                }

                var chat = await _dbContext.Chats
                    .Include(x => x.Messages)
                    .FirstOrDefaultAsync(
                        x => x.IntegrationId == integration.Id && x.ExternalChatId == senderId,
                        cancellationToken);

                if (chat is null)
                {
                    chat = new Chat
                    {
                        Id = Guid.NewGuid(),
                        IntegrationId = integration.Id,
                        ContactId = contact.Id,
                        ExternalChatId = senderId,
                        Title = contact.DisplayName,
                        Status = "Open",
                        CreatedAt = nowUtc,
                        UpdatedAt = nowUtc,
                        IsArchived = false
                    };

                    _dbContext.Chats.Add(chat);
                    _logger.LogInformation(
                        "Created Messenger chat {ChatId} for sender {SenderId} and page {PageId}.",
                        chat.Id,
                        senderId,
                        recipientId);
                }

                if (!string.IsNullOrWhiteSpace(externalMessageId))
                {
                    var duplicate = await _dbContext.Messages.AnyAsync(
                        x => x.ChatId == chat.Id && x.ExternalMessageId == externalMessageId,
                        cancellationToken);

                    if (duplicate)
                    {
                        _logger.LogInformation(
                            "Messenger message {ExternalMessageId} skipped as duplicate for chat {ChatId}.",
                            externalMessageId,
                            chat.Id);
                        continue;
                    }
                }

                var incomingMessage = new Message
                {
                    Id = Guid.NewGuid(),
                    ChatId = chat.Id,
                    ExternalMessageId = externalMessageId,
                    Text = string.IsNullOrWhiteSpace(text) ? null : text.Trim(),
                    Direction = "Inbound",
                    MessageType = hasAttachments ? "Attachment" : "Text",
                    SenderDisplayName = contact.DisplayName,
                    SentAt = messageCreatedAt,
                    IsEdited = false,
                    IsDeleted = false,
                    CreatedAt = messageCreatedAt,
                };

                if (hasAttachments)
                {
                    var pageAccessToken = integration.Credentials
                        .FirstOrDefault(x => x.CredentialType == MessengerPageAccessTokenCredentialType)
                        ?.ValueEncrypted;

                    if (!string.IsNullOrWhiteSpace(pageAccessToken))
                    {
                        foreach (var attachmentElement in attachmentsProperty.EnumerateArray())
                        {
                            var attachment = await SaveIncomingAttachmentAsync(
                                attachmentElement,
                                pageAccessToken,
                                incomingMessage.Id,
                                cancellationToken);

                            if (attachment is not null)
                            {
                                incomingMessage.Attachments.Add(attachment);
                            }
                        }
                    }
                }

                chat.Title = contact.DisplayName;
                chat.LastMessageText = ResolveLastMessageText(incomingMessage);
                chat.LastMessageAt = incomingMessage.CreatedAt;
                chat.UnreadCount += 1;
                chat.UpdatedAt = nowUtc;
                integration.LastSyncAt = nowUtc;
                integration.UpdatedAt = nowUtc;
                contact.UpdatedAt = nowUtc;

                _dbContext.Messages.Add(incomingMessage);
                await _dbContext.SaveChangesAsync(cancellationToken);

                _logger.LogInformation(
                    "Messenger message persisted. ChatId={ChatId}, MessageId={MessageId}, SenderId={SenderId}",
                    chat.Id,
                    incomingMessage.Id,
                    senderId);
            }
        }

        return (true, null, StatusCodes.Status200OK);
    }

    public Task<string?> GetProfileNameAsync(
        string psid,
        string pageAccessToken,
        CancellationToken cancellationToken = default)
    {
        return FetchProfileNameAsync(psid, pageAccessToken, cancellationToken);
    }

    public async Task<(string? ExternalMessageId, string? ErrorMessage, int StatusCode)> SendGifAsync(
        string psid,
        string pageAccessToken,
        string gifUrl,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(psid) || string.IsNullOrWhiteSpace(pageAccessToken) || string.IsNullOrWhiteSpace(gifUrl))
        {
            return (null, "Messenger recipient, page token, or GIF URL is missing.", StatusCodes.Status400BadRequest);
        }

        var apiVersion = string.IsNullOrWhiteSpace(_messengerOptions.GraphApiVersion)
            ? "v19.0"
            : _messengerOptions.GraphApiVersion.Trim();
        var requestUri = $"https://graph.facebook.com/{apiVersion}/me/messages?access_token={Uri.EscapeDataString(pageAccessToken)}";

        var payload = JsonSerializer.Serialize(new
        {
            recipient = new { id = psid },
            message = new
            {
                attachment = new
                {
                    type = "image",
                    payload = new
                    {
                        url = gifUrl,
                        is_reusable = false
                    }
                }
            }
        });

        using var request = new HttpRequestMessage(HttpMethod.Post, requestUri)
        {
            Content = new StringContent(payload, Encoding.UTF8, "application/json")
        };
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Messenger send GIF failed. StatusCode={StatusCode}, Response={Response}",
                (int)response.StatusCode,
                responseContent);
            return (null, ExtractMessengerError(responseContent) ?? "Messenger rejected the GIF.", StatusCodes.Status400BadRequest);
        }

        try
        {
            using var json = JsonDocument.Parse(responseContent);
            var messageId = json.RootElement.TryGetProperty("message_id", out var messageIdProperty)
                ? messageIdProperty.GetString()
                : null;

            return (messageId, null, StatusCodes.Status200OK);
        }
        catch (JsonException)
        {
            return (null, null, StatusCodes.Status200OK);
        }
    }

    public async Task<(string? ExternalMessageId, string? ErrorMessage, int StatusCode)> SendAttachmentAsync(
        string psid,
        string pageAccessToken,
        Stream fileStream,
        string fileName,
        string? contentType,
        string? caption,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(psid) || string.IsNullOrWhiteSpace(pageAccessToken))
        {
            return (null, "Messenger recipient or page token is missing.", StatusCodes.Status400BadRequest);
        }

        var attachmentType = ResolveOutgoingAttachmentType(contentType, fileName);
        var apiVersion = string.IsNullOrWhiteSpace(_messengerOptions.GraphApiVersion)
            ? "v19.0"
            : _messengerOptions.GraphApiVersion.Trim();
        var requestUri = $"https://graph.facebook.com/{apiVersion}/me/messages?access_token={Uri.EscapeDataString(pageAccessToken)}";

        var messagePayload = new Dictionary<string, object?>
        {
            ["attachment"] = new Dictionary<string, object?>
            {
                ["type"] = attachmentType,
                ["payload"] = new Dictionary<string, object?>()
            }
        };

        if (!string.IsNullOrWhiteSpace(caption))
        {
            messagePayload["text"] = caption;
        }

        using var formData = new MultipartFormDataContent();
        formData.Add(
            new StringContent(JsonSerializer.Serialize(new { id = psid }), Encoding.UTF8, "application/json"),
            "recipient");
        formData.Add(
            new StringContent(
                JsonSerializer.Serialize(messagePayload, _jsonOptions),
                Encoding.UTF8,
                "application/json"),
            "message");

        using var streamContent = new StreamContent(fileStream);
        streamContent.Headers.ContentType = new MediaTypeHeaderValue(ResolveAttachmentMimeType(contentType, fileName, attachmentType));
        formData.Add(streamContent, "filedata", Path.GetFileName(fileName));

        using var response = await _httpClient.PostAsync(requestUri, formData, cancellationToken);
        var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Messenger send attachment failed. StatusCode={StatusCode}, FileName={FileName}, ContentType={ContentType}, Response={Response}",
                (int)response.StatusCode,
                fileName,
                contentType,
                responseContent);
            return (null, ExtractMessengerError(responseContent) ?? "Messenger rejected the attachment.", StatusCodes.Status400BadRequest);
        }

        try
        {
            using var json = JsonDocument.Parse(responseContent);
            var messageId = json.RootElement.TryGetProperty("message_id", out var messageIdProperty)
                ? messageIdProperty.GetString()
                : null;

            return (messageId, null, StatusCodes.Status200OK);
        }
        catch (JsonException)
        {
            return (null, null, StatusCodes.Status200OK);
        }
    }

    public async Task<(string? ExternalMessageId, string? ErrorMessage, int StatusCode)> SendTextMessageAsync(
        string psid,
        string pageAccessToken,
        string text,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(psid) || string.IsNullOrWhiteSpace(pageAccessToken))
        {
            return (null, "Messenger recipient or page token is missing.", StatusCodes.Status400BadRequest);
        }

        var apiVersion = string.IsNullOrWhiteSpace(_messengerOptions.GraphApiVersion)
            ? "v19.0"
            : _messengerOptions.GraphApiVersion.Trim();
        var requestUri = $"https://graph.facebook.com/{apiVersion}/me/messages?access_token={Uri.EscapeDataString(pageAccessToken)}";

        var payload = JsonSerializer.Serialize(new
        {
            recipient = new { id = psid },
            message = new { text }
        });

        using var request = new HttpRequestMessage(HttpMethod.Post, requestUri)
        {
            Content = new StringContent(payload, Encoding.UTF8, "application/json")
        };
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Messenger send failed. StatusCode={StatusCode}, Response={Response}",
                (int)response.StatusCode,
                responseContent);
            return (null, ExtractMessengerError(responseContent) ?? "Messenger rejected the message.", StatusCodes.Status400BadRequest);
        }

        try
        {
            using var json = JsonDocument.Parse(responseContent);
            var messageId = json.RootElement.TryGetProperty("message_id", out var messageIdProperty)
                ? messageIdProperty.GetString()
                : null;

            return (messageId, null, StatusCodes.Status200OK);
        }
        catch (JsonException)
        {
            return (null, null, StatusCodes.Status200OK);
        }
    }

    private async Task<ResolvedIntegrationContext> ResolveContextAsync(
        Guid userId,
        bool requireWorkspaceManageAccess,
        CancellationToken cancellationToken)
    {
        var user = await _dbContext.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);

        if (user is null)
        {
            return ResolvedIntegrationContext.Fail("User not found.", StatusCodes.Status404NotFound);
        }

        if (!user.ActiveWorkspaceId.HasValue)
        {
            var personalAccountId = await EnsurePersonalAccountAsync(userId, cancellationToken);
            return ResolvedIntegrationContext.Personal(userId, personalAccountId);
        }

        var membership = await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.WorkspaceId == user.ActiveWorkspaceId.Value
                    && x.UserId == userId
                    && x.IsActive,
                cancellationToken);

        if (membership is null)
        {
            return ResolvedIntegrationContext.Fail("You do not have access to the active workspace.", StatusCodes.Status403Forbidden);
        }

        if (requireWorkspaceManageAccess && !CanManageWorkspaceIntegrations(membership.Role))
        {
            return ResolvedIntegrationContext.Fail("Only the workspace Owner can manage integrations.", StatusCodes.Status403Forbidden);
        }

        return ResolvedIntegrationContext.Workspace(userId, membership.WorkspaceId, membership.Role);
    }

    private async Task<Guid> EnsurePersonalAccountAsync(Guid userId, CancellationToken cancellationToken)
    {
        var existingId = await _dbContext.PersonalAccounts
            .Where(x => x.UserId == userId && x.IsActive)
            .Select(x => (Guid?)x.Id)
            .FirstOrDefaultAsync(cancellationToken);

        if (existingId.HasValue)
        {
            return existingId.Value;
        }

        var user = await _dbContext.Users.FirstAsync(x => x.Id == userId, cancellationToken);
        var nowUtc = DateTime.UtcNow;
        var displayName = $"{user.FirstName} {user.LastName}".Trim();
        if (string.IsNullOrWhiteSpace(displayName))
        {
            displayName = user.Email;
        }

        var personalAccount = new PersonalAccount
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            DisplayName = displayName,
            PublicSenderName = displayName,
            CreatedAt = nowUtc,
            UpdatedAt = nowUtc,
            IsActive = true
        };

        _dbContext.PersonalAccounts.Add(personalAccount);
        await _dbContext.SaveChangesAsync(cancellationToken);
        return personalAccount.Id;
    }

    private IQueryable<Integration> BuildScopedIntegrationsQuery(ResolvedIntegrationContext context)
    {
        var query = _dbContext.Integrations.AsQueryable();
        return context.Scope == "Workspace"
            ? query.Where(x => x.WorkspaceId == context.WorkspaceId)
            : query.Where(x => x.PersonalAccountId == context.PersonalAccountId);
    }

    private async Task UpsertCredentialAsync(
        Guid integrationId,
        string credentialType,
        string value,
        CancellationToken cancellationToken)
    {
        var credential = await _dbContext.IntegrationCredentials
            .FirstOrDefaultAsync(
                x => x.IntegrationId == integrationId
                    && x.CredentialType == credentialType,
                cancellationToken);

        if (credential is null)
        {
            credential = new IntegrationCredential
            {
                Id = Guid.NewGuid(),
                IntegrationId = integrationId,
                CredentialType = credentialType,
                ValueEncrypted = value,
                CreatedAt = DateTime.UtcNow
            };

            _dbContext.IntegrationCredentials.Add(credential);
        }
        else
        {
            credential.ValueEncrypted = value;
            credential.UpdatedAt = DateTime.UtcNow;
        }
    }

    private static bool CanManageWorkspaceIntegrations(string? role)
    {
        return string.Equals(role, "Owner", StringComparison.OrdinalIgnoreCase);
    }

    private static IntegrationAccountDto MapIntegration(Integration integration, ResolvedIntegrationContext context)
    {
        return new IntegrationAccountDto
        {
            Id = integration.Id,
            PlatformCode = integration.Platform.Code,
            PlatformName = integration.Platform.Name,
            DisplayName = integration.DisplayName,
            ExternalAccountId = integration.ExternalAccountId,
            Username = integration.Username,
            Status = integration.Status,
            Scope = context.Scope,
            WorkspaceId = integration.WorkspaceId,
            UserId = context.UserId,
            CreatedAt = integration.CreatedAt,
            ConnectedAt = integration.ConnectedAt,
            LastSyncAt = integration.LastSyncAt,
            DisconnectedAt = integration.DisconnectedAt,
            ConnectedByName = integration.ConnectedByUser is null
                ? null
                : $"{integration.ConnectedByUser.FirstName} {integration.ConnectedByUser.LastName}".Trim()
        };
    }

    private static string? GetNestedString(JsonElement element, string propertyName, string nestedPropertyName)
    {
        return TryGetNestedProperty(element, out var property, propertyName, nestedPropertyName)
            ? property.GetString()
            : null;
    }

    private static bool TryGetNestedProperty(JsonElement element, out JsonElement property, params string[] path)
    {
        property = element;

        foreach (var segment in path)
        {
            if (property.ValueKind != JsonValueKind.Object || !property.TryGetProperty(segment, out property))
            {
                property = default;
                return false;
            }
        }

        return true;
    }

    private static string BuildContactDisplayName(string senderId)
    {
        var suffix = senderId.Length <= 6 ? senderId : senderId[^6..];
        return $"Messenger user {suffix}";
    }

    private async Task<string?> FetchProfileNameAsync(
        string psid,
        string? pageAccessToken,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(psid) || string.IsNullOrWhiteSpace(pageAccessToken))
        {
            return null;
        }

        var apiVersion = string.IsNullOrWhiteSpace(_messengerOptions.GraphApiVersion)
            ? "v19.0"
            : _messengerOptions.GraphApiVersion.Trim();
        var requestUri =
            $"https://graph.facebook.com/{apiVersion}/{Uri.EscapeDataString(psid)}?fields=name&access_token={Uri.EscapeDataString(pageAccessToken)}";

        using var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Messenger profile lookup failed. SenderId={SenderId}, StatusCode={StatusCode}, Response={Response}",
                psid,
                (int)response.StatusCode,
                responseContent);
            return null;
        }

        try
        {
            using var json = JsonDocument.Parse(responseContent);
            if (json.RootElement.TryGetProperty("name", out var nameProperty))
            {
                var name = nameProperty.GetString()?.Trim();
                return string.IsNullOrWhiteSpace(name) ? null : name;
            }
        }
        catch (JsonException)
        {
            _logger.LogWarning(
                "Messenger profile lookup returned malformed JSON for sender {SenderId}.",
                psid);
        }

        return null;
    }

    private static string? ExtractMessengerError(string responseContent)
    {
        if (string.IsNullOrWhiteSpace(responseContent))
        {
            return null;
        }

        try
        {
            using var json = JsonDocument.Parse(responseContent);
            if (json.RootElement.TryGetProperty("error", out var error)
                && error.TryGetProperty("message", out var message))
            {
                return message.GetString();
            }
        }
        catch (JsonException)
        {
            // Ignore malformed error bodies and fall back to a generic message.
        }

        return null;
    }

    private async Task<MessageAttachment?> SaveIncomingAttachmentAsync(
        JsonElement attachmentElement,
        string pageAccessToken,
        Guid messageId,
        CancellationToken cancellationToken)
    {
        var type = attachmentElement.TryGetProperty("type", out var typeProperty)
            ? typeProperty.GetString()?.Trim().ToLowerInvariant()
            : null;
        var url = GetNestedString(attachmentElement, "payload", "url");

        if (string.IsNullOrWhiteSpace(type) || string.IsNullOrWhiteSpace(url))
        {
            return null;
        }

        if (type is "audio" or "video")
        {
            return null;
        }

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("*/*"));
            using var response = await _httpClient.SendAsync(request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning(
                    "Messenger attachment download failed. AttachmentType={AttachmentType}, Url={AttachmentUrl}, StatusCode={StatusCode}",
                    type,
                    url,
                    (int)response.StatusCode);
                return null;
            }

            var content = await response.Content.ReadAsByteArrayAsync(cancellationToken);
            var responseContentType = response.Content.Headers.ContentType?.MediaType;
            var fileName = ResolveIncomingAttachmentFileName(type, url);
            var contentType = ResolveIncomingAttachmentContentType(type, url, responseContentType);
            var extension = Path.GetExtension(fileName);

            var uploadsRoot = GetAttachmentUploadsRoot();
            Directory.CreateDirectory(uploadsRoot);

            var storedFileName = $"{Guid.NewGuid():N}{extension}";
            var absolutePath = Path.Combine(uploadsRoot, storedFileName);
            await File.WriteAllBytesAsync(absolutePath, content, cancellationToken);

            return new MessageAttachment
            {
                Id = Guid.NewGuid(),
                MessageId = messageId,
                FileName = fileName,
                FileUrl = $"/uploads/message-attachments/{storedFileName}",
                MimeType = contentType,
                FileSize = content.LongLength,
                CreatedAt = DateTime.UtcNow
            };
        }
        catch (Exception exception)
        {
            _logger.LogWarning(
                exception,
                "Messenger attachment download threw an exception. AttachmentType={AttachmentType}, Url={AttachmentUrl}",
                type,
                url);
            return null;
        }
    }

    private string GetAttachmentUploadsRoot()
    {
        var currentDirectory = Directory.GetCurrentDirectory();
        return Path.Combine(currentDirectory, "wwwroot", "uploads", "message-attachments");
    }

    private static string ResolveIncomingAttachmentFileName(string type, string url)
    {
        var parsedUrl = Uri.TryCreate(url, UriKind.Absolute, out var uri) ? uri : null;
        var fromPath = parsedUrl is null ? null : Path.GetFileName(parsedUrl.LocalPath);
        var fileName = Path.GetFileName(fromPath);

        if (!string.IsNullOrWhiteSpace(fileName))
        {
            return fileName;
        }

        return type switch
        {
            "image" => "image.jpg",
            "file" => "file.bin",
            _ => "attachment.bin"
        };
    }

    private static string ResolveIncomingAttachmentContentType(string type, string url, string? responseContentType)
    {
        if (!string.IsNullOrWhiteSpace(responseContentType)
            && !string.Equals(responseContentType, "application/octet-stream", StringComparison.OrdinalIgnoreCase))
        {
            return responseContentType;
        }

        var extension = Path.GetExtension(ResolveIncomingAttachmentFileName(type, url)).ToLowerInvariant();
        return extension switch
        {
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".webp" => "image/webp",
            ".gif" => "image/gif",
            ".pdf" => "application/pdf",
            ".txt" => "text/plain",
            ".doc" => "application/msword",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            _ when type == "image" => "image/jpeg",
            _ => "application/octet-stream"
        };
    }

    private static string ResolveOutgoingAttachmentType(string? contentType, string fileName)
    {
        var normalizedContentType = contentType?.Trim() ?? string.Empty;
        if (normalizedContentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
        {
            return "image";
        }

        var extension = Path.GetExtension(fileName).ToLowerInvariant();
        return extension is ".jpg" or ".jpeg" or ".png" or ".webp" or ".gif"
            ? "image"
            : "file";
    }

    private static string ResolveAttachmentMimeType(string? contentType, string fileName, string attachmentType)
    {
        if (!string.IsNullOrWhiteSpace(contentType)
            && !string.Equals(contentType, "application/octet-stream", StringComparison.OrdinalIgnoreCase))
        {
            return contentType;
        }

        var extension = Path.GetExtension(fileName).ToLowerInvariant();
        return extension switch
        {
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".webp" => "image/webp",
            ".gif" => "image/gif",
            ".pdf" => "application/pdf",
            ".doc" => "application/msword",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            _ when attachmentType == "image" => "image/jpeg",
            _ => "application/octet-stream"
        };
    }

    private static string? ResolveLastMessageText(Message message)
    {
        if (!string.IsNullOrWhiteSpace(message.Text))
        {
            return message.Text;
        }

        var firstAttachment = message.Attachments.FirstOrDefault();
        if (firstAttachment is null)
        {
            return null;
        }

        if (!string.IsNullOrWhiteSpace(firstAttachment.MimeType)
            && firstAttachment.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
        {
            return "Image received";
        }

        return Path.GetFileName(firstAttachment.FileName);
    }

    private sealed record ResolvedIntegrationContext(
        bool IsSuccess,
        string Scope,
        Guid UserId,
        Guid? WorkspaceId,
        Guid? PersonalAccountId,
        string? Role,
        string? ErrorMessage,
        int StatusCode)
    {
        public static ResolvedIntegrationContext Personal(Guid userId, Guid personalAccountId) =>
            new(true, "Personal", userId, null, personalAccountId, null, null, StatusCodes.Status200OK);

        public static ResolvedIntegrationContext Workspace(Guid userId, Guid workspaceId, string? role) =>
            new(true, "Workspace", userId, workspaceId, null, role, null, StatusCodes.Status200OK);

        public static ResolvedIntegrationContext Fail(string message, int statusCode) =>
            new(false, string.Empty, Guid.Empty, null, null, null, message, statusCode);
    }
}
