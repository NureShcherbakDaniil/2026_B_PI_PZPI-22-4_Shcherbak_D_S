using Dialogly.Api.Data;
using Dialogly.Api.Dtos.Chats;
using Dialogly.Api.Interfaces;
using Dialogly.Api.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Dialogly.Api.Services;

public class ChatService(
    ApplicationDbContext dbContext,
    IMessengerService messengerService,
    ITelegramService telegramService,
    IWebHostEnvironment environment,
    ILogger<ChatService> logger) : IChatService
{
    private static readonly HashSet<string> AllowedPlatformCodes = ["telegram", "messenger"];
    private const string MessengerPlatformCode = "messenger";
    private const string MessengerPageAccessTokenCredentialType = "messenger_page_access_token";
    private const string TelegramPlatformCode = "telegram";
    private const string TelegramBotTokenCredentialType = "telegram_bot_token";
    private static readonly HashSet<string> AllowedReactions = new(StringComparer.Ordinal)
    {
        "\U0001F44D",
        "\u2764\uFE0F",
        "\U0001F601",
        "\U0001F62F",
        "\U0001F622"
    };

    private readonly ApplicationDbContext _dbContext = dbContext;
    private readonly IMessengerService _messengerService = messengerService;
    private readonly ITelegramService _telegramService = telegramService;
    private readonly IWebHostEnvironment _environment = environment;
    private readonly ILogger<ChatService> _logger = logger;

    public async Task<(IReadOnlyList<ChatListItemDto> Response, string? ErrorMessage, int StatusCode)> GetChatsAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        var context = await ResolveContextAsync(userId, cancellationToken);
        if (!context.IsSuccess)
        {
            return ([], context.ErrorMessage, context.StatusCode);
        }

        var chats = await ApplyScope(
                _dbContext.Chats
                    .AsNoTracking()
                    .Include(x => x.Contact)
                    .Include(x => x.Integration)
                        .ThenInclude(x => x.Platform)
                    .Include(x => x.Messages)
                        .ThenInclude(x => x.Reads),
                context)
            .Where(x => !x.IsArchived && x.Integration.IsActive && AllowedPlatformCodes.Contains(x.Integration.Platform.Code))
            .OrderByDescending(x => x.IsPinned)
            .ThenByDescending(x => x.LastMessageAt ?? x.CreatedAt)
            .ToListAsync(cancellationToken);

        return (chats.Select(x => MapChatListItem(x, userId)).ToList(), null, StatusCodes.Status200OK);
    }

    public async Task<(IReadOnlyList<ChatListItemDto> Response, string? ErrorMessage, int StatusCode)> GetArchivedChatsAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        var context = await ResolveContextAsync(userId, cancellationToken);
        if (!context.IsSuccess)
        {
            return ([], context.ErrorMessage, context.StatusCode);
        }

        var chats = await ApplyScope(
                _dbContext.Chats
                    .AsNoTracking()
                    .Include(x => x.Contact)
                    .Include(x => x.Integration)
                        .ThenInclude(x => x.Platform)
                    .Include(x => x.Messages)
                        .ThenInclude(x => x.Reads),
                context)
            .Where(x => x.IsArchived && x.Integration.IsActive && AllowedPlatformCodes.Contains(x.Integration.Platform.Code))
            .OrderByDescending(x => x.IsPinned)
            .ThenByDescending(x => x.LastMessageAt ?? x.CreatedAt)
            .ToListAsync(cancellationToken);

        return (chats.Select(x => MapChatListItem(x, userId)).ToList(), null, StatusCodes.Status200OK);
    }

    public async Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> GetChatAsync(
        Guid userId,
        Guid chatId,
        CancellationToken cancellationToken = default)
    {
        var (chat, errorMessage, statusCode) = await LoadAccessibleChatAsync(userId, chatId, cancellationToken);
        if (chat is null)
        {
            return (null, errorMessage, statusCode);
        }

        return (MapChatDetails(chat, userId), null, StatusCodes.Status200OK);
    }

    public async Task<(IReadOnlyList<MessageDto> Response, string? ErrorMessage, int StatusCode)> GetChatMessagesAsync(
        Guid userId,
        Guid chatId,
        CancellationToken cancellationToken = default)
    {
        var (chat, errorMessage, statusCode) = await LoadAccessibleChatAsync(userId, chatId, cancellationToken);
        if (chat is null)
        {
            return ([], errorMessage, statusCode);
        }

        var messages = await _dbContext.Messages
            .AsNoTracking()
            .Include(x => x.Reads)
            .Include(x => x.Attachments)
            .Include(x => x.CreatedByUser)
            .Where(x => x.ChatId == chat.Id && !x.IsDeleted)
            .OrderBy(x => x.CreatedAt)
            .ToListAsync(cancellationToken);

        return (messages.Select(x => MapMessage(x, userId)).ToList(), null, StatusCodes.Status200OK);
    }

    public async Task<(AttachmentContentDto? Response, string? ErrorMessage, int StatusCode)> GetAttachmentAsync(
        Guid userId,
        Guid attachmentId,
        CancellationToken cancellationToken = default)
    {
        var context = await ResolveContextAsync(userId, cancellationToken);
        if (!context.IsSuccess)
        {
            return (null, context.ErrorMessage, context.StatusCode);
        }

        var attachment = await _dbContext.MessageAttachments
            .AsNoTracking()
            .Include(x => x.Message)
                .ThenInclude(x => x.Chat)
                    .ThenInclude(x => x.Integration)
            .FirstOrDefaultAsync(x => x.Id == attachmentId, cancellationToken);

        if (attachment is null)
        {
            return (null, "Attachment not found.", StatusCodes.Status404NotFound);
        }

        var hasAccess = context.Scope == "Workspace"
            ? attachment.Message.Chat.Integration.WorkspaceId == context.WorkspaceId
            : attachment.Message.Chat.Integration.PersonalAccountId == context.PersonalAccountId;

        if (!hasAccess)
        {
            return (null, "Attachment not found.", StatusCodes.Status404NotFound);
        }

        var relativePath = attachment.FileUrl.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
        var webRoot = string.IsNullOrWhiteSpace(_environment.WebRootPath)
            ? Path.Combine(_environment.ContentRootPath, "wwwroot")
            : _environment.WebRootPath;
        var absolutePath = Path.Combine(webRoot, relativePath);

        if (!File.Exists(absolutePath))
        {
            return (null, "Attachment file not found.", StatusCodes.Status404NotFound);
        }

        var content = await File.ReadAllBytesAsync(absolutePath, cancellationToken);
        return (new AttachmentContentDto
        {
            FileName = attachment.FileName,
            ContentType = ResolveAttachmentContentType(attachment.MimeType, attachment.FileName),
            Content = content
        }, null, StatusCodes.Status200OK);
    }

    public async Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> UpdateChatCustomDetailsAsync(
        Guid userId,
        Guid chatId,
        UpdateChatCustomDetailsRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var (chat, errorMessage, statusCode) = await LoadAccessibleChatAsync(userId, chatId, cancellationToken);
        if (chat is null)
        {
            return (null, errorMessage, statusCode);
        }

        if (request.CustomName is not null)
        {
            chat.CustomName = NormalizeOptionalValue(request.CustomName, 255);
        }

        if (request.Notes is not null)
        {
            chat.Notes = NormalizeOptionalValue(request.Notes, 2000);
        }
        if (request.IsPinned.HasValue)
        {
            chat.IsPinned = request.IsPinned.Value;
        }

        if (request.IsArchived.HasValue)
        {
            chat.IsArchived = request.IsArchived.Value;
        }

        chat.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapChatDetails(chat, userId), null, StatusCodes.Status200OK);
    }

    public async Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> UpdateChatArchiveAsync(
        Guid userId,
        Guid chatId,
        UpdateChatArchiveRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var (chat, errorMessage, statusCode) = await LoadAccessibleChatAsync(userId, chatId, cancellationToken);
        if (chat is null)
        {
            return (null, errorMessage, statusCode);
        }

        chat.IsArchived = request.IsArchived;
        chat.UpdatedAt = DateTime.UtcNow;

        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapChatDetails(chat, userId), null, StatusCodes.Status200OK);
    }

    public async Task<(MessageDto? Response, string? ErrorMessage, int StatusCode)> SendMessageAsync(
        Guid userId,
        Guid chatId,
        SendMessageRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var trimmedText = request.Text?.Trim();
        var trimmedGifUrl = request.GifUrl?.Trim();
        var attachments = request.Attachments ?? [];

        if (string.IsNullOrWhiteSpace(trimmedText) && string.IsNullOrWhiteSpace(trimmedGifUrl) && attachments.Count == 0)
        {
            return (null, "Message text or attachment is required.", StatusCodes.Status400BadRequest);
        }

        var (chat, errorMessage, statusCode) = await LoadAccessibleChatAsync(userId, chatId, cancellationToken);
        if (chat is null)
        {
            return (null, errorMessage, statusCode);
        }

        var integration = await _dbContext.Integrations
            .AsNoTracking()
            .Include(x => x.Platform)
            .Include(x => x.Credentials)
            .FirstOrDefaultAsync(x => x.Id == chat.IntegrationId, cancellationToken);

        if (integration is null)
        {
            return (null, "Integration not found for this chat.", StatusCodes.Status404NotFound);
        }

        var nowUtc = DateTime.UtcNow;
        var senderName = await _dbContext.Users
            .Where(x => x.Id == userId)
            .Select(x => (x.FirstName + " " + x.LastName).Trim())
            .FirstOrDefaultAsync(cancellationToken);

        string? externalMessageId = null;
        var savedAttachmentEntries = new List<SavedAttachmentEntry>();
        foreach (var attachment in attachments.Where(x => x.Length > 0))
        {
            savedAttachmentEntries.Add(await SaveUploadedAttachmentAsync(attachment, cancellationToken));
        }

        var savedAttachments = savedAttachmentEntries.Select(x => x.Attachment).ToList();
        var fallbackAttachmentText = attachments.Count > 0
            ? $"Sent {attachments.Count} attachment"
            : null;

        if (!string.IsNullOrWhiteSpace(trimmedGifUrl))
        {
            if (string.Equals(integration.Platform.Code, TelegramPlatformCode, StringComparison.OrdinalIgnoreCase))
            {
                var botToken = integration.Credentials
                    .FirstOrDefault(x => x.CredentialType == TelegramBotTokenCredentialType)
                    ?.ValueEncrypted;

                if (!string.IsNullOrWhiteSpace(botToken))
                {
                    var telegramResult = await _telegramService.SendAnimationAsync(
                        botToken,
                        chat.ExternalChatId,
                        trimmedGifUrl,
                        trimmedText,
                        cancellationToken);

                    if (telegramResult is not { Ok: true, Result: not null })
                    {
                        return (
                            null,
                            telegramResult?.Description ?? "Telegram rejected the GIF.",
                            StatusCodes.Status400BadRequest);
                    }

                    externalMessageId = telegramResult.Result.MessageId.ToString();
                }
            }
            else if (string.Equals(integration.Platform.Code, MessengerPlatformCode, StringComparison.OrdinalIgnoreCase))
            {
                var pageAccessToken = integration.Credentials
                    .FirstOrDefault(x => x.CredentialType == MessengerPageAccessTokenCredentialType)
                    ?.ValueEncrypted;

                var messengerResult = await _messengerService.SendGifAsync(
                    chat.ExternalChatId,
                    pageAccessToken ?? string.Empty,
                    trimmedGifUrl,
                    cancellationToken);

                if (string.IsNullOrWhiteSpace(messengerResult.ExternalMessageId) && !string.IsNullOrWhiteSpace(messengerResult.ErrorMessage))
                {
                    return (null, messengerResult.ErrorMessage, messengerResult.StatusCode);
                }

                externalMessageId = messengerResult.ExternalMessageId;
            }
        }
        else if (string.Equals(integration.Platform.Code, TelegramPlatformCode, StringComparison.OrdinalIgnoreCase))
        {
            var botToken = integration.Credentials
                .FirstOrDefault(x => x.CredentialType == TelegramBotTokenCredentialType)
                ?.ValueEncrypted;

            if (!string.IsNullOrWhiteSpace(botToken))
            {
                if (savedAttachmentEntries.Count > 0)
                {
                    for (var attachmentIndex = 0; attachmentIndex < savedAttachmentEntries.Count; attachmentIndex++)
                    {
                        var savedAttachmentEntry = savedAttachmentEntries[attachmentIndex];
                        var attachmentCaption = attachmentIndex == 0 ? trimmedText : null;
                        var storageLength = new FileInfo(savedAttachmentEntry.AbsolutePath).Length;

                        if (IsImageAttachment(savedAttachmentEntry.Attachment))
                        {
                            await using var photoStream = File.OpenRead(savedAttachmentEntry.AbsolutePath);
                            _logger.LogInformation(
                                "Sending Telegram photo for chat {ChatId}. OriginalFileName={OriginalFileName}, AttachmentFileName={AttachmentFileName}, ContentType={ContentType}, UploadLength={UploadLength}, StorageLength={StorageLength}",
                                chat.Id,
                                savedAttachmentEntry.OriginalFileName,
                                savedAttachmentEntry.Attachment.FileName,
                                savedAttachmentEntry.Attachment.MimeType,
                                savedAttachmentEntry.OriginalLength,
                                storageLength);
                            var telegramPhotoResult = await _telegramService.SendPhotoAsync(
                                botToken,
                                chat.ExternalChatId,
                                photoStream,
                                savedAttachmentEntry.Attachment.FileName,
                                savedAttachmentEntry.Attachment.MimeType,
                                attachmentCaption,
                                cancellationToken);

                            if (telegramPhotoResult is not { Ok: true, Result: not null })
                            {
                                return (
                                    null,
                                    telegramPhotoResult?.Description ?? "Telegram rejected the photo.",
                                    StatusCodes.Status400BadRequest);
                            }

                            externalMessageId = telegramPhotoResult.Result.MessageId.ToString();
                            continue;
                        }

                        await using var documentStream = File.OpenRead(savedAttachmentEntry.AbsolutePath);
                        _logger.LogInformation(
                            "Sending Telegram document for chat {ChatId}. OriginalFileName={OriginalFileName}, AttachmentFileName={AttachmentFileName}, ContentType={ContentType}, UploadLength={UploadLength}, StorageLength={StorageLength}",
                            chat.Id,
                            savedAttachmentEntry.OriginalFileName,
                            savedAttachmentEntry.Attachment.FileName,
                            savedAttachmentEntry.Attachment.MimeType,
                            savedAttachmentEntry.OriginalLength,
                            storageLength);
                        var telegramDocumentResult = await _telegramService.SendDocumentAsync(
                            botToken,
                            chat.ExternalChatId,
                            documentStream,
                            savedAttachmentEntry.Attachment.FileName,
                            savedAttachmentEntry.Attachment.MimeType,
                            attachmentCaption,
                            cancellationToken);

                        if (telegramDocumentResult is not { Ok: true, Result: not null })
                        {
                            _logger.LogWarning(
                                "Telegram sendDocument failed for chat {ChatId} ({ExternalChatId}) with file {FileName}. Description: {Description}",
                                chat.Id,
                                chat.ExternalChatId,
                                savedAttachmentEntry.Attachment.FileName,
                                telegramDocumentResult?.Description ?? "No description");
                            return (
                                null,
                                telegramDocumentResult?.Description ?? "Telegram rejected the document.",
                                StatusCodes.Status400BadRequest);
                        }

                        externalMessageId = telegramDocumentResult.Result.MessageId.ToString();
                    }
                }
                else if (!string.IsNullOrWhiteSpace(trimmedText))
                {
                    var telegramResult = await _telegramService.SendMessageAsync(
                        botToken,
                        chat.ExternalChatId,
                        trimmedText,
                        cancellationToken);

                    if (telegramResult is not { Ok: true, Result: not null })
                    {
                        return (
                            null,
                            telegramResult?.Description ?? "Telegram rejected the message.",
                            StatusCodes.Status400BadRequest);
                    }

                    externalMessageId = telegramResult.Result.MessageId.ToString();
                }
                else if (attachments.Count > 0)
                {
                    var telegramResult = await _telegramService.SendMessageAsync(
                        botToken,
                        chat.ExternalChatId,
                        fallbackAttachmentText!,
                        cancellationToken);

                    if (telegramResult is not { Ok: true, Result: not null })
                    {
                        return (
                            null,
                            telegramResult?.Description ?? "Telegram rejected the attachment notification.",
                            StatusCodes.Status400BadRequest);
                    }

                    externalMessageId = telegramResult.Result.MessageId.ToString();
                }
            }
        }
        else if (string.Equals(integration.Platform.Code, MessengerPlatformCode, StringComparison.OrdinalIgnoreCase))
        {
            var pageAccessToken = integration.Credentials
                .FirstOrDefault(x => x.CredentialType == MessengerPageAccessTokenCredentialType)
                ?.ValueEncrypted;

            if (attachments.Count > 0)
            {
                var firstAttachment = savedAttachmentEntries.FirstOrDefault();
                if (firstAttachment is null)
                {
                    return (
                        null,
                        "Messenger attachment could not be prepared.",
                        StatusCodes.Status400BadRequest);
                }

                await using var attachmentStream = File.OpenRead(firstAttachment.AbsolutePath);
                var messengerAttachmentResult = await _messengerService.SendAttachmentAsync(
                    chat.ExternalChatId,
                    pageAccessToken ?? string.Empty,
                    attachmentStream,
                    firstAttachment.Attachment.FileName,
                    firstAttachment.Attachment.MimeType,
                    trimmedText,
                    cancellationToken);

                if (string.IsNullOrWhiteSpace(messengerAttachmentResult.ExternalMessageId)
                    && !string.IsNullOrWhiteSpace(messengerAttachmentResult.ErrorMessage))
                {
                    return (null, messengerAttachmentResult.ErrorMessage, messengerAttachmentResult.StatusCode);
                }

                externalMessageId = messengerAttachmentResult.ExternalMessageId;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(trimmedText))
                {
                    return (
                        null,
                        "Messenger currently supports text-only messages.",
                        StatusCodes.Status400BadRequest);
                }

                var messengerResult = await _messengerService.SendTextMessageAsync(
                    chat.ExternalChatId,
                    pageAccessToken ?? string.Empty,
                    trimmedText,
                    cancellationToken);

                if (string.IsNullOrWhiteSpace(messengerResult.ExternalMessageId) && !string.IsNullOrWhiteSpace(messengerResult.ErrorMessage))
                {
                    return (null, messengerResult.ErrorMessage, messengerResult.StatusCode);
                }

                externalMessageId = messengerResult.ExternalMessageId;
            }
        }

        var message = new Message
        {
            Id = Guid.NewGuid(),
            ChatId = chat.Id,
            ExternalMessageId = externalMessageId,
            Text = !string.IsNullOrWhiteSpace(trimmedGifUrl) ? trimmedGifUrl : trimmedText,
            Direction = "Outbound",
            MessageType = !string.IsNullOrWhiteSpace(trimmedGifUrl)
                ? "Gif"
                : savedAttachments.Count > 0
                    ? "Attachment"
                    : "Text",
            CreatedByUserId = userId,
            SenderDisplayName = string.IsNullOrWhiteSpace(senderName) ? "You" : senderName,
            SentAt = nowUtc,
            DeliveredAt = nowUtc,
            IsEdited = false,
            IsDeleted = false,
            CreatedAt = nowUtc,
            Attachments = savedAttachments
        };

        chat.LastMessageText = ResolveOutgoingLastMessageText(trimmedText, trimmedGifUrl, savedAttachments);
        chat.LastMessageAt = message.CreatedAt;
        chat.UpdatedAt = nowUtc;

        _dbContext.Messages.Add(message);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapMessage(message, userId), null, StatusCodes.Status200OK);
    }

    public async Task<(MessageDto? Response, string? ErrorMessage, int StatusCode)> UpdateMessageReactionAsync(
        Guid userId,
        Guid messageId,
        UpdateMessageReactionRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var normalizedReaction = NormalizeReaction(request.Emoji);
        if (normalizedReaction is not null && !AllowedReactions.Contains(normalizedReaction))
        {
            return (null, "Unsupported reaction.", StatusCodes.Status400BadRequest);
        }

        var context = await ResolveContextAsync(userId, cancellationToken);
        if (!context.IsSuccess)
        {
            return (null, context.ErrorMessage, context.StatusCode);
        }

        var message = await _dbContext.Messages
            .Include(x => x.Reads)
            .Include(x => x.Attachments)
            .Include(x => x.CreatedByUser)
            .Include(x => x.Chat)
                .ThenInclude(x => x.Integration)
                    .ThenInclude(x => x.Platform)
            .Include(x => x.Chat)
                .ThenInclude(x => x.Integration)
                    .ThenInclude(x => x.Credentials)
            .FirstOrDefaultAsync(x => x.Id == messageId && !x.IsDeleted, cancellationToken);

        if (message is null)
        {
            return (null, "Message not found.", StatusCodes.Status404NotFound);
        }

        var hasAccess = context.Scope == "Workspace"
            ? message.Chat.Integration.WorkspaceId == context.WorkspaceId
            : message.Chat.Integration.PersonalAccountId == context.PersonalAccountId;

        if (!hasAccess)
        {
            return (null, "Message not found.", StatusCodes.Status404NotFound);
        }

        var nextReaction = normalizedReaction is not null
            && string.Equals(message.DialoglyReaction, normalizedReaction, StringComparison.Ordinal)
                ? null
                : normalizedReaction;

        var telegramSync = await TrySyncTelegramReactionAsync(message, nextReaction, cancellationToken);
        if (!telegramSync.IsSuccess)
        {
            _logger.LogWarning(
                "Telegram reaction sync failed for message {MessageId}. Saving Dialogly reaction anyway. Reason: {Reason}",
                message.Id,
                telegramSync.ErrorMessage ?? "Unknown reaction sync error");
        }

        message.DialoglyReaction = nextReaction;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (MapMessage(message, userId), null, StatusCodes.Status200OK);
    }

    public async Task<(int? UnreadCount, string? ErrorMessage, int StatusCode)> MarkChatAsReadAsync(
        Guid userId,
        Guid chatId,
        CancellationToken cancellationToken = default)
    {
        var (chat, errorMessage, statusCode) = await LoadAccessibleChatAsync(userId, chatId, cancellationToken);
        if (chat is null)
        {
            return (null, errorMessage, statusCode);
        }

        var incomingMessages = await _dbContext.Messages
            .Include(x => x.Reads)
            .Where(x => x.ChatId == chat.Id && !x.IsDeleted && x.Direction == "Inbound")
            .ToListAsync(cancellationToken);

        var newReads = incomingMessages
            .Where(x => x.Reads.All(read => read.UserId != userId))
            .Select(x => new MessageRead
            {
                Id = Guid.NewGuid(),
                MessageId = x.Id,
                UserId = userId,
                ReadAt = DateTime.UtcNow
            })
            .ToList();

        if (chat.Integration.WorkspaceId.HasValue)
        {
            var workspaceMemberIds = await _dbContext.WorkspaceMembers
                .AsNoTracking()
                .Where(x => x.WorkspaceId == chat.Integration.WorkspaceId.Value && x.IsActive)
                .Select(x => x.UserId)
                .ToListAsync(cancellationToken);

            newReads = incomingMessages
                .SelectMany(message => workspaceMemberIds
                    .Where(memberId => message.Reads.All(read => read.UserId != memberId))
                    .Select(memberId => new MessageRead
                    {
                        Id = Guid.NewGuid(),
                        MessageId = message.Id,
                        UserId = memberId,
                        ReadAt = DateTime.UtcNow
                    }))
                .ToList();
        }

        if (newReads.Count > 0)
        {
            _dbContext.MessageReads.AddRange(newReads);
        }

        chat.UnreadCount = 0;
        chat.UpdatedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);

        return (0, null, StatusCodes.Status200OK);
    }

    public async Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> CreateMockChatAsync(
        Guid userId,
        CreateMockChatRequestDto request,
        CancellationToken cancellationToken = default)
    {
        var context = await ResolveContextAsync(userId, cancellationToken);
        if (!context.IsSuccess)
        {
            return (null, context.ErrorMessage, context.StatusCode);
        }

        var integrationQuery = ApplyIntegrationScope(
                _dbContext.Integrations
                    .Include(x => x.Platform)
                    .Where(x => x.IsActive && x.Status == "Connected" && AllowedPlatformCodes.Contains(x.Platform.Code)),
                context);

        if (request.IntegrationId.HasValue)
        {
            integrationQuery = integrationQuery.Where(x => x.Id == request.IntegrationId.Value);
        }
        else if (!string.IsNullOrWhiteSpace(request.PlatformCode))
        {
            var platformCode = request.PlatformCode.Trim().ToLowerInvariant();
            integrationQuery = integrationQuery.Where(x => x.Platform.Code == platformCode);
        }

        var integration = await integrationQuery
            .OrderByDescending(x => x.UpdatedAt ?? x.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);

        if (integration is null)
        {
            return (null, "Connect a Telegram or Messenger integration first.", StatusCodes.Status400BadRequest);
        }

        var nowUtc = DateTime.UtcNow;
        var customerName = string.IsNullOrWhiteSpace(request.CustomerName)
            ? $"{integration.Platform.Name} Test Customer"
            : request.CustomerName.Trim();
        var username = string.IsNullOrWhiteSpace(request.Username)
            ? customerName.ToLowerInvariant().Replace(' ', '_')
            : request.Username.Trim();
        var initialMessageText = string.IsNullOrWhiteSpace(request.InitialMessageText)
            ? $"Hello from your {integration.Platform.Name} mock chat."
            : request.InitialMessageText.Trim();

        var contact = new Contact
        {
            Id = Guid.NewGuid(),
            IntegrationId = integration.Id,
            ExternalContactId = $"{integration.Platform.Code}-contact-{Guid.NewGuid():N}"[..30],
            DisplayName = customerName,
            Username = username,
            CreatedAt = nowUtc,
            UpdatedAt = nowUtc
        };

        var chat = new Chat
        {
            Id = Guid.NewGuid(),
            IntegrationId = integration.Id,
            ContactId = contact.Id,
            ExternalChatId = $"{integration.Platform.Code}-chat-{Guid.NewGuid():N}"[..27],
            Title = customerName,
            Status = "Open",
            LastMessageText = initialMessageText,
            LastMessageAt = nowUtc,
            UnreadCount = 1,
            IsArchived = false,
            CreatedAt = nowUtc,
            UpdatedAt = nowUtc
        };

        var message = new Message
        {
            Id = Guid.NewGuid(),
            ChatId = chat.Id,
            Text = initialMessageText,
            Direction = "Inbound",
            MessageType = "Text",
            SenderDisplayName = customerName,
            SentAt = nowUtc,
            IsEdited = false,
            IsDeleted = false,
            CreatedAt = nowUtc
        };

        _dbContext.Contacts.Add(contact);
        _dbContext.Chats.Add(chat);
        _dbContext.Messages.Add(message);
        await _dbContext.SaveChangesAsync(cancellationToken);

        var savedChat = await _dbContext.Chats
            .AsNoTracking()
            .Include(x => x.Contact)
            .Include(x => x.Integration)
                .ThenInclude(x => x.Platform)
            .Include(x => x.Messages)
                .ThenInclude(x => x.Reads)
            .FirstAsync(x => x.Id == chat.Id, cancellationToken);

        return (MapChatDetails(savedChat, userId), null, StatusCodes.Status200OK);
    }

    private async Task<(Chat? Chat, string? ErrorMessage, int StatusCode)> LoadAccessibleChatAsync(
        Guid userId,
        Guid chatId,
        CancellationToken cancellationToken)
    {
        var context = await ResolveContextAsync(userId, cancellationToken);
        if (!context.IsSuccess)
        {
            return (null, context.ErrorMessage, context.StatusCode);
        }

        var chat = await ApplyScope(
                _dbContext.Chats
                    .Include(x => x.Contact)
                    .Include(x => x.Integration)
                        .ThenInclude(x => x.Platform)
                    .Include(x => x.Messages)
                        .ThenInclude(x => x.Reads),
                context)
            .FirstOrDefaultAsync(x => x.Id == chatId, cancellationToken);

        if (chat is null)
        {
            return (null, "Chat not found.", StatusCodes.Status404NotFound);
        }

        return (chat, null, StatusCodes.Status200OK);
    }

    private async Task<ResolvedChatContext> ResolveContextAsync(Guid userId, CancellationToken cancellationToken)
    {
        var user = await _dbContext.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == userId && x.IsActive, cancellationToken);

        if (user is null)
        {
            return ResolvedChatContext.Fail("User not found.", StatusCodes.Status404NotFound);
        }

        if (!user.ActiveWorkspaceId.HasValue)
        {
            var personalAccountId = await _dbContext.PersonalAccounts
                .AsNoTracking()
                .Where(x => x.UserId == userId && x.IsActive)
                .Select(x => (Guid?)x.Id)
                .FirstOrDefaultAsync(cancellationToken);

            return ResolvedChatContext.Personal(userId, personalAccountId);
        }

        var membership = await _dbContext.WorkspaceMembers
            .AsNoTracking()
            .FirstOrDefaultAsync(
                x => x.UserId == userId && x.WorkspaceId == user.ActiveWorkspaceId.Value && x.IsActive,
                cancellationToken);

        if (membership is null)
        {
            return ResolvedChatContext.Fail("You do not have access to the active workspace.", StatusCodes.Status403Forbidden);
        }

        return ResolvedChatContext.Workspace(userId, membership.WorkspaceId);
    }

    private IQueryable<Chat> ApplyScope(IQueryable<Chat> query, ResolvedChatContext context)
    {
        return context.Scope == "Workspace"
            ? query.Where(x => x.Integration.WorkspaceId == context.WorkspaceId)
            : query.Where(x => x.Integration.PersonalAccountId == context.PersonalAccountId);
    }

    private IQueryable<Integration> ApplyIntegrationScope(IQueryable<Integration> query, ResolvedChatContext context)
    {
        return context.Scope == "Workspace"
            ? query.Where(x => x.WorkspaceId == context.WorkspaceId)
            : query.Where(x => x.PersonalAccountId == context.PersonalAccountId);
    }

    private static ChatListItemDto MapChatListItem(Chat chat, Guid userId)
    {
        var unreadCount = GetUnreadCount(chat, userId);
        var lastPersistedMessage = chat.Messages
            .Where(x => !x.IsDeleted)
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefault();

        return new ChatListItemDto
        {
            Id = chat.Id,
            Title = chat.Title ?? chat.Contact.DisplayName,
            CustomName = chat.CustomName,
            PlatformCode = chat.Integration.Platform.Code,
            PlatformName = chat.Integration.Platform.Name,
            IntegrationAccountId = chat.IntegrationId,
            ExternalChatId = chat.ExternalChatId,
            LastMessageText = chat.LastMessageText ?? lastPersistedMessage?.Text,
            LastMessageAt = ToUtcNullable(lastPersistedMessage?.CreatedAt ?? chat.LastMessageAt),
            LastActivityAt = ToUtcNullable(chat.Messages
                .Where(x => !x.IsDeleted && string.Equals(x.Direction, "Inbound", StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(x => x.CreatedAt)
                .Select(x => (DateTime?)x.CreatedAt)
                .FirstOrDefault()),
            UnreadCount = unreadCount,
            HasUnread = unreadCount > 0,
            IsRead = unreadCount == 0,
            IsPinned = chat.IsPinned,
            IsArchived = chat.IsArchived,
            Status = chat.Status,
            AvatarUrl = chat.Contact.AvatarUrl
        };
    }

    private static ChatDetailsDto MapChatDetails(Chat chat, Guid userId)
    {
        var unreadCount = GetUnreadCount(chat, userId);

        return new ChatDetailsDto
        {
            Id = chat.Id,
            Title = chat.Title ?? chat.Contact.DisplayName,
            CustomName = chat.CustomName,
            Notes = chat.Notes,
            PlatformCode = chat.Integration.Platform.Code,
            PlatformName = chat.Integration.Platform.Name,
            IntegrationAccountId = chat.IntegrationId,
            ExternalChatId = chat.ExternalChatId,
            Status = chat.Status,
            AvatarUrl = chat.Contact.AvatarUrl,
            FirstMessageAt = ToUtcNullable(chat.Messages
                .Where(x => !x.IsDeleted)
                .OrderBy(x => x.CreatedAt)
                .Select(x => (DateTime?)x.CreatedAt)
                .FirstOrDefault()),
            IsPinned = chat.IsPinned,
            IsArchived = chat.IsArchived,
            UnreadCount = unreadCount,
            HasUnread = unreadCount > 0
        };
    }

    private static MessageDto MapMessage(Message message, Guid userId)
    {
        var isInbound = string.Equals(message.Direction, "Inbound", StringComparison.OrdinalIgnoreCase);
        var wasRead = message.Reads.Any(x => x.UserId == userId);

        return new MessageDto
        {
            Id = message.Id,
            ChatId = message.ChatId,
            Text = string.Equals(message.MessageType, "Gif", StringComparison.OrdinalIgnoreCase) ? null : message.Text,
            Direction = isInbound ? "Incoming" : "Outgoing",
            Status = ResolveMessageStatus(message, wasRead),
            CreatedAt = ToUtc(message.CreatedAt),
            SenderName = message.SenderDisplayName,
            PlatformMessageId = message.ExternalMessageId,
            Reaction = message.DialoglyReaction,
            DialoglyReaction = message.DialoglyReaction,
            TelegramReaction = message.TelegramReaction,
            Reactions = BuildMessageReactions(message),
            GifUrl = string.Equals(message.MessageType, "Gif", StringComparison.OrdinalIgnoreCase) ? message.Text : null,
            Attachments = message.Attachments
                .Select(x => new MessageAttachmentDto
                {
                    Id = x.Id,
                    FileName = x.FileName,
                    FileUrl = x.FileUrl,
                    DownloadUrl = $"/api/chats/attachments/{x.Id}",
                    MimeType = x.MimeType,
                    ContentType = ResolveAttachmentContentType(x.MimeType, x.FileName),
                    FileSize = x.FileSize,
                    Size = x.FileSize
                })
                .ToList()
        };
    }

    private static IReadOnlyList<MessageReactionDto> BuildMessageReactions(Message message)
    {
        var reactions = new List<MessageReactionDto>();

        if (!string.IsNullOrWhiteSpace(message.DialoglyReaction))
        {
            reactions.Add(new MessageReactionDto
            {
                Source = "dialogly",
                Emoji = message.DialoglyReaction
            });
        }

        if (!string.IsNullOrWhiteSpace(message.TelegramReaction))
        {
            reactions.Add(new MessageReactionDto
            {
                Source = "telegram",
                Emoji = message.TelegramReaction
            });
        }

        return reactions;
    }

    private async Task<(bool IsSuccess, string? ErrorMessage, int StatusCode)> TrySyncTelegramReactionAsync(
        Message message,
        string? reaction,
        CancellationToken cancellationToken)
    {
        var integration = message.Chat.Integration;
        if (!string.Equals(integration.Platform.Code, TelegramPlatformCode, StringComparison.OrdinalIgnoreCase))
        {
            return (true, null, StatusCodes.Status200OK);
        }

        if (string.IsNullOrWhiteSpace(message.ExternalMessageId)
            || !int.TryParse(message.ExternalMessageId, out var telegramMessageId))
        {
            _logger.LogWarning(
                "Skipping Telegram reaction sync for message {MessageId} because ExternalMessageId is missing or invalid.",
                message.Id);
            return (true, null, StatusCodes.Status200OK);
        }

        var botToken = integration.Credentials
            .FirstOrDefault(x => x.CredentialType == TelegramBotTokenCredentialType)
            ?.ValueEncrypted;

        if (string.IsNullOrWhiteSpace(botToken))
        {
            _logger.LogWarning(
                "Skipping Telegram reaction sync for message {MessageId} because bot token credential is missing.",
                message.Id);
            return (true, null, StatusCodes.Status200OK);
        }

        var telegramResult = await _telegramService.SetMessageReactionAsync(
            botToken,
            message.Chat.ExternalChatId,
            telegramMessageId,
            reaction,
            cancellationToken);

        if (telegramResult is { Ok: true })
        {
            return (true, null, StatusCodes.Status200OK);
        }

        return (
            false,
            telegramResult?.Description ?? "Telegram rejected the reaction.",
            StatusCodes.Status502BadGateway);
    }

    private static int GetUnreadCount(Chat chat, Guid userId)
    {
        return chat.UnreadCount;
    }

    private static string? NormalizeReaction(string? emoji)
    {
        var normalizedReaction = emoji?.Trim();
        return string.IsNullOrWhiteSpace(normalizedReaction) ? null : normalizedReaction;
    }

    private static string? ResolveOutgoingLastMessageText(string? trimmedText, string? trimmedGifUrl, List<MessageAttachment> attachments)
    {
        if (!string.IsNullOrWhiteSpace(trimmedText))
        {
            return trimmedText;
        }

        if (!string.IsNullOrWhiteSpace(trimmedGifUrl))
        {
            return "GIF";
        }

        var firstAttachment = attachments.FirstOrDefault();
        if (firstAttachment is null)
        {
            return null;
        }

        if (!string.IsNullOrWhiteSpace(firstAttachment.MimeType)
            && firstAttachment.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
        {
            return "Photo";
        }

        return "File";
    }

    private static string ResolveMessageStatus(Message message, bool wasRead)
    {
        if (wasRead)
        {
            return "Read";
        }

        if (message.DeliveredAt.HasValue)
        {
            return "Delivered";
        }

        return "Sent";
    }

    private static DateTime ToUtc(DateTime value)
    {
        return value.Kind == DateTimeKind.Utc
            ? value
            : DateTime.SpecifyKind(value, DateTimeKind.Utc);
    }

    private static DateTime? ToUtcNullable(DateTime? value)
    {
        return value.HasValue ? ToUtc(value.Value) : null;
    }

    private static string ResolveAttachmentContentType(string? mimeType, string fileName)
    {
        if (!string.IsNullOrWhiteSpace(mimeType)
            && !string.Equals(mimeType, "application/octet-stream", StringComparison.OrdinalIgnoreCase))
        {
            return mimeType;
        }

        var extension = Path.GetExtension(fileName).ToLowerInvariant();
        return extension switch
        {
            ".jpg" or ".jpeg" => "image/jpeg",
            ".png" => "image/png",
            ".webp" => "image/webp",
            ".gif" => "image/gif",
            ".mp4" => "video/mp4",
            ".mov" => "video/quicktime",
            ".webm" => "video/webm",
            ".pdf" => "application/pdf",
            ".doc" => "application/msword",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xls" => "application/vnd.ms-excel",
            ".xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".txt" => "text/plain",
            _ => "application/octet-stream"
        };
    }

    private static string? NormalizeOptionalValue(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var trimmed = value.Trim();
        return trimmed.Length <= maxLength ? trimmed : trimmed[..maxLength];
    }

    private async Task<SavedAttachmentEntry> SaveUploadedAttachmentAsync(
        IFormFile file,
        CancellationToken cancellationToken)
    {
        var uploadsRoot = Path.Combine(
            string.IsNullOrWhiteSpace(_environment.WebRootPath)
                ? Path.Combine(_environment.ContentRootPath, "wwwroot")
                : _environment.WebRootPath,
            "uploads",
            "message-attachments");

        Directory.CreateDirectory(uploadsRoot);

        var extension = Path.GetExtension(file.FileName);
        var storedFileName = $"{Guid.NewGuid():N}{extension}";
        var absolutePath = Path.Combine(uploadsRoot, storedFileName);

        await using (var stream = File.Create(absolutePath))
        {
            await file.CopyToAsync(stream, cancellationToken);
        }

        var attachment = new MessageAttachment
        {
            Id = Guid.NewGuid(),
            FileName = file.FileName,
            FileUrl = $"/uploads/message-attachments/{storedFileName}",
            MimeType = ResolveAttachmentContentType(file.ContentType, file.FileName),
            FileSize = file.Length,
            CreatedAt = DateTime.UtcNow
        };

        return new SavedAttachmentEntry(
            attachment,
            absolutePath,
            file.FileName,
            file.Length);
    }

    private static bool IsImageFile(IFormFile file)
    {
        if (!string.IsNullOrWhiteSpace(file.ContentType)
            && file.ContentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        return extension is ".jpg" or ".jpeg" or ".png" or ".webp" or ".gif";
    }

    private static bool IsImageAttachment(MessageAttachment attachment)
    {
        if (!string.IsNullOrWhiteSpace(attachment.MimeType)
            && attachment.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        var extension = Path.GetExtension(attachment.FileName).ToLowerInvariant();
        return extension is ".jpg" or ".jpeg" or ".png" or ".webp" or ".gif";
    }

    private sealed record ResolvedChatContext(
        bool IsSuccess,
        string Scope,
        Guid UserId,
        Guid? WorkspaceId,
        Guid? PersonalAccountId,
        string? ErrorMessage,
        int StatusCode)
    {
        public static ResolvedChatContext Personal(Guid userId, Guid? personalAccountId) =>
            new(true, "Personal", userId, null, personalAccountId, null, StatusCodes.Status200OK);

        public static ResolvedChatContext Workspace(Guid userId, Guid workspaceId) =>
            new(true, "Workspace", userId, workspaceId, null, null, StatusCodes.Status200OK);

        public static ResolvedChatContext Fail(string message, int statusCode) =>
            new(false, string.Empty, Guid.Empty, null, null, message, statusCode);
    }

    private sealed record SavedAttachmentEntry(
        MessageAttachment Attachment,
        string AbsolutePath,
        string OriginalFileName,
        long OriginalLength);
}
