using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Dialogly.Api.DTOs.Telegram;
using Dialogly.Api.Interfaces;
using Microsoft.Extensions.Logging;

namespace Dialogly.Api.Services;

public class TelegramService(HttpClient httpClient, ILogger<TelegramService> logger) : ITelegramService
{
    private readonly HttpClient _httpClient = httpClient;
    private readonly ILogger<TelegramService> _logger = logger;
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public async Task<TelegramBotInfoDto?> ValidateBotTokenAsync(string botToken, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.GetAsync(BuildApiUrl(botToken, "getMe"), cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var payload = await response.Content.ReadFromJsonAsync<TelegramGetMeResponseDto>(JsonOptions, cancellationToken);
        if (payload is not { Ok: true, Result: not null })
        {
            return null;
        }

        return new TelegramBotInfoDto
        {
            ExternalAccountId = payload.Result.Id.ToString(),
            Username = string.IsNullOrWhiteSpace(payload.Result.Username)
                ? string.Empty
                : $"@{payload.Result.Username.TrimStart('@')}",
            DisplayName = BuildDisplayName(payload.Result.FirstName, payload.Result.Username)
        };
    }

    public async Task<TelegramSendMessageResponseDto?> SendMessageAsync(string botToken, string chatId, string text, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PostAsJsonAsync(
            BuildApiUrl(botToken, "sendMessage"),
            new
            {
                chat_id = chatId,
                text,
            },
            cancellationToken);

        var payload = await response.Content.ReadFromJsonAsync<TelegramSendMessageResponseDto>(JsonOptions, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Telegram sendMessage failed with status {StatusCode}: {Description}",
                (int)response.StatusCode,
                payload?.Description ?? "No description");
        }

        return payload;
    }

    public async Task<TelegramSendMessageResponseDto?> SendAnimationAsync(
        string botToken,
        string chatId,
        string animationUrl,
        string? caption = null,
        CancellationToken cancellationToken = default)
    {
        var payloadBody = new Dictionary<string, object?>
        {
            ["chat_id"] = chatId,
            ["animation"] = animationUrl,
        };

        if (!string.IsNullOrWhiteSpace(caption))
        {
            payloadBody["caption"] = caption;
        }

        var response = await _httpClient.PostAsJsonAsync(
            BuildApiUrl(botToken, "sendAnimation"),
            payloadBody,
            cancellationToken);

        var payload = await response.Content.ReadFromJsonAsync<TelegramSendMessageResponseDto>(JsonOptions, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Telegram sendAnimation failed with status {StatusCode}: {Description}",
                (int)response.StatusCode,
                payload?.Description ?? "No description");
        }

        return payload;
    }

    public async Task<TelegramSendMessageResponseDto?> SendPhotoAsync(
        string botToken,
        string chatId,
        Stream photoStream,
        string fileName,
        string? contentType = null,
        string? caption = null,
        CancellationToken cancellationToken = default)
    {
        using var formData = new MultipartFormDataContent();
        formData.HeaderEncodingSelector = static (_, _) => Encoding.UTF8;
        formData.Add(new StringContent(chatId), "chat_id");

        if (!string.IsNullOrWhiteSpace(caption))
        {
            formData.Add(new StringContent(caption), "caption");
        }

        using var streamContent = new StreamContent(photoStream);
        AddMultipartFile(
            formData,
            streamContent,
            "photo",
            fileName,
            contentType,
            fallbackBaseName: "image");

        var response = await _httpClient.PostAsync(
            BuildApiUrl(botToken, "sendPhoto"),
            formData,
            cancellationToken);

        var payload = await response.Content.ReadFromJsonAsync<TelegramSendMessageResponseDto>(JsonOptions, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Telegram sendPhoto failed with status {StatusCode}: {Description}",
                (int)response.StatusCode,
                payload?.Description ?? "No description");
        }

        return payload;
    }

    public async Task<TelegramSendMessageResponseDto?> SendDocumentAsync(
        string botToken,
        string chatId,
        Stream documentStream,
        string fileName,
        string? contentType = null,
        string? caption = null,
        CancellationToken cancellationToken = default)
    {
        using var formData = new MultipartFormDataContent();
        formData.HeaderEncodingSelector = static (_, _) => Encoding.UTF8;
        formData.Add(new StringContent(chatId), "chat_id");

        if (!string.IsNullOrWhiteSpace(caption))
        {
            formData.Add(new StringContent(caption), "caption");
        }

        await using var copyStream = new MemoryStream();
        await documentStream.CopyToAsync(copyStream, cancellationToken);
        var documentBytes = copyStream.ToArray();
        using var fileContent = new ByteArrayContent(documentBytes);
        AddMultipartDocumentFile(
            formData,
            fileContent,
            fileName,
            contentType,
            fallbackBaseName: "document");

        var response = await _httpClient.PostAsync(
            BuildApiUrl(botToken, "sendDocument"),
            formData,
            cancellationToken);

        var payload = await response.Content.ReadFromJsonAsync<TelegramSendMessageResponseDto>(JsonOptions, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Telegram sendDocument failed with status {StatusCode}: {Description}",
                (int)response.StatusCode,
                payload?.Description ?? "No description");
        }

        return payload;
    }

    public async Task<TelegramSetWebhookResponseDto?> SetMessageReactionAsync(
        string botToken,
        string chatId,
        int messageId,
        string? emoji,
        CancellationToken cancellationToken = default)
    {
        object[] reaction = string.IsNullOrWhiteSpace(emoji)
            ? Array.Empty<object>()
            : new object[]
            {
                new
                {
                    type = "emoji",
                    emoji
                }
            };

        var response = await _httpClient.PostAsJsonAsync(
            BuildApiUrl(botToken, "setMessageReaction"),
            new
            {
                chat_id = chatId,
                message_id = messageId,
                reaction,
                is_big = false
            },
            JsonOptions,
            cancellationToken);

        var payload = await response.Content.ReadFromJsonAsync<TelegramSetWebhookResponseDto>(JsonOptions, cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "Telegram setMessageReaction failed with status {StatusCode}: {Description}",
                (int)response.StatusCode,
                payload?.Description ?? "No description");
        }

        return payload;
    }

    public async Task<TelegramSetWebhookResponseDto?> SetWebhookAsync(
        string botToken,
        string webhookUrl,
        string? secretToken = null,
        IReadOnlyCollection<string>? allowedUpdates = null,
        CancellationToken cancellationToken = default)
    {
        var payload = new Dictionary<string, object?>
        {
            ["url"] = webhookUrl,
        };

        if (!string.IsNullOrWhiteSpace(secretToken))
        {
            payload["secret_token"] = secretToken;
        }

        if (allowedUpdates is { Count: > 0 })
        {
            payload["allowed_updates"] = allowedUpdates;
        }

        var response = await _httpClient.PostAsJsonAsync(
            BuildApiUrl(botToken, "setWebhook"),
            payload,
            cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        return await response.Content.ReadFromJsonAsync<TelegramSetWebhookResponseDto>(JsonOptions, cancellationToken);
    }

    public async Task<TelegramFileDto?> GetFileAsync(string botToken, string fileId, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PostAsJsonAsync(
            BuildApiUrl(botToken, "getFile"),
            new
            {
                file_id = fileId,
            },
            cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var payload = await response.Content.ReadFromJsonAsync<TelegramGetFileResponseDto>(JsonOptions, cancellationToken);
        if (payload is not { Ok: true, Result: not null })
        {
            return null;
        }

        return payload.Result;
    }

    public async Task<(byte[] Content, string? ContentType)?> DownloadFileAsync(string botToken, string filePath, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.GetAsync(BuildFileUrl(botToken, filePath), cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var content = await response.Content.ReadAsByteArrayAsync(cancellationToken);
        return (content, response.Content.Headers.ContentType?.MediaType);
    }

    private static string BuildApiUrl(string botToken, string method)
    {
        return $"https://api.telegram.org/bot{botToken}/{method}";
    }

    private static string BuildFileUrl(string botToken, string filePath)
    {
        return $"https://api.telegram.org/file/bot{botToken}/{filePath}";
    }

    private void AddMultipartFile(
        MultipartFormDataContent formData,
        StreamContent streamContent,
        string fieldName,
        string? originalFileName,
        string? contentType,
        string fallbackBaseName)
    {
        var resolvedContentType = string.IsNullOrWhiteSpace(contentType)
            ? "application/octet-stream"
            : contentType;
        var telegramFileName = GetTelegramFileName(originalFileName, resolvedContentType, fallbackBaseName);
        _logger.LogInformation(
            "Preparing Telegram multipart file part. FieldName={FieldName}, FileName={FileName}, ContentType={ContentType}",
            fieldName,
            telegramFileName,
            resolvedContentType);

        streamContent.Headers.ContentType = new MediaTypeHeaderValue(resolvedContentType);
        streamContent.Headers.Remove("Content-Disposition");
        streamContent.Headers.TryAddWithoutValidation(
            "Content-Disposition",
            BuildContentDispositionHeader(fieldName, telegramFileName));

        formData.Add(streamContent);
    }

    private void AddMultipartDocumentFile(
        MultipartFormDataContent formData,
        HttpContent fileContent,
        string? originalFileName,
        string? contentType,
        string fallbackBaseName)
    {
        var resolvedContentType = string.IsNullOrWhiteSpace(contentType)
            ? "application/octet-stream"
            : contentType;
        var telegramFileName = GetTelegramFileName(originalFileName, resolvedContentType, fallbackBaseName);

        _logger.LogInformation(
            "Preparing Telegram document multipart file part. FileName={FileName}, ContentType={ContentType}",
            telegramFileName,
            resolvedContentType);

        fileContent.Headers.ContentType = new MediaTypeHeaderValue(resolvedContentType);
        fileContent.Headers.Remove("Content-Disposition");
        fileContent.Headers.TryAddWithoutValidation(
            "Content-Disposition",
            BuildContentDispositionHeader("document", telegramFileName));

        formData.Add(fileContent);
    }

    private static string GetTelegramFileName(string? originalFileName, string contentType, string fallbackBaseName)
    {
        var candidate = Path.GetFileName(originalFileName?.Trim() ?? string.Empty);
        candidate = candidate
            .Replace("/", string.Empty, StringComparison.Ordinal)
            .Replace("\\", string.Empty, StringComparison.Ordinal);

        var extension = Path.GetExtension(candidate);
        if (string.IsNullOrWhiteSpace(extension))
        {
            extension = GetDefaultExtension(contentType);
        }

        if (string.IsNullOrWhiteSpace(candidate))
        {
            return $"{fallbackBaseName}{extension}";
        }

        var fileNameWithoutExtension = Path.GetFileNameWithoutExtension(candidate);
        var normalizedBaseName = new string(fileNameWithoutExtension
            .Where(character => !char.IsControl(character))
            .ToArray())
            .Trim();

        if (string.IsNullOrWhiteSpace(normalizedBaseName))
        {
            normalizedBaseName = fallbackBaseName;
        }

        return $"{normalizedBaseName}{extension}";
    }

    private static string BuildContentDispositionHeader(
        string fieldName,
        string telegramFileName)
    {
        var escapedFieldName = EscapeContentDispositionValue(fieldName);
        var escapedUnicodeName = EscapeContentDispositionValue(telegramFileName);
        var encodedUnicodeName = Uri.EscapeDataString(telegramFileName);

        return $"form-data; name=\"{escapedFieldName}\"; filename=\"{escapedUnicodeName}\"; filename*=UTF-8''{encodedUnicodeName}";
    }

    private static string EscapeContentDispositionValue(string value)
    {
        return value
            .Replace("\\", "\\\\", StringComparison.Ordinal)
            .Replace("\"", "\\\"", StringComparison.Ordinal);
    }

    private static string GetDefaultExtension(string contentType)
    {
        return contentType.ToLowerInvariant() switch
        {
            "application/pdf" => ".pdf",
            "image/jpeg" => ".jpg",
            "image/png" => ".png",
            "image/webp" => ".webp",
            "image/gif" => ".gif",
            "text/plain" => ".txt",
            "application/msword" => ".doc",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document" => ".docx",
            _ => ".bin"
        };
    }

    private static string BuildDisplayName(string? firstName, string? username)
    {
        if (!string.IsNullOrWhiteSpace(firstName))
        {
            return firstName.Trim();
        }

        if (!string.IsNullOrWhiteSpace(username))
        {
            return $"@{username.TrimStart('@')}";
        }

        return "Telegram Bot";
    }
}
