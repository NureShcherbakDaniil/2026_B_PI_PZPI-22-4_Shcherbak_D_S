using Dialogly.Api.Interfaces;

namespace Dialogly.Api.Services;

public class TelegramWebhookStartupRefreshService(
    IServiceScopeFactory scopeFactory,
    ILogger<TelegramWebhookStartupRefreshService> logger) : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory = scopeFactory;
    private readonly ILogger<TelegramWebhookStartupRefreshService> _logger = logger;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await Task.Delay(TimeSpan.FromSeconds(2), stoppingToken);
            using var scope = _scopeFactory.CreateScope();
            var telegramWebhookRefreshService = scope.ServiceProvider.GetRequiredService<ITelegramWebhookRefreshService>();
            await telegramWebhookRefreshService.RefreshAllAsync(stoppingToken);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
        }
        catch (Exception exception)
        {
            _logger.LogWarning(exception, "Telegram webhook startup refresh failed.");
        }
    }
}
