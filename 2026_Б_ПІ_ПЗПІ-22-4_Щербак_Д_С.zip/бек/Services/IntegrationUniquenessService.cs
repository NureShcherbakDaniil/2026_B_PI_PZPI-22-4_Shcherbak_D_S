using Dialogly.Api.Data;
using Dialogly.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Dialogly.Api.Services;

public class IntegrationUniquenessService(
    ApplicationDbContext dbContext,
    ILogger<IntegrationUniquenessService> logger) : IIntegrationUniquenessService
{
    private readonly ApplicationDbContext _dbContext = dbContext;
    private readonly ILogger<IntegrationUniquenessService> _logger = logger;

    public async Task<IntegrationAvailabilityResult> EnsureIntegrationIsAvailableAsync(
        string platformCode,
        string externalAccountId,
        Guid currentUserId,
        Guid? workspaceId,
        CancellationToken cancellationToken = default)
    {
        var normalizedPlatformCode = platformCode.Trim().ToLowerInvariant();
        var normalizedExternalAccountId = externalAccountId.Trim();

        var existingIntegration = await _dbContext.Integrations
            .Include(x => x.Platform)
            .Include(x => x.PersonalAccount)
            .Include(x => x.ConnectedByUser)
            .FirstOrDefaultAsync(
                x => x.Platform.Code == normalizedPlatformCode
                    && x.ExternalAccountId == normalizedExternalAccountId
                    && x.IsActive
                    && x.DisconnectedAt == null,
                cancellationToken);

        if (existingIntegration is null)
        {
            return IntegrationAvailabilityResult.Available();
        }

        var belongsToCurrentOwner = workspaceId.HasValue
            ? existingIntegration.WorkspaceId == workspaceId.Value
            : existingIntegration.WorkspaceId == null
                && existingIntegration.PersonalAccount?.UserId == currentUserId;

        if (belongsToCurrentOwner)
        {
            _logger.LogInformation(
                "Integration already connected for this owner. PlatformCode={PlatformCode}, IntegrationId={IntegrationId}",
                normalizedPlatformCode,
                existingIntegration.Id);

            return IntegrationAvailabilityResult.ExistingForSameOwner(existingIntegration);
        }

        return IntegrationAvailabilityResult.Conflict(
            $"This {ResolvePlatformLabel(normalizedPlatformCode)} is already connected to another Dialogly account.");
    }

    private static string ResolvePlatformLabel(string platformCode)
    {
        return platformCode switch
        {
            "telegram" => "Telegram bot",
            "messenger" => "Facebook Page",
            _ => "integration account"
        };
    }
}
