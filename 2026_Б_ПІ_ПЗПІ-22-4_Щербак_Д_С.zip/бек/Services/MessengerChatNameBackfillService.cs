using Dialogly.Api.Data;
using Dialogly.Api.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Dialogly.Api.Services;

public class MessengerChatNameBackfillService(
    IServiceScopeFactory serviceScopeFactory,
    ILogger<MessengerChatNameBackfillService> logger) : BackgroundService
{
    private const string MessengerPlatformCode = "messenger";
    private const string MessengerPageAccessTokenCredentialType = "messenger_page_access_token";
    private const string PlaceholderPrefix = "Messenger user";

    private readonly IServiceScopeFactory _serviceScopeFactory = serviceScopeFactory;
    private readonly ILogger<MessengerChatNameBackfillService> _logger = logger;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await Task.Delay(TimeSpan.FromSeconds(2), stoppingToken);

            using var scope = _serviceScopeFactory.CreateScope();
            var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            var messengerService = scope.ServiceProvider.GetRequiredService<IMessengerService>();

            var chats = await dbContext.Chats
                .Include(x => x.Contact)
                .Include(x => x.Integration)
                    .ThenInclude(x => x.Platform)
                .Include(x => x.Integration)
                    .ThenInclude(x => x.Credentials)
                .Where(x =>
                    x.Integration.IsActive
                    && x.Integration.Status == "Connected"
                    && x.Integration.Platform.Code == MessengerPlatformCode
                    && (
                        (x.Title != null && x.Title.StartsWith(PlaceholderPrefix))
                        || x.Contact.DisplayName.StartsWith(PlaceholderPrefix)
                    ))
                .ToListAsync(stoppingToken);

            if (chats.Count == 0)
            {
                _logger.LogInformation("Messenger chat name backfill skipped: no placeholder chats found.");
                return;
            }

            var updatedCount = 0;
            foreach (var chat in chats)
            {
                if (stoppingToken.IsCancellationRequested)
                {
                    break;
                }

                var pageAccessToken = chat.Integration.Credentials
                    .FirstOrDefault(x => x.CredentialType == MessengerPageAccessTokenCredentialType)
                    ?.ValueEncrypted;

                if (string.IsNullOrWhiteSpace(pageAccessToken))
                {
                    _logger.LogWarning(
                        "Messenger chat name backfill skipped chat {ChatId}: page token missing.",
                        chat.Id);
                    continue;
                }

                var profileName = await messengerService.GetProfileNameAsync(
                    chat.ExternalChatId,
                    pageAccessToken,
                    stoppingToken);

                if (string.IsNullOrWhiteSpace(profileName))
                {
                    continue;
                }

                var changed = false;
                if (chat.Contact.DisplayName.StartsWith(PlaceholderPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    chat.Contact.DisplayName = profileName;
                    chat.Contact.UpdatedAt = DateTime.UtcNow;
                    changed = true;
                }

                if (string.IsNullOrWhiteSpace(chat.Title)
                    || chat.Title.StartsWith(PlaceholderPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    chat.Title = profileName;
                    chat.UpdatedAt = DateTime.UtcNow;
                    changed = true;
                }

                if (!changed)
                {
                    continue;
                }

                updatedCount += 1;
            }

            if (updatedCount > 0)
            {
                await dbContext.SaveChangesAsync(stoppingToken);
            }

            _logger.LogInformation(
                "Messenger chat name backfill completed. Placeholder chats checked: {Total}, updated: {Updated}.",
                chats.Count,
                updatedCount);
        }
        catch (OperationCanceledException)
        {
            // Normal shutdown.
        }
        catch (Exception exception)
        {
            _logger.LogError(exception, "Messenger chat name backfill failed. Continuing startup.");
        }
    }
}
