using System.Text.Json;
using Dialogly.Api.DTOs.Integrations;
using Dialogly.Api.Models;

namespace Dialogly.Api.Interfaces;

public interface IMessengerService
{
    Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> ConnectAsync(
        Guid userId,
        ConnectMessengerIntegrationRequestDto request,
        CancellationToken cancellationToken = default);

    Task<(bool Success, string? ErrorMessage, int StatusCode)> HandleWebhookAsync(
        JsonElement body,
        CancellationToken cancellationToken = default);

    Task<string?> GetProfileNameAsync(
        string psid,
        string pageAccessToken,
        CancellationToken cancellationToken = default);

    Task<(string? ExternalMessageId, string? ErrorMessage, int StatusCode)> SendGifAsync(
        string psid,
        string pageAccessToken,
        string gifUrl,
        CancellationToken cancellationToken = default);

    Task<(string? ExternalMessageId, string? ErrorMessage, int StatusCode)> SendAttachmentAsync(
        string psid,
        string pageAccessToken,
        Stream fileStream,
        string fileName,
        string? contentType,
        string? caption,
        CancellationToken cancellationToken = default);

    Task<(string? ExternalMessageId, string? ErrorMessage, int StatusCode)> SendTextMessageAsync(
        string psid,
        string pageAccessToken,
        string text,
        CancellationToken cancellationToken = default);
}
