namespace Dialogly.Api.Interfaces;

public interface IIpGeolocationService
{
    Task<string> ResolveLocationAsync(string? ipAddress, CancellationToken cancellationToken = default);
}
