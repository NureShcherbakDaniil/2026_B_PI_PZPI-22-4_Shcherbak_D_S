namespace Dialogly.Api.Interfaces;

public interface ITelegramWebhookRefreshService
{
    Task RefreshAllAsync(CancellationToken cancellationToken = default);
    Task<bool> TryRefreshIntegrationAsync(Guid integrationId, CancellationToken cancellationToken = default);
}
