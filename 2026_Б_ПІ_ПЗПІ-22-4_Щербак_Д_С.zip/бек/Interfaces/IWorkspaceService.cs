using Dialogly.Api.DTOs.Workspaces;

namespace Dialogly.Api.Interfaces;

public interface IWorkspaceService
{
    Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> CreateWorkspaceAsync(Guid userId, CreateWorkspaceRequestDto request, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<WorkspaceDto>> GetMyWorkspacesAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> GetWorkspaceAsync(Guid userId, Guid workspaceId, CancellationToken cancellationToken = default);
    Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> UpdateWorkspaceAsync(Guid userId, Guid workspaceId, UpdateWorkspaceRequestDto request, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<WorkspaceMemberDto>> GetWorkspaceMembersAsync(Guid userId, Guid workspaceId, CancellationToken cancellationToken = default);
    Task<(string? ErrorMessage, int StatusCode)> RemoveWorkspaceMemberAsync(Guid userId, Guid workspaceId, Guid memberUserId, CancellationToken cancellationToken = default);
    Task<(WorkspaceInviteDto? Response, string? ErrorMessage, int StatusCode)> CreateInviteAsync(Guid userId, Guid workspaceId, CreateWorkspaceInviteRequestDto request, string frontendBaseUrl, CancellationToken cancellationToken = default);
    Task<(IReadOnlyList<WorkspaceInviteDto>? Response, string? ErrorMessage, int StatusCode)> GetWorkspaceInvitesAsync(Guid userId, Guid workspaceId, string frontendBaseUrl, CancellationToken cancellationToken = default);
    Task<(WorkspaceInviteDto? Response, string? ErrorMessage, int StatusCode)> RevokeWorkspaceInviteAsync(Guid userId, Guid workspaceId, string token, string frontendBaseUrl, CancellationToken cancellationToken = default);
    Task<WorkspaceInviteValidationDto> ValidateInviteAsync(string token, CancellationToken cancellationToken = default);
    Task<(AcceptWorkspaceInviteResponseDto? Response, string? ErrorMessage, int StatusCode)> AcceptInviteAsync(Guid userId, string token, CancellationToken cancellationToken = default);
    Task<(WorkspaceDto? Response, string? ErrorMessage, int StatusCode)> JoinWorkspaceAsync(Guid userId, string inviteCode, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<AccountContextDto>> GetAccountContextsAsync(Guid userId, CancellationToken cancellationToken = default);
}
