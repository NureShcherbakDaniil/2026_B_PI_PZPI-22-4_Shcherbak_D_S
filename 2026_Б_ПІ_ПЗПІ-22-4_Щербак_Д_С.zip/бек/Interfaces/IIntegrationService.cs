using Dialogly.Api.DTOs.Integrations;
using Dialogly.Api.DTOs.Telegram;

namespace Dialogly.Api.Interfaces;

public interface IIntegrationService
{
    Task<IReadOnlyList<PlatformDto>> GetPlatformsAsync(CancellationToken cancellationToken = default);
    Task<(IReadOnlyList<IntegrationAccountDto> Response, string? ErrorMessage, int StatusCode)> GetIntegrationsAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> ConnectIntegrationAsync(Guid userId, ConnectIntegrationRequestDto request, CancellationToken cancellationToken = default);
    Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> ConnectTelegramBotAsync(Guid userId, ConnectTelegramIntegrationRequestDto request, CancellationToken cancellationToken = default);
    Task<(IntegrationAccountDto? Response, string? ErrorMessage, int StatusCode)> DisconnectIntegrationAsync(Guid userId, Guid integrationId, CancellationToken cancellationToken = default);
    Task<(object? Response, string? ErrorMessage, int StatusCode)> SetTelegramWebhookAsync(Guid userId, Guid integrationId, SetTelegramWebhookRequestDto request, CancellationToken cancellationToken = default);
    Task<(bool Success, string? ErrorMessage, int StatusCode)> HandleTelegramWebhookAsync(Guid integrationId, TelegramUpdateDto update, CancellationToken cancellationToken = default);
}
