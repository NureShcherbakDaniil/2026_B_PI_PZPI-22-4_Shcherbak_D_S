using Dialogly.Api.Dtos.Chats;

namespace Dialogly.Api.Interfaces;

public interface IChatService
{
    Task<(IReadOnlyList<ChatListItemDto> Response, string? ErrorMessage, int StatusCode)> GetChatsAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(IReadOnlyList<ChatListItemDto> Response, string? ErrorMessage, int StatusCode)> GetArchivedChatsAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> GetChatAsync(Guid userId, Guid chatId, CancellationToken cancellationToken = default);
    Task<(IReadOnlyList<MessageDto> Response, string? ErrorMessage, int StatusCode)> GetChatMessagesAsync(Guid userId, Guid chatId, CancellationToken cancellationToken = default);
    Task<(AttachmentContentDto? Response, string? ErrorMessage, int StatusCode)> GetAttachmentAsync(Guid userId, Guid attachmentId, CancellationToken cancellationToken = default);
    Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> UpdateChatCustomDetailsAsync(Guid userId, Guid chatId, UpdateChatCustomDetailsRequestDto request, CancellationToken cancellationToken = default);
    Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> UpdateChatArchiveAsync(Guid userId, Guid chatId, UpdateChatArchiveRequestDto request, CancellationToken cancellationToken = default);
    Task<(MessageDto? Response, string? ErrorMessage, int StatusCode)> SendMessageAsync(Guid userId, Guid chatId, SendMessageRequestDto request, CancellationToken cancellationToken = default);
    Task<(MessageDto? Response, string? ErrorMessage, int StatusCode)> UpdateMessageReactionAsync(Guid userId, Guid messageId, UpdateMessageReactionRequestDto request, CancellationToken cancellationToken = default);
    Task<(int? UnreadCount, string? ErrorMessage, int StatusCode)> MarkChatAsReadAsync(Guid userId, Guid chatId, CancellationToken cancellationToken = default);
    Task<(ChatDetailsDto? Response, string? ErrorMessage, int StatusCode)> CreateMockChatAsync(Guid userId, CreateMockChatRequestDto request, CancellationToken cancellationToken = default);
}
