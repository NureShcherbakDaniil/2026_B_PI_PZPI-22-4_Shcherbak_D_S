using Dialogly.Api.DTOs.Auth;
using Dialogly.Api.DTOs.Users;

namespace Dialogly.Api.Interfaces;

public interface IAuthService
{
    Task<(AuthResponseDto? Response, string? ErrorMessage, int StatusCode)> RegisterAsync(RegisterRequestDto request, CancellationToken cancellationToken = default);
    Task<(AuthResponseDto? Response, string? ErrorMessage, int StatusCode)> LoginAsync(LoginRequestDto request, string? userAgent, string? ipAddress, CancellationToken cancellationToken = default);
    Task<(EmailVerificationResponseDto? Response, string? ErrorMessage, int StatusCode)> VerifyEmailAsync(VerifyEmailRequestDto request, CancellationToken cancellationToken = default);
    Task<(EmailVerificationResponseDto? Response, string? ErrorMessage, int StatusCode)> ResendVerificationCodeAsync(ResendVerificationCodeRequestDto request, CancellationToken cancellationToken = default);
    Task<ForgotPasswordResponseDto> ForgotPasswordAsync(ForgotPasswordRequestDto request, CancellationToken cancellationToken = default);
    Task<(ForgotPasswordResponseDto? Response, string? ErrorMessage, int StatusCode)> ResendPasswordResetCodeAsync(ResendPasswordResetCodeRequestDto request, CancellationToken cancellationToken = default);
    Task<(ResetPasswordResponseDto? Response, string? ErrorMessage, int StatusCode)> ResetPasswordAsync(ResetPasswordRequestDto request, CancellationToken cancellationToken = default);
    Task<(ChangePasswordResponseDto? Response, string? ErrorMessage, int StatusCode)> ChangePasswordAsync(Guid userId, ChangePasswordRequestDto request, CancellationToken cancellationToken = default);
    Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> RequestAccountDeletionCodeAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> ConfirmAccountDeletionAsync(Guid userId, DeleteAccountRequestDto request, CancellationToken cancellationToken = default);
    Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> ResendAccountDeletionCodeAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<UserSessionDto>> GetActiveSessionsAsync(Guid userId, string? currentSessionJti, CancellationToken cancellationToken = default);
    Task<(SessionOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> RevokeSessionAsync(Guid userId, Guid sessionId, string? currentSessionJti, CancellationToken cancellationToken = default);
    Task<TwoFactorStatusDto?> GetTwoFactorStatusAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(TwoFactorSetupResponseDto? Response, string? ErrorMessage, int StatusCode)> GetTwoFactorSetupAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(TwoFactorOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> ConfirmTwoFactorSetupAsync(Guid userId, TwoFactorConfirmSetupRequestDto request, CancellationToken cancellationToken = default);
    Task<(TwoFactorOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> EnableTwoFactorAsync(Guid userId, TwoFactorEnableRequestDto request, CancellationToken cancellationToken = default);
    Task<(TwoFactorOperationResponseDto? Response, string? ErrorMessage, int StatusCode)> DisableTwoFactorAsync(Guid userId, TwoFactorCodeRequestDto request, CancellationToken cancellationToken = default);
    Task<(AuthResponseDto? Response, string? ErrorMessage, int StatusCode)> VerifyTwoFactorLoginAsync(TwoFactorVerifyRequestDto request, string? userAgent, string? ipAddress, CancellationToken cancellationToken = default);
    Task<bool> ValidateActiveSessionAsync(Guid userId, string sessionJti, CancellationToken cancellationToken = default);
    Task TouchActiveSessionAsync(Guid userId, string sessionJti, CancellationToken cancellationToken = default);
    Task<CurrentUserDto?> GetCurrentUserAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<CurrentUserSettingsDto> GetCurrentUserSettingsAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(CurrentUserDto? Response, string? ErrorMessage, int StatusCode)> UpdateCurrentUserProfileAsync(Guid userId, UpdateCurrentUserProfileRequestDto request, CancellationToken cancellationToken = default);
    Task<(CurrentUserSettingsDto? Response, string? ErrorMessage, int StatusCode)> UpdateCurrentUserSettingsAsync(Guid userId, UpdateCurrentUserSettingsRequestDto request, CancellationToken cancellationToken = default);
    Task<SecuritySettingsDto> GetSecuritySettingsAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<(SecuritySettingsDto? Response, string? ErrorMessage, int StatusCode)> UpdateSecuritySettingsAsync(Guid userId, UpdateSecuritySettingsRequestDto request, CancellationToken cancellationToken = default);
    Task<CurrentUserDto?> UpdateOnboardingStatusAsync(Guid userId, bool? completed, string? workspaceChoice, CancellationToken cancellationToken = default);
    Task<(CurrentUserDto? Response, string? ErrorMessage, int StatusCode)> UpdateActiveWorkspaceAsync(Guid userId, Guid? workspaceId, CancellationToken cancellationToken = default);
}
