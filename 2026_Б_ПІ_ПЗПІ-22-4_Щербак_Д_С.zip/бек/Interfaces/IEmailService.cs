namespace Dialogly.Api.Interfaces;

public interface IEmailService
{
    Task SendVerificationCodeAsync(string email, string code, CancellationToken cancellationToken = default);
    Task SendPasswordResetCodeAsync(string email, string code, CancellationToken cancellationToken = default);
    Task SendAccountDeletionCodeAsync(string email, string code, CancellationToken cancellationToken = default);
    Task SendLoginAlertAsync(string email, string device, string location, DateTimeOffset occurredAt, CancellationToken cancellationToken = default);
}
