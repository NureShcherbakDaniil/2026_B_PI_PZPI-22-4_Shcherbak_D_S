using Dialogly.Api.DTOs.Telegram;

namespace Dialogly.Api.Interfaces;

public interface ITelegramService
{
    Task<TelegramBotInfoDto?> ValidateBotTokenAsync(string botToken, CancellationToken cancellationToken = default);
    Task<TelegramSendMessageResponseDto?> SendMessageAsync(string botToken, string chatId, string text, CancellationToken cancellationToken = default);
    Task<TelegramSendMessageResponseDto?> SendAnimationAsync(string botToken, string chatId, string animationUrl, string? caption = null, CancellationToken cancellationToken = default);
    Task<TelegramSendMessageResponseDto?> SendPhotoAsync(string botToken, string chatId, Stream photoStream, string fileName, string? contentType = null, string? caption = null, CancellationToken cancellationToken = default);
    Task<TelegramSendMessageResponseDto?> SendDocumentAsync(string botToken, string chatId, Stream documentStream, string fileName, string? contentType = null, string? caption = null, CancellationToken cancellationToken = default);
    Task<TelegramSetWebhookResponseDto?> SetMessageReactionAsync(string botToken, string chatId, int messageId, string? emoji, CancellationToken cancellationToken = default);
    Task<TelegramSetWebhookResponseDto?> SetWebhookAsync(string botToken, string webhookUrl, string? secretToken = null, IReadOnlyCollection<string>? allowedUpdates = null, CancellationToken cancellationToken = default);
    Task<TelegramFileDto?> GetFileAsync(string botToken, string fileId, CancellationToken cancellationToken = default);
    Task<(byte[] Content, string? ContentType)?> DownloadFileAsync(string botToken, string filePath, CancellationToken cancellationToken = default);
}
