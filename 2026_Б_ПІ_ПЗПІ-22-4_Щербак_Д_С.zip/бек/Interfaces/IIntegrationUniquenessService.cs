using Dialogly.Api.Models;

namespace Dialogly.Api.Interfaces;

public interface IIntegrationUniquenessService
{
    Task<IntegrationAvailabilityResult> EnsureIntegrationIsAvailableAsync(
        string platformCode,
        string externalAccountId,
        Guid currentUserId,
        Guid? workspaceId,
        CancellationToken cancellationToken = default);
}

public sealed record IntegrationAvailabilityResult(
    bool IsAvailable,
    Integration? ExistingIntegration,
    string? ErrorMessage,
    int StatusCode)
{
    public static IntegrationAvailabilityResult Available() =>
        new(true, null, null, StatusCodes.Status200OK);

    public static IntegrationAvailabilityResult ExistingForSameOwner(Integration integration) =>
        new(true, integration, null, StatusCodes.Status200OK);

    public static IntegrationAvailabilityResult Conflict(string message) =>
        new(false, null, message, StatusCodes.Status409Conflict);
}
