using Dialogly.Api.Models;

namespace Dialogly.Api.Interfaces;

public interface IJwtService
{
    string GenerateToken(User user, string? sessionJti = null);
    string GenerateTwoFactorTempToken(User user, string secret);
    bool TryValidateTwoFactorTempToken(string token, out Guid userId, out string secret);
}
