namespace Dialogly.Api.Models;

public class Integration
{
    public Guid Id { get; set; }
    public Guid? PersonalAccountId { get; set; }
    public Guid? WorkspaceId { get; set; }
    public Guid PlatformId { get; set; }
    public string? ExternalAccountId { get; set; }
    public string DisplayName { get; set; } = string.Empty;
    public string? Username { get; set; }
    public string Status { get; set; } = "Active";
    public Guid? ConnectedByUserId { get; set; }
    public DateTime? ConnectedAt { get; set; }
    public DateTime? LastSyncAt { get; set; }
    public DateTime? DisconnectedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public bool IsActive { get; set; } = true;

    public PersonalAccount? PersonalAccount { get; set; }
    public Workspace? Workspace { get; set; }
    public Platform Platform { get; set; } = null!;
    public User? ConnectedByUser { get; set; }
    public List<IntegrationCredential> Credentials { get; set; } = [];
    public List<Contact> Contacts { get; set; } = [];
    public List<Chat> Chats { get; set; } = [];
}
