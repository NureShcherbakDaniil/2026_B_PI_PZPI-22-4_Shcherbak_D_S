namespace Dialogly.Api.Models;

public class Contact
{
    public Guid Id { get; set; }
    public Guid IntegrationId { get; set; }
    public string ExternalContactId { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string? Username { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? AvatarUrl { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public Integration Integration { get; set; } = null!;
    public List<Chat> Chats { get; set; } = [];
}
