namespace Dialogly.Api.Models;

public class Platform
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;

    public List<Integration> Integrations { get; set; } = [];
}
