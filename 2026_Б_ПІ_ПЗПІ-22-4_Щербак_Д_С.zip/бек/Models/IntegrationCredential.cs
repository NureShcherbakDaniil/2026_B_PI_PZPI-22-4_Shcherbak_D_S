namespace Dialogly.Api.Models;

public class IntegrationCredential
{
    public Guid Id { get; set; }
    public Guid IntegrationId { get; set; }
    public string CredentialType { get; set; } = string.Empty;
    public string ValueEncrypted { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public Integration Integration { get; set; } = null!;
}
