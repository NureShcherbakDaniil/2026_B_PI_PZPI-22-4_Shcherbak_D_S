namespace Dialogly.Api.Models;

public class Workspace
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Website { get; set; }
    public string? Description { get; set; }
    public string? LogoUrl { get; set; }
    public string? Industry { get; set; }
    public string? Timezone { get; set; }
    public string? DefaultLanguage { get; set; }
    public string PublicSenderName { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public bool IsActive { get; set; } = true;

    public List<WorkspaceMember> Members { get; set; } = [];
    public List<WorkspaceInvite> Invites { get; set; } = [];
    public List<Integration> Integrations { get; set; } = [];
}
