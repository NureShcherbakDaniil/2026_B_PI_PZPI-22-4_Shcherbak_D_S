namespace Dialogly.Api.Models;

public class Message
{
    public Guid Id { get; set; }
    public Guid ChatId { get; set; }
    public string? ExternalMessageId { get; set; }
    public string? Text { get; set; }
    public string? DialoglyReaction { get; set; }
    public string? TelegramReaction { get; set; }
    public string Direction { get; set; } = "Inbound";
    public string MessageType { get; set; } = "Text";
    public Guid? CreatedByUserId { get; set; }
    public string? SenderDisplayName { get; set; }
    public DateTime SentAt { get; set; } = DateTime.UtcNow;
    public DateTime? DeliveredAt { get; set; }
    public bool IsEdited { get; set; }
    public DateTime? EditedAt { get; set; }
    public bool IsDeleted { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Chat Chat { get; set; } = null!;
    public User? CreatedByUser { get; set; }
    public List<MessageRead> Reads { get; set; } = [];
    public List<MessageAttachment> Attachments { get; set; } = [];
}
