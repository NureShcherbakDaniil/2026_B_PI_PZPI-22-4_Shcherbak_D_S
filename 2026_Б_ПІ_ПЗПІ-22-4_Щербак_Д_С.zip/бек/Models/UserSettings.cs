namespace Dialogly.Api.Models;

public class UserSettings
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public bool IsTourCompleted { get; set; } = false;
    public bool NotificationsEnabled { get; set; } = true;
    public bool SoundEnabled { get; set; } = false;
    public bool LoginAlertsEnabled { get; set; } = true;
    public bool QuietHoursEnabled { get; set; } = false;
    public string QuietHoursStart { get; set; } = "22:00";
    public string QuietHoursEnd { get; set; } = "08:00";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public User User { get; set; } = null!;
}
