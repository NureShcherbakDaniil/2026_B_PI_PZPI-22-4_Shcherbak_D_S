namespace Dialogly.Api.Models;

public class Chat
{
    public Guid Id { get; set; }
    public Guid IntegrationId { get; set; }
    public Guid ContactId { get; set; }
    public string ExternalChatId { get; set; } = string.Empty;
    public string? Title { get; set; }
    public string? CustomName { get; set; }
    public string? Notes { get; set; }
    public string Status { get; set; } = "Open";
    public Guid? AssignedToUserId { get; set; }
    public string? LastMessageText { get; set; }
    public DateTime? LastMessageAt { get; set; }
    public int UnreadCount { get; set; }
    public bool IsPinned { get; set; }
    public bool IsArchived { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public Integration Integration { get; set; } = null!;
    public Contact Contact { get; set; } = null!;
    public User? AssignedToUser { get; set; }

    public List<Message> Messages { get; set; } = [];
}
