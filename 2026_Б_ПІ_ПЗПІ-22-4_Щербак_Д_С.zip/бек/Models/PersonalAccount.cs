namespace Dialogly.Api.Models;

public class PersonalAccount
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public string DisplayName { get; set; } = string.Empty;
    public string? PublicSenderName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public bool IsActive { get; set; } = true;

    public User User { get; set; } = null!;
    public List<Integration> Integrations { get; set; } = [];
}
