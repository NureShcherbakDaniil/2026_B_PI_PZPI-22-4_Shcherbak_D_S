using System.ComponentModel.DataAnnotations.Schema;

namespace Dialogly.Api.Models;

public class User
{
    public Guid Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string? AvatarUrl { get; set; }
    public bool TwoFactorEnabled { get; set; } = false;
    public string? TwoFactorSecret { get; set; }
    public bool IsOnboardingCompleted { get; set; } = false;
    public string? OnboardingWorkspaceChoice { get; set; }
    public Guid? ActiveWorkspaceId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; } = false;
    public DateTime? DeletedAt { get; set; }
    public bool EmailConfirmed { get; set; } = true;

    [NotMapped]
    public string FullName => $"{FirstName} {LastName}".Trim();

    public List<PersonalAccount> PersonalAccounts { get; set; } = [];
    public List<WorkspaceMember> WorkspaceMemberships { get; set; } = [];
    public List<WorkspaceMember> InvitedWorkspaceMembers { get; set; } = [];
    public List<WorkspaceInvite> CreatedWorkspaceInvites { get; set; } = [];
    public List<WorkspaceInvite> UsedWorkspaceInvites { get; set; } = [];
    public List<Chat> AssignedChats { get; set; } = [];
    public List<Message> CreatedMessages { get; set; } = [];
    public List<MessageRead> MessageReads { get; set; } = [];
    public List<Integration> ConnectedIntegrations { get; set; } = [];
    public List<PasswordResetToken> PasswordResetTokens { get; set; } = [];
    public List<PasswordResetCode> PasswordResetCodes { get; set; } = [];
    public List<EmailVerificationCode> EmailVerificationCodes { get; set; } = [];
    public List<AccountDeletionCode> AccountDeletionCodes { get; set; } = [];
    public List<UserSession> Sessions { get; set; } = [];
    public UserSettings? Settings { get; set; }

    [NotMapped]
    public bool IsFirstLogin => !IsOnboardingCompleted;
}
