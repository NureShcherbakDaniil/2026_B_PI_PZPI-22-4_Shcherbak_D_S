namespace Dialogly.Api.Models;

public class WorkspaceInvite
{
    public Guid Id { get; set; }
    public Guid WorkspaceId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string InviteLinkToken { get; set; } = string.Empty;
    public string Role { get; set; } = "Member";
    public Guid CreatedByUserId { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public bool IsUsed { get; set; }
    public Guid? UsedByUserId { get; set; }
    public DateTime? UsedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsActive { get; set; } = true;

    public Workspace Workspace { get; set; } = null!;
    public User CreatedByUser { get; set; } = null!;
    public User? UsedByUser { get; set; }
}
