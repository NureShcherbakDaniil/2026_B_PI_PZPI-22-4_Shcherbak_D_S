using Dialogly.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Dialogly.Api.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Workspace> Workspaces => Set<Workspace>();
    public DbSet<WorkspaceMember> WorkspaceMembers => Set<WorkspaceMember>();
    public DbSet<WorkspaceInvite> WorkspaceInvites => Set<WorkspaceInvite>();
    public DbSet<Platform> Platforms => Set<Platform>();
    public DbSet<PersonalAccount> PersonalAccounts => Set<PersonalAccount>();
    public DbSet<Integration> Integrations => Set<Integration>();
    public DbSet<IntegrationCredential> IntegrationCredentials => Set<IntegrationCredential>();
    public DbSet<Contact> Contacts => Set<Contact>();
    public DbSet<Chat> Chats => Set<Chat>();
    public DbSet<Message> Messages => Set<Message>();
    public DbSet<MessageRead> MessageReads => Set<MessageRead>();
    public DbSet<MessageAttachment> MessageAttachments => Set<MessageAttachment>();
    public DbSet<PasswordResetToken> PasswordResetTokens => Set<PasswordResetToken>();
    public DbSet<PasswordResetCode> PasswordResetCodes => Set<PasswordResetCode>();
    public DbSet<EmailVerificationCode> EmailVerificationCodes => Set<EmailVerificationCode>();
    public DbSet<AccountDeletionCode> AccountDeletionCodes => Set<AccountDeletionCode>();
    public DbSet<UserSettings> UserSettings => Set<UserSettings>();
    public DbSet<UserSession> UserSessions => Set<UserSession>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("Users");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.FirstName).IsRequired().HasMaxLength(40);
            entity.Property(x => x.LastName).IsRequired().HasMaxLength(40);
            entity.Property(x => x.Email).IsRequired().HasMaxLength(254);
            entity.HasIndex(x => x.Email).HasDatabaseName("UX_Users_Email").IsUnique();
            entity.Property(x => x.PasswordHash).IsRequired().HasMaxLength(500);
            entity.Property(x => x.AvatarUrl).HasMaxLength(500);
            entity.Property(x => x.TwoFactorEnabled).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.TwoFactorSecret).HasMaxLength(256);
            entity.Property(x => x.IsOnboardingCompleted).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.ActiveWorkspaceId);
            entity.Property(x => x.OnboardingWorkspaceChoice).HasMaxLength(20);
            entity.Property(x => x.ActiveWorkspaceId);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.Property(x => x.IsDeleted).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.DeletedAt);
            entity.Property(x => x.EmailConfirmed).IsRequired().HasDefaultValue(true);
        });

        modelBuilder.Entity<EmailVerificationCode>(entity =>
        {
            entity.ToTable("EmailVerificationCodes");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Email).IsRequired().HasMaxLength(254);
            entity.Property(x => x.CodeHash).IsRequired().HasMaxLength(100);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.ExpiresAt).IsRequired();
            entity.Property(x => x.UsedAt);
            entity.Property(x => x.AttemptsCount).IsRequired().HasDefaultValue(0);
            entity.HasIndex(x => x.Email).HasDatabaseName("IX_EmailVerificationCodes_Email");
            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_EmailVerificationCodes_UserId");
            entity.HasIndex(x => x.ExpiresAt).HasDatabaseName("IX_EmailVerificationCodes_ExpiresAt");

            entity.HasOne(x => x.User)
                .WithMany(x => x.EmailVerificationCodes)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<PasswordResetCode>(entity =>
        {
            entity.ToTable("PasswordResetCodes");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Email).IsRequired().HasMaxLength(254);
            entity.Property(x => x.CodeHash).IsRequired().HasMaxLength(100);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.ExpiresAt).IsRequired();
            entity.Property(x => x.UsedAt);
            entity.Property(x => x.AttemptsCount).IsRequired().HasDefaultValue(0);
            entity.HasIndex(x => x.Email).HasDatabaseName("IX_PasswordResetCodes_Email");
            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_PasswordResetCodes_UserId");
            entity.HasIndex(x => x.ExpiresAt).HasDatabaseName("IX_PasswordResetCodes_ExpiresAt");

            entity.HasOne(x => x.User)
                .WithMany(x => x.PasswordResetCodes)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<AccountDeletionCode>(entity =>
        {
            entity.ToTable("AccountDeletionCodes");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Email).IsRequired().HasMaxLength(254);
            entity.Property(x => x.CodeHash).IsRequired().HasMaxLength(100);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.ExpiresAt).IsRequired();
            entity.Property(x => x.UsedAt);
            entity.Property(x => x.AttemptsCount).IsRequired().HasDefaultValue(0);
            entity.HasIndex(x => x.Email).HasDatabaseName("IX_AccountDeletionCodes_Email");
            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_AccountDeletionCodes_UserId");
            entity.HasIndex(x => x.ExpiresAt).HasDatabaseName("IX_AccountDeletionCodes_ExpiresAt");

            entity.HasOne(x => x.User)
                .WithMany(x => x.AccountDeletionCodes)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<PasswordResetToken>(entity =>
        {
            entity.ToTable("PasswordResetTokens");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Token).IsRequired().HasMaxLength(128);
            entity.Property(x => x.ExpiresAt).IsRequired();
            entity.Property(x => x.IsUsed).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.HasIndex(x => x.Token).HasDatabaseName("UX_PasswordResetTokens_Token").IsUnique();
            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_PasswordResetTokens_UserId");

            entity.HasOne(x => x.User)
                .WithMany(x => x.PasswordResetTokens)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<UserSettings>(entity =>
        {
            entity.ToTable("UserSettings");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.IsTourCompleted).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.NotificationsEnabled).IsRequired().HasDefaultValue(true);
            entity.Property(x => x.SoundEnabled).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.LoginAlertsEnabled).IsRequired().HasDefaultValue(true);
            entity.Property(x => x.QuietHoursEnabled).IsRequired().HasDefaultValue(false);
            entity.Property(x => x.QuietHoursStart).IsRequired().HasMaxLength(5).HasDefaultValue("22:00");
            entity.Property(x => x.QuietHoursEnd).IsRequired().HasMaxLength(5).HasDefaultValue("08:00");
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.UpdatedAt);
            entity.HasIndex(x => x.UserId).HasDatabaseName("UX_UserSettings_UserId").IsUnique();

            entity.HasOne(x => x.User)
                .WithOne(x => x.Settings)
                .HasForeignKey<UserSettings>(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Workspace>(entity =>
        {
            entity.ToTable("Workspaces");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired().HasMaxLength(200);
            entity.Property(x => x.Website).HasMaxLength(255);
            entity.Property(x => x.LogoUrl).HasMaxLength(500);
            entity.Property(x => x.Industry).HasMaxLength(100);
            entity.Property(x => x.Timezone).HasMaxLength(100);
            entity.Property(x => x.DefaultLanguage).HasMaxLength(20);
            entity.Property(x => x.PublicSenderName).IsRequired().HasMaxLength(200);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
        });

        modelBuilder.Entity<WorkspaceMember>(entity =>
        {
            entity.ToTable("WorkspaceMembers");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Role).IsRequired().HasMaxLength(20);
            entity.Property(x => x.JoinedAt).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.HasIndex(x => new { x.WorkspaceId, x.UserId })
                .HasDatabaseName("UX_WorkspaceMembers_Workspace_User")
                .IsUnique();

            entity.HasOne(x => x.Workspace)
                .WithMany(x => x.Members)
                .HasForeignKey(x => x.WorkspaceId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.User)
                .WithMany(x => x.WorkspaceMemberships)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.NoAction);

            entity.HasOne(x => x.InvitedByUser)
                .WithMany(x => x.InvitedWorkspaceMembers)
                .HasForeignKey(x => x.InvitedByUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<WorkspaceInvite>(entity =>
        {
            entity.ToTable("WorkspaceInvites");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Code).IsRequired().HasMaxLength(100);
            entity.Property(x => x.InviteLinkToken).IsRequired().HasMaxLength(200);
            entity.Property(x => x.Role).IsRequired().HasMaxLength(20);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.HasIndex(x => x.Code).HasDatabaseName("UX_WorkspaceInvites_Code").IsUnique();
            entity.HasIndex(x => x.InviteLinkToken).HasDatabaseName("UX_WorkspaceInvites_InviteLinkToken").IsUnique();

            entity.HasOne(x => x.Workspace)
                .WithMany(x => x.Invites)
                .HasForeignKey(x => x.WorkspaceId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.CreatedByUser)
                .WithMany(x => x.CreatedWorkspaceInvites)
                .HasForeignKey(x => x.CreatedByUserId)
                .OnDelete(DeleteBehavior.NoAction);

            entity.HasOne(x => x.UsedByUser)
                .WithMany(x => x.UsedWorkspaceInvites)
                .HasForeignKey(x => x.UsedByUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Platform>(entity =>
        {
            entity.ToTable("Platforms");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Name).IsRequired().HasMaxLength(100);
            entity.Property(x => x.Code).IsRequired().HasMaxLength(50);
            entity.Property(x => x.IsActive).IsRequired();
            entity.HasIndex(x => x.Code).HasDatabaseName("UX_Platforms_Code").IsUnique();

            entity.HasData(
                new Platform { Id = Guid.Parse("04559849-6af7-4efc-9a95-a4d9c77d46fd"), Name = "Telegram", Code = "telegram", IsActive = true },
                new Platform { Id = Guid.Parse("79ecdf94-a165-46e1-b88d-1967a6d08f85"), Name = "Instagram", Code = "instagram", IsActive = true },
                new Platform { Id = Guid.Parse("62ed873b-c37f-48a3-b986-b3faad304ed2"), Name = "Messenger", Code = "messenger", IsActive = true },
                new Platform { Id = Guid.Parse("daef8bc2-a924-40d9-b83b-1b4e5be38bc9"), Name = "Viber", Code = "viber", IsActive = true },
                new Platform { Id = Guid.Parse("e4ac567b-b29a-4b16-8a9b-2262418c26f0"), Name = "WhatsApp", Code = "whatsapp", IsActive = true }
            );
        });

        modelBuilder.Entity<PersonalAccount>(entity =>
        {
            entity.ToTable("PersonalAccounts");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.DisplayName).IsRequired().HasMaxLength(200);
            entity.Property(x => x.PublicSenderName).HasMaxLength(200);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_PersonalAccounts_UserId");

            entity.HasOne(x => x.User)
                .WithMany(x => x.PersonalAccounts)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.NoAction);
        });

        modelBuilder.Entity<Integration>(entity =>
        {
            entity.ToTable("Integrations");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ExternalAccountId).HasMaxLength(255);
            entity.Property(x => x.DisplayName).IsRequired().HasMaxLength(255);
            entity.Property(x => x.Username).HasMaxLength(255);
            entity.Property(x => x.Status).IsRequired().HasMaxLength(20);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.Property(x => x.DisconnectedAt);
            entity.HasIndex(x => x.PersonalAccountId).HasDatabaseName("IX_Integrations_PersonalAccountId");
            entity.HasIndex(x => x.PlatformId).HasDatabaseName("IX_Integrations_PlatformId");
            entity.HasIndex(x => x.WorkspaceId).HasDatabaseName("IX_Integrations_WorkspaceId");
            entity.HasIndex(x => new { x.PlatformId, x.ExternalAccountId })
                .HasDatabaseName("UX_Integrations_Platform_ExternalAccount_Active")
                .IsUnique()
                .HasFilter("[ExternalAccountId] IS NOT NULL AND [IsActive] = 1 AND [DisconnectedAt] IS NULL");

            entity.HasOne(x => x.PersonalAccount)
                .WithMany(x => x.Integrations)
                .HasForeignKey(x => x.PersonalAccountId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.Workspace)
                .WithMany(x => x.Integrations)
                .HasForeignKey(x => x.WorkspaceId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.Platform)
                .WithMany(x => x.Integrations)
                .HasForeignKey(x => x.PlatformId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.ConnectedByUser)
                .WithMany(x => x.ConnectedIntegrations)
                .HasForeignKey(x => x.ConnectedByUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<IntegrationCredential>(entity =>
        {
            entity.ToTable("IntegrationCredentials");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.CredentialType).IsRequired().HasMaxLength(50);
            entity.Property(x => x.ValueEncrypted).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.HasIndex(x => x.IntegrationId).HasDatabaseName("IX_IntegrationCredentials_IntegrationId");

            entity.HasOne(x => x.Integration)
                .WithMany(x => x.Credentials)
                .HasForeignKey(x => x.IntegrationId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<UserSession>(entity =>
        {
            entity.ToTable("UserSessions");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.DeviceName).IsRequired().HasMaxLength(200);
            entity.Property(x => x.OS).IsRequired().HasMaxLength(200);
            entity.Property(x => x.Browser).IsRequired().HasMaxLength(200);
            entity.Property(x => x.IpAddress).IsRequired().HasMaxLength(100);
            entity.Property(x => x.Location).IsRequired().HasMaxLength(200);
            entity.Property(x => x.TokenJti).IsRequired().HasMaxLength(100);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.LastActiveAt).IsRequired();
            entity.Property(x => x.IsRevoked).IsRequired().HasDefaultValue(false);
            entity.HasIndex(x => x.UserId).HasDatabaseName("IX_UserSessions_UserId");
            entity.HasIndex(x => x.TokenJti).HasDatabaseName("UX_UserSessions_TokenJti").IsUnique();

            entity.HasOne(x => x.User)
                .WithMany(x => x.Sessions)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Contact>(entity =>
        {
            entity.ToTable("Contacts");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ExternalContactId).IsRequired().HasMaxLength(255);
            entity.Property(x => x.DisplayName).IsRequired().HasMaxLength(255);
            entity.Property(x => x.Username).HasMaxLength(255);
            entity.Property(x => x.Phone).HasMaxLength(50);
            entity.Property(x => x.Email).HasMaxLength(254);
            entity.Property(x => x.AvatarUrl).HasMaxLength(500);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.HasIndex(x => x.IntegrationId).HasDatabaseName("IX_Contacts_IntegrationId");
            entity.HasIndex(x => new { x.IntegrationId, x.ExternalContactId })
                .HasDatabaseName("UX_Contacts_Integration_ExternalContact")
                .IsUnique();

            entity.HasOne(x => x.Integration)
                .WithMany(x => x.Contacts)
                .HasForeignKey(x => x.IntegrationId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Chat>(entity =>
        {
            entity.ToTable("Chats");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ExternalChatId).IsRequired().HasMaxLength(255);
            entity.Property(x => x.Title).HasMaxLength(255);
            entity.Property(x => x.CustomName).HasMaxLength(255);
            entity.Property(x => x.Notes).HasMaxLength(2000);
            entity.Property(x => x.Status).IsRequired().HasMaxLength(20);
            entity.Property(x => x.LastMessageText);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.Property(x => x.IsPinned).IsRequired();
            entity.Property(x => x.IsArchived).IsRequired();
            entity.HasIndex(x => x.AssignedToUserId).HasDatabaseName("IX_Chats_AssignedToUserId");
            entity.HasIndex(x => x.ContactId).HasDatabaseName("IX_Chats_ContactId");
            entity.HasIndex(x => x.IntegrationId).HasDatabaseName("IX_Chats_IntegrationId");
            entity.HasIndex(x => new { x.IntegrationId, x.ExternalChatId })
                .HasDatabaseName("UX_Chats_Integration_ExternalChat")
                .IsUnique();

            entity.HasOne(x => x.Integration)
                .WithMany(x => x.Chats)
                .HasForeignKey(x => x.IntegrationId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.Contact)
                .WithMany(x => x.Chats)
                .HasForeignKey(x => x.ContactId)
                .OnDelete(DeleteBehavior.NoAction);

            entity.HasOne(x => x.AssignedToUser)
                .WithMany(x => x.AssignedChats)
                .HasForeignKey(x => x.AssignedToUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Message>(entity =>
        {
            entity.ToTable("Messages");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ExternalMessageId).HasMaxLength(255);
            entity.Property(x => x.Text);
            entity.Property(x => x.DialoglyReaction).HasMaxLength(32);
            entity.Property(x => x.TelegramReaction).HasMaxLength(32);
            entity.Property(x => x.Direction).IsRequired().HasMaxLength(20);
            entity.Property(x => x.MessageType).IsRequired().HasMaxLength(20);
            entity.Property(x => x.SenderDisplayName).HasMaxLength(255);
            entity.Property(x => x.SentAt).IsRequired();
            entity.Property(x => x.IsEdited).IsRequired();
            entity.Property(x => x.IsDeleted).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.HasIndex(x => x.ChatId).HasDatabaseName("IX_Messages_ChatId");
            entity.HasIndex(x => x.CreatedByUserId).HasDatabaseName("IX_Messages_CreatedByUserId");

            entity.HasOne(x => x.Chat)
                .WithMany(x => x.Messages)
                .HasForeignKey(x => x.ChatId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.CreatedByUser)
                .WithMany(x => x.CreatedMessages)
                .HasForeignKey(x => x.CreatedByUserId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<MessageRead>(entity =>
        {
            entity.ToTable("MessageReads");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ReadAt).IsRequired();
            entity.HasIndex(x => new { x.MessageId, x.UserId })
                .HasDatabaseName("UX_MessageReads_Message_User")
                .IsUnique();

            entity.HasOne(x => x.Message)
                .WithMany(x => x.Reads)
                .HasForeignKey(x => x.MessageId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.User)
                .WithMany(x => x.MessageReads)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<MessageAttachment>(entity =>
        {
            entity.ToTable("MessageAttachments");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.FileName).IsRequired().HasMaxLength(255);
            entity.Property(x => x.FileUrl).IsRequired().HasMaxLength(500);
            entity.Property(x => x.MimeType).HasMaxLength(100);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.HasIndex(x => x.MessageId).HasDatabaseName("IX_MessageAttachments_MessageId");

            entity.HasOne(x => x.Message)
                .WithMany(x => x.Attachments)
                .HasForeignKey(x => x.MessageId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
