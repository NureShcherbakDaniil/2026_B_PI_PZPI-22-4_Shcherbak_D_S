﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations;

public partial class AddChatPinAndArchive : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            IF COL_LENGTH('Chats', 'IsPinned') IS NULL
            BEGIN
                ALTER TABLE [Chats] ADD [IsPinned] bit NOT NULL CONSTRAINT [DF_Chats_IsPinned] DEFAULT CAST(0 AS bit);
            END
            """);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            IF COL_LENGTH('Chats', 'IsPinned') IS NOT NULL
            BEGIN
                DECLARE @constraintName nvarchar(128);
                SELECT @constraintName = dc.name
                FROM sys.default_constraints dc
                INNER JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
                WHERE dc.parent_object_id = OBJECT_ID('Chats') AND c.name = 'IsPinned';

                IF @constraintName IS NOT NULL
                BEGIN
                    EXEC('ALTER TABLE [Chats] DROP CONSTRAINT [' + @constraintName + ']');
                END

                ALTER TABLE [Chats] DROP COLUMN [IsPinned];
            END
            """);
    }
}
