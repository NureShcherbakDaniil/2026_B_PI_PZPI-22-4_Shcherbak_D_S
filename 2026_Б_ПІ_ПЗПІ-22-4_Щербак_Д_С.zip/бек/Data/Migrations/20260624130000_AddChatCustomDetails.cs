﻿using Dialogly.Api.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations;

[DbContext(typeof(ApplicationDbContext))]
[Migration("20260624130000_AddChatCustomDetails")]
public partial class AddChatCustomDetails : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            IF COL_LENGTH('Chats', 'CustomName') IS NULL
            BEGIN
                ALTER TABLE [Chats] ADD [CustomName] nvarchar(255) NULL;
            END
            """);

        migrationBuilder.Sql("""
            IF COL_LENGTH('Chats', 'Notes') IS NULL
            BEGIN
                ALTER TABLE [Chats] ADD [Notes] nvarchar(2000) NULL;
            END
            """);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            IF COL_LENGTH('Chats', 'CustomName') IS NOT NULL
            BEGIN
                ALTER TABLE [Chats] DROP COLUMN [CustomName];
            END
            """);

        migrationBuilder.Sql("""
            IF COL_LENGTH('Chats', 'Notes') IS NOT NULL
            BEGIN
                ALTER TABLE [Chats] DROP COLUMN [Notes];
            END
            """);
    }
}
