using Dialogly.Api.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20260705093000_SplitMessageReactions")]
    public partial class SplitMessageReactions : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DialoglyReaction",
                table: "Messages",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TelegramReaction",
                table: "Messages",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.Sql("""
                IF COL_LENGTH('Messages', 'Reaction') IS NOT NULL
                BEGIN
                    UPDATE [Messages]
                    SET [DialoglyReaction] = [Reaction]
                    WHERE [Reaction] IS NOT NULL;
                END
                """);

            migrationBuilder.DropColumn(
                name: "Reaction",
                table: "Messages");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Reaction",
                table: "Messages",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.Sql("""
                UPDATE [Messages]
                SET [Reaction] = COALESCE([DialoglyReaction], [TelegramReaction])
                WHERE [DialoglyReaction] IS NOT NULL OR [TelegramReaction] IS NOT NULL;
                """);

            migrationBuilder.DropColumn(
                name: "DialoglyReaction",
                table: "Messages");

            migrationBuilder.DropColumn(
                name: "TelegramReaction",
                table: "Messages");
        }
    }
}
