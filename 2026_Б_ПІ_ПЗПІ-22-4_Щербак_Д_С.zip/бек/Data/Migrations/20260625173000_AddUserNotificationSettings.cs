using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations
{
    public partial class AddUserNotificationSettings : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "NotificationsEnabled",
                table: "UserSettings",
                type: "bit",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<bool>(
                name: "QuietHoursEnabled",
                table: "UserSettings",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "QuietHoursEnd",
                table: "UserSettings",
                type: "nvarchar(5)",
                maxLength: 5,
                nullable: false,
                defaultValue: "08:00");

            migrationBuilder.AddColumn<string>(
                name: "QuietHoursStart",
                table: "UserSettings",
                type: "nvarchar(5)",
                maxLength: 5,
                nullable: false,
                defaultValue: "22:00");

            migrationBuilder.AddColumn<bool>(
                name: "SoundEnabled",
                table: "UserSettings",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NotificationsEnabled",
                table: "UserSettings");

            migrationBuilder.DropColumn(
                name: "QuietHoursEnabled",
                table: "UserSettings");

            migrationBuilder.DropColumn(
                name: "QuietHoursEnd",
                table: "UserSettings");

            migrationBuilder.DropColumn(
                name: "QuietHoursStart",
                table: "UserSettings");

            migrationBuilder.DropColumn(
                name: "SoundEnabled",
                table: "UserSettings");
        }
    }
}
