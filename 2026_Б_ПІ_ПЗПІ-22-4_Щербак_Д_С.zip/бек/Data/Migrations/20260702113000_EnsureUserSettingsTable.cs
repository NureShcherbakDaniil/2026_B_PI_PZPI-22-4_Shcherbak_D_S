using Dialogly.Api.Data;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations;

[DbContext(typeof(ApplicationDbContext))]
[Migration("20260702113000_EnsureUserSettingsTable")]
public partial class EnsureUserSettingsTable : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            IF OBJECT_ID(N'[dbo].[UserSettings]', N'U') IS NULL
            BEGIN
                CREATE TABLE [dbo].[UserSettings] (
                    [Id] uniqueidentifier NOT NULL,
                    [UserId] uniqueidentifier NOT NULL,
                    [IsTourCompleted] bit NOT NULL DEFAULT CAST(0 AS bit),
                    [NotificationsEnabled] bit NOT NULL DEFAULT CAST(1 AS bit),
                    [SoundEnabled] bit NOT NULL DEFAULT CAST(0 AS bit),
                    [QuietHoursEnabled] bit NOT NULL DEFAULT CAST(0 AS bit),
                    [QuietHoursStart] nvarchar(5) NOT NULL DEFAULT N'22:00',
                    [QuietHoursEnd] nvarchar(5) NOT NULL DEFAULT N'08:00',
                    [CreatedAt] datetime2 NOT NULL,
                    [UpdatedAt] datetime2 NULL,
                    CONSTRAINT [PK_UserSettings] PRIMARY KEY ([Id]),
                    CONSTRAINT [FK_UserSettings_Users_UserId] FOREIGN KEY ([UserId]) REFERENCES [dbo].[Users] ([Id]) ON DELETE CASCADE
                );

                CREATE UNIQUE INDEX [UX_UserSettings_UserId] ON [dbo].[UserSettings] ([UserId]);
            END
            ELSE
            BEGIN
                IF COL_LENGTH(N'[dbo].[UserSettings]', N'NotificationsEnabled') IS NULL
                    ALTER TABLE [dbo].[UserSettings] ADD [NotificationsEnabled] bit NOT NULL DEFAULT CAST(1 AS bit);

                IF COL_LENGTH(N'[dbo].[UserSettings]', N'SoundEnabled') IS NULL
                    ALTER TABLE [dbo].[UserSettings] ADD [SoundEnabled] bit NOT NULL DEFAULT CAST(0 AS bit);

                IF COL_LENGTH(N'[dbo].[UserSettings]', N'QuietHoursEnabled') IS NULL
                    ALTER TABLE [dbo].[UserSettings] ADD [QuietHoursEnabled] bit NOT NULL DEFAULT CAST(0 AS bit);

                IF COL_LENGTH(N'[dbo].[UserSettings]', N'QuietHoursStart') IS NULL
                    ALTER TABLE [dbo].[UserSettings] ADD [QuietHoursStart] nvarchar(5) NOT NULL DEFAULT N'22:00';

                IF COL_LENGTH(N'[dbo].[UserSettings]', N'QuietHoursEnd') IS NULL
                    ALTER TABLE [dbo].[UserSettings] ADD [QuietHoursEnd] nvarchar(5) NOT NULL DEFAULT N'08:00';

                IF NOT EXISTS (
                    SELECT 1
                    FROM sys.indexes
                    WHERE [name] = N'UX_UserSettings_UserId'
                      AND [object_id] = OBJECT_ID(N'[dbo].[UserSettings]')
                )
                    CREATE UNIQUE INDEX [UX_UserSettings_UserId] ON [dbo].[UserSettings] ([UserId]);
            END
            """);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Intentionally no-op: this migration repairs databases where UserSettings
        // may already exist or may have been created outside EF's tracked history.
    }
}
