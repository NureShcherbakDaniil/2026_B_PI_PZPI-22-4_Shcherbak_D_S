﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddWorkspaceApiSupport : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "ActiveWorkspaceId",
                table: "Users",
                type: "uniqueidentifier",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ActiveWorkspaceId",
                table: "Users");
        }
    }
}
