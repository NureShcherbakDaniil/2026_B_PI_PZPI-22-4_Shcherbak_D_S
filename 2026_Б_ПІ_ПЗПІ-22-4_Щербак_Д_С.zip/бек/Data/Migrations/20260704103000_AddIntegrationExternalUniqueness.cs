﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddIntegrationExternalUniqueness : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("""
                IF EXISTS (
                    SELECT 1
                    FROM [Integrations]
                    WHERE [ExternalAccountId] IS NOT NULL
                      AND [IsActive] = 1
                      AND [DisconnectedAt] IS NULL
                    GROUP BY [PlatformId], [ExternalAccountId]
                    HAVING COUNT(*) > 1
                )
                BEGIN
                    THROW 51000, 'Cannot add unique integration index because duplicate active integrations exist. Run the duplicate integration check SQL and resolve duplicates first.', 1;
                END
                """);

            migrationBuilder.CreateIndex(
                name: "UX_Integrations_Platform_ExternalAccount_Active",
                table: "Integrations",
                columns: new[] { "PlatformId", "ExternalAccountId" },
                unique: true,
                filter: "[ExternalAccountId] IS NOT NULL AND [IsActive] = 1 AND [DisconnectedAt] IS NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "UX_Integrations_Platform_ExternalAccount_Active",
                table: "Integrations");
        }
    }
}
