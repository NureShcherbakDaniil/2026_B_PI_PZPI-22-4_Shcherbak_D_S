using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Dialogly.Api.Data.Migrations
{
    public partial class FixTwoFactorDefaultState : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                UPDATE [Users]
                SET [TwoFactorEnabled] = 0
                WHERE [TwoFactorSecret] IS NULL OR LTRIM(RTRIM([TwoFactorSecret])) = ''
            ");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
